import { environment } from './environments/environment';
import { initFederation } from '@angular-architects/native-federation';
import { mapRemotes } from './app/utils/remote-mapper';

const remoteEnvironments = mapRemotes(environment.remotes);

initFederation(remoteEnvironments)
  .catch(err => console.error(err))
  .then(() => import('./bootstrap'))
  .catch(err => console.error(err));
