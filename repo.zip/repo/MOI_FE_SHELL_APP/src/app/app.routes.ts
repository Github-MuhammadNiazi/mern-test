import { AppMfeProvidersService } from './services/app-mfe-providers.service';
import { DashboardGuard } from './guards/auth/dashboard.guard';
import { DocTypeResolver } from './guards/doc-type.resolver';

import { LoginRedirectGuard } from './guards/auth/login-redirect.guard';
import { NationalityResolver } from './guards/nationality.resolver';
import { OtpStepGuard } from './guards/auth/otp-step.guard';
import { RegisterUserFormResolver } from './core/resolvers/register-user.resolver';
import { Routes } from '@angular/router';

import { loadRemoteModule } from '@angular-architects/native-federation';



export const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
    // loadChildren: () =>
    //   loadRemoteModule('header-mfe', './Routes').then((m) => m.routes),
  },

  {
    path: 'login',
    canActivate: [LoginRedirectGuard],
    loadChildren: () => loadRemoteModule('login-mfe', './Routes').then((m) => m.routes),
    data: { isSignup: false }, // adjust login-mfe to display login UI
    providers: AppMfeProvidersService.getLoginProviders()
  },

  {
    path: 'login/otp',
    canActivate: [ OtpStepGuard, LoginRedirectGuard],
    loadChildren: () => loadRemoteModule('otp-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getOtpProviders({
      sendOtp: false,
      redirectTo: '/dashboard',
      extras: { queryParams: { from: 'otp' } }
    }),
  },

  {
    path: 'signup',
    loadChildren: () => loadRemoteModule('login-mfe', './Routes').then((m) => m.routes),
    data: { isSignup: true }, // adjust login-mfe to display signup UI
    providers: AppMfeProvidersService.getSignupProviders()
  },

  {
    path: 'signup/otp',
    canActivate: [OtpStepGuard],
    loadChildren: () => loadRemoteModule('otp-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getOtpProviders({
      sendOtp: true,
      redirectTo: ''
    }),
  },

  {
    path: 'signup/register-user',
    canActivate: [OtpStepGuard],
    loadChildren: () =>
      loadRemoteModule('signup-mfe', './Routes').then((m) => m.routes),
    data: {isSignup: true},
    resolve: {
      userData: RegisterUserFormResolver, // resolves formType, isEtisalatUser and user
      docType: DocTypeResolver,
      nationality: NationalityResolver
    },
    providers: AppMfeProvidersService.getRegisterUserProviders()
  },

  {
    path: 'home/:userId/dashboard',
    canActivate: [DashboardGuard],
    loadChildren: () =>
      loadRemoteModule('home-dashboard-mfe', './Routes').then((m) => m.routes),
    providers: AppMfeProvidersService.getHomeDashboardProviders()
  },

  {
    path: 'user/:userId/dashboard',
    canActivate: [DashboardGuard],
    loadChildren: () => loadRemoteModule('user-dashboard-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getUserDashboardProviders()
  },

  {
    path: 'plans',
    data: { isAuthenticated: false },
    loadChildren: () => loadRemoteModule('plans-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getPlansPageProviders()
  },

  {
    path: 'home/:orderId/configuration',
    canActivate: [DashboardGuard],
    data: { isAuthenticated: true }, // TODO: change hardcoded data - use resolver
    loadChildren: () => loadRemoteModule('plans-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getPlansPageProviders()
  },
  {
    path: 'home/:orderId/location',
    canActivate: [DashboardGuard],
    loadChildren: () => loadRemoteModule('gis-module-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getGisProviders()
  },

  {
    path: 'home/location',
    canActivate: [DashboardGuard],
    loadChildren: () => loadRemoteModule('gis-module-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getGisProviders()
  },

  {
    path: 'home/:orderId/configuration/review-order',
    loadChildren: () => loadRemoteModule('boq-mfe', './Routes').then(m => m.routes),
    providers: AppMfeProvidersService.getBoqProviders()
  },

  {
    path: ':orderId/payment-status/success',
    loadChildren: () => loadRemoteModule('boq-mfe', './Routes').then(m => m.routes),
    data: { isPaymentSuccessRoute: true },
    providers: AppMfeProvidersService.getBoqProviders()
  },

  {
    path: ':orderId/payment-status/failed',
    loadChildren: () => loadRemoteModule('boq-mfe', './Routes').then(m => m.routes),
    data: { isPaymentFailedRoute: true },
    providers: AppMfeProvidersService.getBoqProviders()
  },

  {
    path: 'error',
    loadChildren: () =>
      loadRemoteModule('error-page-mfe', './Routes').then(m => m.routes),
  },

  {
    path: '**',
    redirectTo: 'error/404',
    pathMatch: 'full'
  },
];

