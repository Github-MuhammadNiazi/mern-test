function mapRemotes(envRemotes) {
  return {
    "header-mfe": envRemotes.MFE_HEADER_URL,
    "footer-mfe": envRemotes.MFE_FOOTER_URL,
    "login-mfe": envRemotes.MFE_LOGIN_URL,
    "signup-mfe": envRemotes.MFE_SIGNUP_URL,
    "otp-mfe": envRemotes.MFE_OTP_URL,
    "user-dashboard-mfe": envRemotes.MFE_USER_DASHBOARD_URL,
    "error-page-mfe": envRemotes.MFE_ERROR_PAGE_URL,
    "home-dashboard-mfe": envRemotes.MFE_HOME_DASHBOARD_URL,
    "plans-mfe": envRemotes.MFE_PLANS,
    "gis-module-mfe": envRemotes.MFE_GIS_MODULE_URL,
    "boq-mfe": envRemotes.MFE_BOQ_URL,
  };
}

module.exports = { mapRemotes };
