export interface EnvironmentRemotes {
    MFE_HEADER_URL: string;
    MFE_FOOTER_URL: string;
    MFE_LOGIN_URL: string;
    MFE_SIGNUP_URL: string;
    MFE_OTP_URL: string;
    MFE_USER_DASHBOARD_URL: string;
    MFE_PLANS_URL: string;
    MFE_ERROR_PAGE_URL: string;
    MFE_HOME_DASHBOARD_URL: string;
    MFE_GIS_MODULE_URL: string;
    MFE_BOQ_URL: string;
}

export function mapRemotes (envRemotes: EnvironmentRemotes) {
  return {
    "header-mfe": envRemotes.MFE_HEADER_URL,
    "footer-mfe": envRemotes.MFE_FOOTER_URL,
    "login-mfe": envRemotes.MFE_LOGIN_URL,
    "signup-mfe": envRemotes.MFE_SIGNUP_URL,
    "otp-mfe": envRemotes.MFE_OTP_URL,
    "user-dashboard-mfe": envRemotes.MFE_USER_DASHBOARD_URL,
    "error-page-mfe": envRemotes.MFE_ERROR_PAGE_URL,
    "home-dashboard-mfe": envRemotes.MFE_HOME_DASHBOARD_URL,
    "plans-mfe": envRemotes.MFE_PLANS_URL,
    "gis-module-mfe": envRemotes.MFE_GIS_MODULE_URL,
    "boq-mfe": envRemotes.MFE_BOQ_URL
  };
}

