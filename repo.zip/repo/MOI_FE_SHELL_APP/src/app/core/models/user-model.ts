// import { DocType, GenderTitle } from "../enums/enums";

// export class UserModel {
//   active = false;
//   isPartyExists = false;
//   birthDate = '';
//   creationDate: string | undefined;
//   documentExpiryDate = '';
//   documentNumber: string | undefined;
//   documentStatus: string | undefined;
//   documentStatusLabelEn: string | undefined;
//   documentStatusLabelAr: string | undefined;
//   documentId: string | undefined;
//   documentType: DocType = DocType.EmiratesID;
//   email: string | undefined;
//   landlineNumber: string | undefined;
//   firstNameEn: string | undefined;
//   firstNameAr: string | undefined;
//   gender: GenderTitle | undefined;
//   id: number | undefined;
//   isDeveloper: boolean | undefined;
//   isEtisalatCustomer: boolean | undefined;
//   lastNameAr: string | undefined;
//   lastNameEn: string | undefined;
//   lastUpdateDate: string | undefined;
//   locale: string | undefined;
//   locked: boolean | undefined;
//   nationality: string | undefined;
//   partyId: string | undefined;
//   password: string | undefined;
//   passwordConfirm: string | undefined;
//   passwordExpired: boolean | undefined ;
//   primaryMobileNumber!: string;
//   residentialProfileId!: string;
//   userDocuments: DocumentModel[] = [];
//   userRoles: Role[] = [];
//   accountDetails: AccountDetails | undefined;
//   subsidizedAccountId!: string;
//   type: Status | undefined;
// }

// export class DocumentModel {
//   creationDate: string | undefined;
//   document: string | undefined;
//   id: number | undefined;
//   lastUpdateDate: string | undefined;
//   status: string | undefined;
//   documentType: DocType | undefined;
// }

// export class Role {
//   active?: boolean;
//   comments?: string;
//   displayName?: string;
//   id?: number;
//   name?: string;
// }


// export class AccountDetails {
//   accountActivationDate!: string;
//   accountCessationDate!: string;
//   accountId!: number;
//   accountNumber!: string;
//   accountStatus!: AccountStatus;
//   productGroup!: Status;
//   accountSuffix!: string;
//   accountType!: string;
//   createdBy!: string;
//   modifiedBy!: string;
//   createdDate!: string;
//   modifiedDate!: string;
//   profileId!: number;
//   customerId!: string;
//   billingCycleId!: string;
//   linkedPrivileges!: LinkedPrivileges;
// };

// export class Status {
//   code: string | undefined;
//   name: string | undefined;
//   id: string | undefined;
//   description: string | undefined;
// };

// export class AccountStatus {
//   code!: string;
//   name!: string;
//   id!: string;
//   description!: string;
// }

// export class LinkedPrivileges {
//   privilegeType!: Status;
//   documentType!: DocumentType;
//   documentNumber!: string;
//   addresses!: Addresses;
// };

// export class Addresses {
//   contactName: string | undefined;
//   contactMobileNo!: string;
//   email!: string;
//   newAddress!: boolean;
//   addressLine1!: string;
//   addressLine2!: string;
//   villaLongitude!: string;
//   villaLatitude!: string;
//   buildingName!: string;
//   villaorBuildingNbr!: string;
//   makaniOwmaniNbr!: string;
//   community!: Status;
//   city!: Status;
//   state!: Status;
//   plot!: string;
//   poBox!: string;
//   alreadyProcessedOrderID!: string;
//   alreadyProcessed = false;
// };


// export class DocumentType {
//   code: string | undefined;
//   name: string | undefined;
//   id!: string;
//   description!: string;
// };
