import { Models } from "shared-state";

export interface AuthState {
  user: Models.UserModel | null;
  token: string | null;
  isAuthenticated: boolean;
  tempEmail: string | null; // temporary until login success
  error: string | null;
  isEtisilatUser: boolean | null;
}
