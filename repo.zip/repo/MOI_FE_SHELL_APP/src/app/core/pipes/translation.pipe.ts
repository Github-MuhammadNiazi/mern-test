import { Pipe, PipeTransform, inject } from "@angular/core";
import { SharedState } from 'shared-state';
@Pipe({
    name: 'translate$',
    standalone: true,
    pure: true
})
export class TranslateAsyncPipe implements PipeTransform {
    private sharedService: any = inject(SharedState);

    transform(key: string) {
        return this.sharedService.translate$(key);
    }
}