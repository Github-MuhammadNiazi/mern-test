import { AuthActions } from '../../../public-api';
import { HttpInterceptorFn } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { ToastService } from 'shared-state';

import { catchError } from 'rxjs/operators';
import { inject } from '@angular/core';
import { throwError } from 'rxjs';


export const generalInterceptor: HttpInterceptorFn = (req, next) => {
  const store = inject(Store);
  const toastSvc = inject(ToastService);

  return next(req.clone({
    setHeaders: { 'Content-Type': 'application/json' }
  })).pipe(
    catchError((error) => {
      // Session expired - redirect to login and show error toast
      if (error.status === 401) {
        store.dispatch(AuthActions.logout());
        toastSvc.error("label.sessionExpired", "label.loginToContinue");

      }
      return throwError(() => error);
    })
  );
};

