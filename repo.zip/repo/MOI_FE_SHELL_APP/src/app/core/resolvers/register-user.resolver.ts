import { Injectable, inject } from "@angular/core";
import { combineLatest, filter, firstValueFrom, map, take } from "rxjs";
import { selectIsDeveloper, selectIsEtisalatUser, selectUser } from "../../store/auth/auth.selectors";

import { Resolve } from "@angular/router";
import { Store } from "@ngrx/store";

@Injectable({ providedIn: 'root' })
export class RegisterUserFormResolver implements Resolve<unknown> {
  private store = inject(Store);

  resolve () {
    const userType$ = this.store.select(selectIsDeveloper).pipe(filter(v => v !== null), take(1));
    const isEtisalat$ = this.store.select(selectIsEtisalatUser).pipe(filter(v => v !== null), take(1));
    const user$ = this.store.select(selectUser).pipe(take(1)); // optional

    return firstValueFrom(combineLatest([userType$, isEtisalat$, user$]).pipe(
      map(([userType, isEtisalat, user]) => ({ formType: userType == true ? 'developer' : 'individual', isEtisalatUser: isEtisalat, user }))
    ));
  }
}
