export enum DocType {
  EmiratesID = 'EMIRATES_ID',
  Passport = 'PASSPORT',
  Registration = 'REGISTRATION',
  EmiratesNumber = 'EMIRATES_Number',
  TitleDeed = 'TITLE_DEED',
  UaeIdentityCard ='UAE Identity card',
  EstablishmentCard = 'ESTABLISHMENT_CARD',
};


export enum GenderTitle {
  Mr = 'MALE', Mrs = 'FEMALE'
}

export enum GenderTitleAr {
  السيد = 'MALE', السيدة = 'FEMALE'
}

export enum NavAction {
    Logout = 'logout',
}

export enum HttpStatus {
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
}

export enum ApiStatus {
  OK = 'OK',
  FORBIDDEN = 'FORBIDDEN',
  ERROR = 'ERROR',
}
