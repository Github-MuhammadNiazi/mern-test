import { DevicesConfig, Product } from '../interfaces/interfaces';
import { Injectable, inject } from '@angular/core';
import { Observable, map, of, tap } from 'rxjs';
import { ApiResponse } from '../interfaces/api-response';
import { HttpClient } from '@angular/common/http';

import { Models } from 'shared-state';
import { Router } from '@angular/router';
import { SessionStorageService } from './local-storage.service';
import { environment } from '../../environments/environment';


/**
 * Utility method to return data only from api response
 * @param Observable call
 * @returns Response data from api call
 */
function unwrap<T> (obs: Observable<ApiResponse<T>>): Observable<T> {
  return obs.pipe(map((res) => res.data));
}
@Injectable({
  providedIn: 'root',
})
export class OrderService {
  private httpClient: HttpClient = inject(HttpClient);
  private sessionStorageSvc: SessionStorageService = inject(
    SessionStorageService
  );

  private http = inject(HttpClient);
  private router = inject(Router);

  getSelectedOrderId (orderId: number) {
    console.log('orderId in shall', orderId);
    this.router.navigate([`home/${orderId}/dashboard`]);
  }

  getOrderById (orderId: number): Observable<Models.UserData> {
    const apiUrl = `${environment.API_BASE_URL}/${environment.ORDER_BY_ID}/${orderId}`;
    return this.http.get<Models.UserData>(apiUrl, { withCredentials: true });
  }

  getQuotes (orderId: number): Observable<Models.UserData> {
    const apiUrl = `${environment.API_BASE_URL}/${environment.ORDER_BY_ID}/${orderId}/quote`;
    return this.http.get<Models.UserData>(apiUrl, { withCredentials: true });
  }

  updateSecondaryPhoneNo (orderId: number, orderData: Models.OrderModel): Observable<Models.OrderModel> {
    console.log('body', orderData);
    console.log('orderId', orderId);
    // Update secondary phone number for the order
    const apiUrl = `${environment.API_BASE_URL}/${environment.ORDER_BY_ID}/${orderId}`;
    return this.http.patch<Models.OrderModel>(apiUrl, orderData, { withCredentials: true });
  }

  /**
   * Get package plans either from session storage or by fetching from the API.
   */
  getPackagePlans () {
    const packages = this.sessionStorageSvc.getPackages('en'); // TODO: fetch locale from translationSvc

    if (packages && packages.data) {
      return of(packages.data);
    }

    // Fetch packages from the API if not available in session storage
    return this.fetchPackagesByLocale('en').pipe(
      tap((response) => {
        this.sessionStorageSvc.setPackages(response, 'en');
      })
    );
  }

  /**
   * Get device config either from session storage or by fetching from the API.
   */
  getDevicesConfig () {
    const config = this.sessionStorageSvc.getGetDeviceConfig();

    if (config && config.data) {
      return of(config.data);
    }

    // Fetch from api
    return this.fetchDevicesConfig().pipe(
      tap((response) => {
        this.sessionStorageSvc.setDeviceConfig(response);
      })
    );
  }

  /**
   * Fetch packages by locale from the API.
   * @param locale The locale to fetch packages for.
   */
  fetchPackagesByLocale (locale: string): Observable<Product> {
    const apiUrl = `${environment.API_BASE_URL}/${environment.GET_PACKAGES_ENDPOINT}`;
    return unwrap(this.httpClient.get<ApiResponse<Product>>(
      apiUrl + '?locale=' + locale
    ));
  }

  /**
   * Fetch device config from the API.
   */
  fetchDevicesConfig (): Observable<DevicesConfig> {
    const apiUrl = `${environment.API_BASE_URL}/${environment.GET_DEVICES_CONFIG}`;
    return unwrap(this.httpClient.get<ApiResponse<DevicesConfig>>(apiUrl));
  }

  /**
   * Get order by order id
   * @param orderId
   * @returns Order
   */
  getOrderByOrderid (orderId: number): Observable<Models.OrderModel> {
    const apiUrl = `${environment.API_BASE_URL}/${environment.ORDER}`;
    return unwrap(this.httpClient.get<ApiResponse<Models.OrderModel>>(apiUrl + '/' + orderId, {withCredentials: true}));
  }

  /**
   * Submit updated order
   * @param orderModel
   * @returns
   */
  submitOrderPatch (
    orderModel: Models.OrderModel
  ): Observable<Models.OrderModel> {
    const apiUrl = `${environment.API_BASE_URL}/${environment.ORDER}`;
    return unwrap(
      this.httpClient.patch<ApiResponse<Models.OrderModel>>(
        apiUrl + "/" + orderModel.id,
        orderModel,
        {withCredentials: true}
      )
    );
  }

  /**
   * postPaidEligibilityCheck
   * @param phone number
   * @returns
   */
  postPaidEligibilityCheck (phone: string, isLoggedIn : boolean) {
    const endpoint = isLoggedIn ? environment.POST_PAID_ELIGIBILITY_CHECK : environment.POST_PAID_ELIGIBILITY_CHECK_PUBLIC;
    const apiUrl = `${environment.API_BASE_URL}/${endpoint}`;
    return unwrap(
      this.httpClient.get<ApiResponse<{status: string; errorCode: null; errorType: null; errorDescription: string;}>
      >(apiUrl + '?accountNumber=' + phone, {withCredentials: true})
    );
  }
}
