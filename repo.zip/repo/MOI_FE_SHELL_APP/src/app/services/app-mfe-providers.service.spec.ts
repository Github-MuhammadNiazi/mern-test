import { TestBed } from '@angular/core/testing';

import { AppMfeProvidersService } from './app-mfe-providers.service';

describe('AppMfeProvidersService', () => {
  let service: AppMfeProvidersService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppMfeProvidersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
