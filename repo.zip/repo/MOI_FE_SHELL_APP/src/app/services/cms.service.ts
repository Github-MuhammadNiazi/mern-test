import { Injectable, inject } from '@angular/core';
import { CmsConfig } from '../interfaces/cms-config.interface';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CmsService {
  private http = inject(HttpClient);

  cmsConfig (data: CmsConfig) {
    const URL = `${environment.API_BASE_URL}/${environment.CMS_ENDPOINT}`;
    return this.http.post(URL, data, { withCredentials: true, headers: { 'Content-Type': 'application/json' }});
  }
}
