import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { catchError, map, throwError } from 'rxjs';

import { Models } from 'shared-state';
import { NsLookupItem } from '../interfaces/NsLookupModel';
import { docTypeModel } from '../interfaces/docTypeModel';

import { docTypes } from '../../../public/documentTypes';
import { environment } from '../../environments/environment';
import { nsLookup } from '../../../public/nsLookup';




@Injectable({
  providedIn: 'root'
})
export class UserService {
  docTypes: docTypeModel[] = docTypes;
  nationality: NsLookupItem[] = nsLookup;
  private http = inject(HttpClient);

  setDocType (){
    this.docTypes = docTypes;
  }

  getDocType (){
    return this.docTypes;
  }

  setNationality (){
    this.nationality = nsLookup;
  }

  getNationality (){
    return this.nationality;
  }

  registerUser (data: Models.UserModel) {
    console.log('data from register user-->', data);
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    return this.http.post(`${environment.API_BASE_URL}/${environment.REGISTER_USER_ENDPOINT}`, data, { headers }).pipe(
      catchError(error => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }

  registerDeveloper (data: Models.UserModel) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    return this.http.post(`${environment.API_BASE_URL}/${environment.REGISTER_DEVELOPER_ENDPOINT}`, data, { headers }).pipe(
      catchError(error => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }

  verifyDeveloperProfile (data: Models.UserModel) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    return this.http.post(`${environment.API_BASE_URL}/${environment.VERIFY_DEVELOPER_ENDPOINT}`, data, { headers }).pipe(
      catchError(error => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }

  validateEid (id: number) {
    console.log('validateEid', id);
    return this.http.get(`${environment.API_BASE_URL}/${environment.VALIDATE_EID_ENDPOINT}?document_id=${id}`).pipe(
      catchError(error => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }

  validateEmail (email: number) {
    console.log('validateEmail', email);
    return this.http.get(`${environment.API_BASE_URL}/${environment.CHECK_USER_EXISTS_ENDPOINT}?email=${email}`).pipe(
      catchError(error => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }

  getUserOrder (userId: number, pageNumber: number, pageSize: number) {
    // Construct the API URL dynamically
    const apiUrl = `${environment.API_BASE_URL}/${environment.USER_ORDERS_ENDPOINT}/${userId}/orders?pageNo=${pageNumber}&recordsPerPage=${pageSize}`;

    // Make the HTTP GET request and handle errors
    return this.http.get(apiUrl, {withCredentials: true}).pipe(
      catchError((error) => {
        console.error('An error occurred while fetching user orders:', error);
        return throwError(() => new Error('Failed to fetch user orders.'));
      })
    );
  }

  getCurrentUser () {
    const apiUrl = `${environment.API_BASE_URL}/${environment.USER_ORDERS_ENDPOINT}/current`;
    return this.http.get<Models.UserData>(apiUrl, { withCredentials: true }).pipe(
      map((response) => {
        const mockToken = 'mock-jwt-token-123456';
        return {
          user: response.data as Models.UserModel,
          token: mockToken
        };
      }),
      catchError((error) => {
        console.error('Error fetching current user:', error);
        return throwError(() => new Error('Failed to fetch current user.'));
      })
    );
  }

}
