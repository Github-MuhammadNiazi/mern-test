import {
  EnvironmentInjector,
  Injectable,
  createEnvironmentInjector,
  inject,
} from '@angular/core';
import { Models, TranslationService } from 'shared-state';
import { Observable, Subject, catchError, firstValueFrom, map, switchMap, take, tap, throwError } from 'rxjs';
import { selectIsDeveloper, selectPhoneNumber, selectTempEmail, selectUser } from '../store/auth/auth.selectors';
import { ApiResponse } from '../interfaces/footer.model';
import { AppMfeProvidersService } from './app-mfe-providers.service';
import { AuthActions } from '../store/auth/auth.actions';
import { CmsService } from './cms.service';
import { ModalService } from './modal-service';
import { OrderService } from './order.service';
import { PromiseStatus } from '../core/enums/promises';

import { Router } from '@angular/router';
import { Store } from '@ngrx/store';

import { environment } from '../../environments/environment';
import { loadRemoteModule } from '@angular-architects/native-federation';
import { toSignal } from '@angular/core/rxjs-interop';



@Injectable({
  providedIn: 'root',
})
export class SharedService {
  translatedText$!: Observable<string>;
  lang = '';
  private cmsService = inject(CmsService);
  footerCmsData!: ApiResponse;
  private translationSvc = inject(TranslationService);
  private phone = '';
  private envInjector = inject(EnvironmentInjector);
  private store: Store<{ login: { user: Models.UserModel } }> = inject(Store);
  private router = inject(Router);
  private modalSvc = inject(ModalService);
  private orderSvc = inject(OrderService);
  private readonly loginEmailSignature = toSignal(
    this.store.select(selectTempEmail),
    { initialValue: '' }
  );

  private otpSuccess$ = new Subject<void>();

  get msisdn (): string {
    return this.phone;
  }

  get loginEmail (): string {
    return this.loginEmailSignature() ?? '';
  }

  setMsisdn (v: string) {
    this.phone = v;
    this.store.dispatch(AuthActions.signupStart({msisdn: this.phone}));
  }

  setIsDeveloper (type: string) {
    const isDev = type === "individual" ? false : true;
    this.store.dispatch(AuthActions.setFormType({isDeveloper: isDev}));
  }

  setEmail (email: string) {
    this.store.dispatch(AuthActions.loginStart({ email: email })); // start login flow set user email in temp state
  }

  fetchCmsData (urlConfig: string, locale: string) {
    const url = `cms_${urlConfig}_uri_config`;
    return this.cmsService.cmsConfig({ url, locale }) as Observable<ApiResponse>;
  }

  async loadComponents () {
    const results = await Promise.allSettled([
      loadRemoteModule({
        remoteName: 'header-mfe',
        exposedModule: './HeaderComponent',
      }),
      loadRemoteModule({
        remoteName: 'footer-mfe',
        exposedModule: './FooterComponent',
      }),
    ]);
    const [headerMFE, footerMFE] = results;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const components: any = {};

    if (headerMFE.status === PromiseStatus.fulfilled) {
      components.header = headerMFE.value.HeaderComponent;
    } else {
      console.error('MFE header failed to load:', headerMFE.reason);
    }

    if (footerMFE.status === PromiseStatus.fulfilled) {
      components.footer = footerMFE.value.FooterComponent;
    } else {
      console.error('MFE footer failed to load:', footerMFE.reason);
    }

    return components;
  }

  getCurrentLanguage (): Observable<string> {
    return this.translationSvc.language$.pipe(
      tap((language: string) => {
        return language; // Log or use the value
      }),
      catchError((error) => {
        console.error('Error while subscribing to language$', error); // Handle errors if any
        return throwError(error); // Return an observable error
      })
    );
  }

  // Function to create the footer injector
  createFooterInjector (): Observable<EnvironmentInjector> {
    return this.getCurrentLanguage().pipe(
      switchMap((language: string) => {
        return this.fetchCmsData('footer', language);
      }),
      map((cmsResponse: ApiResponse) => {
        this.footerCmsData = cmsResponse;
        return createEnvironmentInjector(
          [
            { provide: 'channelName', useValue: 'MOI' },
            {
              provide: 'footerLinks',
              useValue: this.footerCmsData,
            },
            {
              provide: 'devNewURL',
              useValue: environment.API_DEV_NEW,
            },
          ],
          this.envInjector
        );
      }),
      catchError((error) => {
        console.error('Error while creating footer injector:', error);
        return throwError(error); // Handle errors gracefully
      })
    );
  }

  createHeaderInjector (): EnvironmentInjector {
    return createEnvironmentInjector(
      AppMfeProvidersService.getHeaderProviders(),
      this.envInjector
    );
  }

  logoutUser () {
    this.store.dispatch(AuthActions.logout());
  }

  async onOtpSuccess (otp: string, isSignup = false, type: 'popup' | 'page') {
    if(type === 'popup'){
      // if coming from popup - call postpaid eligibility api
      this.otpSuccess$.next();
      return;
    }
    if(isSignup) {
      const accountNumber = await firstValueFrom(this.store.select(selectPhoneNumber));
      const isDeveloper =  await firstValueFrom(this.store.select(selectIsDeveloper));
      if(accountNumber && !isDeveloper){
        this.store.dispatch(AuthActions.getUserByAccountNumber({accountNumber, otp}));
      }
      else if (accountNumber && isDeveloper){
        sessionStorage.setItem('fromInApp', 'true');
        this.router.navigate([`/signup/register-user`]);
      }
      else {
        console.error("AccountNumber not found in onOtpSUccess callback");
      }
    }
    else {
      // login otp verified - go to dashboard
      this.store.dispatch(AuthActions.verifyOTPSuccess());
    }
  }

  onSignupSuccess () {
    this.store.dispatch(AuthActions.verifyOTPSuccess());
  }

  onOtpFailure (reason: unknown) {
    this.store.dispatch(
      AuthActions.verifyOTPFailure({ error: reason as string })
    );
  }


  /**
   * Checks the postpaid eligibility for a given phone number, handling OTP flow if the user is not authenticated.
   *
   * If the user is authenticated, it directly calls the postpaid eligibility check service.
   * If the user is not authenticated, it sets the MSISDN, shows an OTP modal,
   * and waits for OTP success before proceeding with the eligibility check.
   *
   * @param phoneNumber - The phone number to check for postpaid eligibility.
   * @returns An observable that emits the result of the postpaid eligibility check.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  checkPostpaidEligibilityOtpFlow (phoneNumber: string): Observable<any> {
    return this.store.select(selectUser).pipe(
      take(1),
      switchMap(user => {
        if (user) {
          return this.orderSvc.postPaidEligibilityCheck(phoneNumber, true).pipe(
            tap(() => this.modalSvc.closeModal()), // hide on success
            catchError(err => {
              this.modalSvc.closeModal(); // hide on error
              return throwError(() => err);
            })
          );
        }

        this.setMsisdn(phoneNumber);
        this.modalSvc.showModal();

        return this.otpSuccess$.pipe(
          take(1),
          switchMap(() =>
            this.orderSvc.postPaidEligibilityCheck(phoneNumber, false).pipe(
              tap(() => this.modalSvc.closeModal()), // hide modal on success
              catchError(err => {
                this.modalSvc.closeModal(); // hide modal on error too
                return throwError(() => err);
              })
            )
          )
        );
      })
    );
  }
}
