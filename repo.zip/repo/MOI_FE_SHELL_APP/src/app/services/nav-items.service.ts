/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable, inject } from '@angular/core';
import { Observable, combineLatest, forkJoin, map, of, switchMap } from 'rxjs';
import { selectIsAuthenticated, selectUserId } from '../store/auth/auth.selectors';
import { AuthActions } from '../../public-api';
import { CmsConfig } from '../interfaces/cms-config.interface';
import { CmsService } from '../services/cms.service';
import { NavAction } from '../core/enums/enums';
import { NavItem } from '../interfaces/nav-item';
import { Store } from '@ngrx/store';
import { TranslationService } from 'shared-state';

@Injectable({ providedIn: 'root' })
export class NavItemsService {
  private store = inject(Store);
  private translationSvc = inject(TranslationService);
  private cmsService = inject(CmsService);

  /**
   * Fetch navigation items based on authentication status and language.
   */
  getNavItems (): Observable<NavItem[]> {
    return combineLatest([
      this.store.select(selectIsAuthenticated),
      this.store.select(selectUserId),
      this.translationSvc.language$,
    ]).pipe(
      switchMap(([isAuthenticated, userId, lang]) =>
        isAuthenticated && userId
          ? this.getAuthenticatedNavItems(userId, lang)
          : this.getUnauthenticatedNavItems(lang)
      )
    );
  }

  /**
   * Generate navigation items for authenticated users.
   * @param userId - User ID
   * @param lang - Language code
   */
  private getAuthenticatedNavItems (userId: number, lang: string): Observable<NavItem[]> {
    const items: NavItem[] = [
      {
        label: lang === 'en' ? 'Dashboard' : 'لوحة القيادة',
        url: `/user/${userId}/dashboard`,
        translationKey: 'dashboard-label',
      },
      {
        label: lang === 'en' ? 'Profile' : 'الملف الشخصي',
        url: `/user/${userId}/profile`,
        translationKey: 'profile-label',
      },
      {
        label: lang === 'en' ? 'Logout' : 'تسجيل خروج',
        action: NavAction.Logout,
        callback: () => this.store.dispatch(AuthActions.logout()),
        translationKey: 'nav.logout',
      },
    ];
    return of(items);
  }

  /**
   * Generate navigation items for unauthenticated users by fetching CMS configurations.
   * @param lang - Language code
   */
  private getUnauthenticatedNavItems (lang: string): Observable<NavItem[]> {
    const topNavParams: CmsConfig = { url: 'cms_top_nav_uri_config', locale: lang };
    const headerNavParams: CmsConfig = { url: 'cms_header_uri_config', locale: lang };

    const topNav$ = this.fetchCmsNavItems(topNavParams, 'topNavigationSection');
    const headerNav$ = this.fetchCmsNavItems(headerNavParams, ['mainMenuLeftSection', 'mainMenuRightSection']);

    return forkJoin([topNav$, headerNav$]).pipe(
      map(([topNav, headerNav]) => this.mergeAndOrderNavItems(topNav, headerNav, lang))
    );
  }

  /**
   * Fetch navigation items from CMS based on the provided configuration and section keys.
   * @param params - CMS configuration parameters
   * @param sectionKeys - Keys to extract navigation sections
   */
  private fetchCmsNavItems (params: CmsConfig, sectionKeys: string | string[]): Observable<NavItem[]> {
    return this.cmsService.cmsConfig(params).pipe(
      map((res: any) => {
        const sections = Array.isArray(sectionKeys)
          ? sectionKeys.flatMap(key => res?.data?.header?.data?.menuSectionByPath?.item?.[key] || [])
          : res?.data?.topNav?.data?.menuSectionByPath?.item?.[sectionKeys] || [];

        return sections
          // eslint-disable-next-line no-underscore-dangle
          .filter((section: any) => !section._path.includes('translation_text') && section.linkText?.trim())
          .map((section: any) => ({
            label: section.linkText,
            url: section.linkUrl.includes('login') ? '/login' :  section.linkUrl.includes('plans') ? '/plans' : section.linkUrl,
          }));
      })
    );
  }

  /**
   * Merge and order navigation items based on a predefined order.
   * ** ⚠️ Temporary method, once cms returns correct data this will be removed  ⚠️ **
   * @param topNav - Top navigation items
   * @param headerNav - Header navigation items
   */
  private mergeAndOrderNavItems (topNav: NavItem[], headerNav: NavItem[], lang: string): NavItem[] {
    const merged = [...topNav, ...headerNav].filter(item => item?.label?.trim());

    const predefinedOrder = ['Home', 'Plans', 'Media & Insights', 'Login', 'Quick Pay'];
    const ordered = predefinedOrder
      .map(label => merged.find(item => item.label === label))
      .filter(Boolean) as NavItem[];

    if(lang === 'ar') {
      const extras: NavItem[] =   merged.filter(item => !predefinedOrder.includes(item.label));
      return [...ordered, ...extras];
    }
    return ordered;
  }
}
