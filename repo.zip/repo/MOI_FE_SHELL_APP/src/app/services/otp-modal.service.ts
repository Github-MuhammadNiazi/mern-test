/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @angular-eslint/prefer-inject */
import { ApplicationRef, ComponentRef, Injectable, Injector, createComponent, createEnvironmentInjector } from '@angular/core';
import { AppMfeProvidersService } from './app-mfe-providers.service';
import { loadRemoteModule } from '@angular-architects/native-federation';

@Injectable({ providedIn: 'root' })
export class OtpService {
  private modalWrapper?: HTMLElement;
  private compRef?: ComponentRef<any>;
  private modalInstance?: any;
  constructor (private injector: Injector, private appRef: ApplicationRef) {}

  async openOtp () {
    const remoteModule = await loadRemoteModule({
      remoteName: 'otp-mfe',
      exposedModule: './OtpComponent'
    });

    const envInjc = createEnvironmentInjector(
      AppMfeProvidersService.getOtpProviders({ sendOtp: true, redirectTo: '', type: 'popup' }),
      this.appRef.injector
    );

    this.compRef = createComponent(remoteModule.OtpComponent, {
      environmentInjector: envInjc,
      elementInjector: this.injector,
    });

    this.appRef.attachView(this.compRef.hostView);

    // Find modal body
    const modalEl = document.getElementById('otpModal');
    const modalBody = modalEl?.querySelector('.modal-body');

    if (modalBody) {
    // Clear old content if any
      modalBody.innerHTML = '';

      // Create a fresh container div
      const container = document.createElement('div');
      container.classList.add('otp-wrapper');

      // Append Angular component
      container.appendChild(this.compRef.location.nativeElement);
      modalBody.appendChild(container);
    }

    // Show Bootstrap modal
    if (modalEl) {
      this.modalInstance = new (window as any).bootstrap.Modal(modalEl);
      this.modalInstance.show();

      modalEl.addEventListener('hidden.bs.modal', () => this.closeOtp(), { once: true });
    }
  }
  closeOtp () {
    if (this.compRef) {
      this.appRef.detachView(this.compRef.hostView);
      this.compRef.destroy();
      this.compRef = undefined;
    }

    if(this.modalInstance){
      this.modalInstance.hide();
      this.modalInstance = undefined;
    }
  }
}

