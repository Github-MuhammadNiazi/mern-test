import { BehaviorSubject, Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  private showModalSubject = new BehaviorSubject<boolean>(false);
  showModal$: Observable<boolean> = this.showModalSubject.asObservable();

  // update modal state
  showModal () {
    this.showModalSubject.next(true);
  }

  closeModal () {
    this.showModalSubject.next(false);
  }
}
