/* eslint-disable @typescript-eslint/no-explicit-any */
import { DevicesConfig } from '../interfaces/interfaces';
import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LocalstorageService {
  valueee: any;

  getToken () {
    const config = localStorage.getItem('userToken');
    return config ? JSON.parse(config) : null;

  }

  setToken (token: string) {
    localStorage.setItem('userToken', token);
  }

  deleteToken () {
    localStorage.removeItem('userToken');
  }

  getCurrentUser () {
    const config = localStorage.getItem('currentUser');
    return config ? JSON.parse(config) : null;
  }

  setCurrentUser (user: any) {
    localStorage.setItem('currentUser', user);
  }

  deleteCurrentUser () {
    this.deleteToken();
    localStorage.removeItem('currentUser');
  }

  getEligibleAccountNumber () {
    if(localStorage.getItem('eligibleAccountNumber') != "") {
      const config = localStorage.getItem('eligibleAccountNumber');
      return config ? JSON.parse(config) : null;
    }
  }

  setEligibleAccountNumber (accountNumber: any) {
    localStorage.setItem('eligibleAccountNumber', accountNumber);
  }

  getEmiratesId () {
    if(localStorage.getItem('emirateId') != "") {
      const config = localStorage.getItem('emirateId');
      return config ? JSON.parse(config) : null;
    }
  }

  setEmiratesId (accountNumber: any) {
    localStorage.setItem('emirateId', accountNumber);
  }

}


@Injectable({
  providedIn: 'root',
})
export class SessionStorageService {

  getDevicesOrder () {
    const config = sessionStorage.getItem('devicesOrder');
    return config ? JSON.parse(config) : null;
  }

  setDevicesOrder (order: any) {
    sessionStorage.setItem('devicesOrder', JSON.stringify(order));
  }

  deleteDevicesOrder () {
    sessionStorage.removeItem('devicesOrder');
  }

  getDevicesQuote () {
    const config = sessionStorage.getItem('devicesQuote');
    return config ? JSON.parse(config) : null;
  }

  setDevicesQuote (quote: any) {
    sessionStorage.setItem('devicesQuote', JSON.stringify(quote));
  }

  deleteDevicesQuote () {
    sessionStorage.removeItem('devicesQuote');
  }

  preserveSubOrderBuildingConfigurations (buildingConfigurations: any) {
    sessionStorage.setItem('subOrderBuildingConfigurations', JSON.stringify(buildingConfigurations));
  }

  fetchSubOrderBuildingConfigurations () {
    const config = sessionStorage.getItem('subOrderBuildingConfigurations');
    return config ? JSON.parse(config) : null;
  }

  removeSubOrderBuildingConfigurations () {
    sessionStorage.removeItem('subOrderBuildingConfigurations');
  }

  setPreLoginOrder (order:any){
    sessionStorage.setItem('preLoginOrder', JSON.stringify(order));
  }

  getPreLoginOrder (){
    const preLoginOrder = sessionStorage.getItem("preLoginOrder");
    return preLoginOrder === null ? null : JSON.parse(preLoginOrder);
  }

  removePreLoginOrder (){
    sessionStorage.removeItem('preLoginOrder');
  }

  setPackages (packages: any, locale: string) {
    sessionStorage.setItem(`packages_${locale}`, JSON.stringify(packages));
  }

  getPackages (locale: string) {
    const packages = sessionStorage.getItem(`packages_${locale}`);
    const data = packages ? JSON.parse(packages) : null;
    return {data: data};
  }

  setDeviceConfig (deviceConfig : DevicesConfig[] | DevicesConfig) {
    sessionStorage.setItem(`deviceConfig`, JSON.stringify(deviceConfig));
  }

  getGetDeviceConfig () {
    const config = sessionStorage.getItem('deviceConfig');
    const data = config ? JSON.parse(config) : null;
    return {data: data};
  }
}
