
import { Enums, Models } from "shared-state";
import { Injectable, inject  } from "@angular/core";
import { Observable, delay, of } from "rxjs";

import { ApiResponse } from "../interfaces/interfaces";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../environments/environment";



// TODO: move this interface to shared-lib
export interface OtpResponse {
  status: string;
  data?: unknown;
  code?: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private httpClient: HttpClient = inject(HttpClient);
  currentUserData!: Models.UserModel;

  /**
   * Retrieves user information by account number and OTP.
   *
   * Calls the backend API to fetch user details based on the provided
   * account number and one-time password (OTP).
   *
   * @param accountNumber - The account number of the user to retrieve.
   * @param otp - The one-time password for authentication.
   * @returns An Observable emitting the API response containing user information.
   */
  getUserByAccountNo (accountNumber: string, otp: string): Observable<ApiResponse> {
    const apiUrl = `${environment.API_BASE_URL}/${environment.REGISTER_USER_ENDPOINT}`;
    return this.httpClient.get<ApiResponse>(apiUrl + '?account_number=' + accountNumber + '&otp=' + otp);
  }


  login () {
    const mockUser: Models.UserModel = {
      email: 'user@example.com',
      active: false,
      isPartyExists: false,
      birthDate: '',
      creationDate: '',
      documentExpiryDate: '',
      documentNumber: '',
      documentStatus: '',
      documentStatusLabelEn: '',
      documentStatusLabelAr: '',
      documentId: '',
      documentType: Enums.DocType.EmiratesID,
      landlineNumber: '',
      firstNameEn: 'Ali Raza',
      fistNameAr: '',
      gender: Enums.GenderTitle.Mr,
      id: 12344,
      isDeveloper: false,
      isEtisalatCustomer: false,
      lastNameAr: '',
      lastNameEn: '',
      lastUpdateDate: '',
      locale: '',
      locked: false,
      nationality: '',
      partyId: '',
      password: '',
      passwordConfirm: '',
      passwordExpired: false,
      primaryMobileNumber: '',
      residentialProfileId: '',
      userDocuments: [],
      userRoles: [],
      accountDetails:new Models.AccountDetails,
      subsidizedAccountId: '',
      type: new Models.Status,
    };

    const mockToken = 'mock-jwt-token-123456';

    return of({ user: mockUser, token: mockToken }).pipe(delay(1000));
  }
}
