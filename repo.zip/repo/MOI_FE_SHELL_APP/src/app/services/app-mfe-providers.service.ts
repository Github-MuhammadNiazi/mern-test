import { DevicesConfig, Product } from '../interfaces/interfaces';
import {Injectable, InjectionToken} from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { Models } from 'shared-state';
import { NavItem } from '../interfaces/nav-item';

import { NavItemsService } from './nav-items.service';
import { Observable } from 'rxjs';
import { OrderService } from './order.service';

import { SharedService } from './shared.service';
import { Store } from '@ngrx/store';
import { UserService } from './user.service';
import { environment } from '../../environments/environment';
import { selectIsAuthenticated } from '../store/auth/auth.selectors';

export interface OtpProviderOptions {
  sendOtp?: boolean;
  redirectTo: string;                 // e.g. '/signup/register-user'
  extras?: NavigationExtras;          // optional router extras
  type?: 'popup' | 'page';

}

// (optional) typed token for the redirect target
export const OTP_REDIRECT = new InjectionToken<string>('OTP_REDIRECT');
// (optional) typed token for extras (can be omitted)
export const OTP_REDIRECT_EXTRAS = new InjectionToken<NavigationExtras>('OTP_REDIRECT_EXTRAS', {
  providedIn: 'root',
  factory: () => ({})
});

@Injectable({providedIn: 'root'})
export class AppMfeProvidersService {
  // getLoginProviders() {
  //   return [
  //     {
  //       provide: 'loginCallback',
  //       useValue: (data: any) => this.shared.loginUser(data),
  //     },
  //     {
  //       provide: APP_CFG,
  //       useValue: <ApiCfg>{
  //         apiBase: environment.API_BASE_URL,
  //         loginUrl: `${environment.API_BASE_URL}/login`,
  //       },
  //     },
  //   ];
  // }

  static getOtpProviders (opts: OtpProviderOptions) {
    const send = opts.sendOtp ?? false;
    const type = opts.type ?? 'page';

    return [
      {
        provide: 'accountNumber',
        useFactory: (shared: SharedService) => shared.msisdn,
        deps: [SharedService]
      },
      {
        provide: 'loginEmail',
        useFactory: (shared: SharedService) => shared.loginEmail,
        deps: [SharedService]
      },
      {
        provide: OTP_REDIRECT, useValue: opts.redirectTo
      },
      {
        provide: OTP_REDIRECT_EXTRAS, useValue: opts.extras ?? {}
      },
      {
        provide: 'otpVerifiedCallback',
        useFactory: (shared: SharedService) => (otp: string) => {
          shared.onOtpSuccess(otp, send, type);
        },
        deps: [SharedService, Router, OTP_REDIRECT, OTP_REDIRECT_EXTRAS]
      },
      {
        provide: 'otpFailedCallback',
        useFactory: (shared: SharedService) => (reason: string) => shared.onOtpFailure(reason),
        deps: [SharedService]
      },
      {
        provide: 'otpSendEnabled',
        useValue: send
      },
      {
        provide: 'APP_CFG',
        useValue: {
          apiBase: environment.API_BASE_URL,
          otpSendUrl: `${environment.API_BASE_URL}/${environment.OTP_SEND_ENDPOINT}`,
          otpVerifyUrl: `${environment.API_BASE_URL}/${environment.OTP_VERIFY_ENDPOINT}`,
          otpVerifyLoginUrl: `${environment.API_BASE_URL}/${environment.OTP_VERIFY_ENDPOINT_LOGIN}`,
          otpSendLoginUrl: `${environment.API_BASE_URL}/${environment.OTP_SEND_ENDPOINT_LOGIN}`,
        }
      }
    ];
  }

  static getSignupProviders () {
    return [
      {
        provide: 'setUserTypeCallback',
        useFactory: (shared : SharedService) => (isDeveloper: string) => {
          shared.setIsDeveloper(isDeveloper);
        },
        deps: [SharedService]
      },
      {
        provide: 'signupCallback',
        useFactory: (sharedService: SharedService) => (msisdn: string) => sharedService.setMsisdn(msisdn),
        deps: [SharedService]
      }
    ];
  }

  static getHeaderProviders () {
    return [
      {
        provide: 'NAV_ITEMS',
        useFactory: (svc: NavItemsService): Observable<NavItem[]> => svc.getNavItems(),
        deps: [NavItemsService]
      }
    ];
  }

  static getRegisterUserProviders () {
    return [
      {
        provide: 'registerUser',
        useFactory: (userService: UserService) => (data: Models.UserModel) => userService.registerUser(data),
        deps: [UserService]
      },
      {
        provide: 'registerDeveloper',
        useFactory: (userService: UserService) => (data: Models.UserModel) => userService.registerDeveloper(data),
        deps: [UserService]
      },
      {
        provide: 'verifyDeveloperProfile',
        useFactory: (userService: UserService) => (data: Models.UserModel) => userService.verifyDeveloperProfile(data),
        deps: [UserService]
      },
      {
        provide: 'validateEid',
        useFactory: (userService: UserService) => (id: number) => userService.validateEid(id),
        deps: [UserService]
      },
      {
        provide: 'validateEmail',
        useFactory: (userService: UserService) => (id: number) => userService.validateEmail(id),
        deps: [UserService]
      },
      {
        provide: 'onSignupSuccessCallback',
        useFactory: (sharedService: SharedService) => () => sharedService.onSignupSuccess(),
        deps: [SharedService]
      }
    ];
  }
  static getLoginProviders () {
    return [
      {
        provide: 'setUserTypeCallback',
        useFactory: (shared : SharedService) => (isDeveloper: string) => {
          shared.setIsDeveloper(isDeveloper);
        },
        deps: [SharedService]
      },
      {
        provide: 'loginCallback',
        useFactory: (shared: SharedService) => (email: string) => {
          shared.setEmail(email);
        },
        deps: [SharedService]
      }
    ];
  }
  static getPlansPageProviders () {
    return [
      {
        provide: 'getPackagesCallback',
        useFactory: (orderService: OrderService) =>
          () : Observable<Product[]> => {
            // fetch api on plans-mfe init method
            return orderService.getPackagePlans();
          },
        deps: [OrderService]
      },
      {
        provide: 'getDeviceConfigCallback',
        useFactory: (orderService: OrderService) =>
          () : Observable<DevicesConfig> => {
            // fetch api on plans-mfe init method
            return orderService.getDevicesConfig();
          },
        deps: [OrderService]
      },
      {
        provide: 'getOrderCallback',
        useFactory: (orderService: OrderService) =>
          (orderid: number) : Observable<Models.OrderModel> => {
            return orderService.getOrderByOrderid(orderid);
          },
        deps: [OrderService]
      },
      {
        provide: 'patchOrderCallback',
        useFactory: (orderService: OrderService) =>
          (order: Models.OrderModel) : Observable<Models.OrderModel> => {
            return orderService.submitOrderPatch(order);
          },
        deps: [OrderService]
      },
      {
        provide: 'postPaidEligibilityCheckCallback',
        useFactory: (sharedService: SharedService) =>
          (phoneNumber: string) => {
            return sharedService.checkPostpaidEligibilityOtpFlow(phoneNumber);
          },
        deps: [SharedService]
      },
    ];
  }
  static getGisProviders () {
    return [
      {
        provide: 'GIS_CFG',
        useValue: {
          gisGetAccessToken: `${environment.API_BASE_URL}/${environment.GIS_GET_ACCESSTOKEN}`,
          gisGetMapViewUrl: `${environment.API_BASE_URL}/${environment.GIS_GET_MAPVIEWURL}`,
          gisCreateOrderUrl: `${environment.API_BASE_URL}/${environment.CREATE_ORDER}`,
          gisGetOrderUrl: `${environment.API_BASE_URL}/${environment.GET_ORDER}`,
          gisPatchOrderUrl: `${environment.API_BASE_URL}/${environment.PATCH_ORDER}`,
        }
      },
      {
        provide: 'GIS_REDIRECT_CALLBACK',
        useFactory: (router: Router) => (orderId: string) => {
          router.navigate([`home/${orderId}/configuration`], {
            state: { fromInApp: true }
          });
        },
        deps: [Router]
      }
    ];
  }
  static getBoqProviders () {
    return [
      {
        provide: 'BOQ_CFG',
        useValue: {
          boqGetOrderQuoteUrl: `${environment.API_BASE_URL}/${environment.GET_ORDER_QUOTE}`,
          boqApplyPromoUrl: `${environment.API_BASE_URL}/${environment.APPLY_PROMO_CODE}`,
          boqProcessPaymentUrl: `${environment.API_BASE_URL}/${environment.GET_PROCESS_ORDER}`,
          boqProcessAutoPayUrl: `${environment.API_BASE_URL}/${environment.GET_PROCESS_AUTO_PAY_ORDER}`,
          boqProcessPaymentWithMethodUrl: `${environment.API_BASE_URL}/${environment.GET_PROCESS_ORDER}?paymentDay={{paymentDay}}&paymentMethodId={{paymentMethodId}}`,
          boqPaymentStatusUrl: `${environment.API_BASE_URL}/${environment.GET_PAYMENT_STATUS}`,
          boqGetOrderUrl: `${environment.API_BASE_URL}/${environment.GET_ORDER}`,
          boqGetPostpaidBillUrl: `${environment.API_BASE_URL}/${environment.GET_POSTPAID_BILL}`,
        }
      },
      {
        provide: 'authService',
        useFactory: (store: Store) => ({
          isAuthenticated$: store.select(selectIsAuthenticated)
        }),
        deps: [Store]
      },
      {
        provide: 'backRedirectCallback',
        useFactory: (router: Router) => (orderId: string) => {
          router.navigate([`/home/${orderId}/configuration`]);
        },
        deps: [Router]
      }
    ];
  }
  static getUserDashboardProviders () {
    return [
      {
        provide: 'userOrderCallback',
        useFactory: (userService: UserService) => (id: number, pageNo: number, recordsPerPage: number) => userService.getUserOrder(id, pageNo, recordsPerPage),
        deps: [UserService]
      },
      {
        provide: 'orderId',
        useFactory: (orderService: OrderService) => (id: number) => orderService.getSelectedOrderId(id),
        deps: [OrderService]
      }
    ];
  }
  static getHomeDashboardProviders () {
    return [
      {
        provide: 'orderData',
        useFactory: (orderService: OrderService) => (id: number) => orderService.getOrderById(id),
        deps: [OrderService]
      },
      {
        provide: 'quoteData',
        useFactory: (orderService: OrderService) => (id: number) => orderService.getQuotes(id),
        deps: [OrderService]
      },
      {
        provide: 'updateSecondaryPhoneNo',
        useFactory: (orderService: OrderService) => (id: number, orderData: Models.OrderModel) => orderService.updateSecondaryPhoneNo(id, orderData),
        deps: [OrderService]
      }
    ];
  }
}
