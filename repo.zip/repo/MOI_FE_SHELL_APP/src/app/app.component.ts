import {CommonModule, NgComponentOutlet} from '@angular/common';
import {Component, EnvironmentInjector, OnInit, inject} from '@angular/core';
import { Constants, HassantukLoaderComponent, TranslationService } from 'shared-state';


import { ModalService } from './services/modal-service';
import {Observable} from 'rxjs';
import { OtpPopupComponent } from './shared-comp/otp-popup/otp-popup.component';
import { OtpService } from './services/otp-modal.service';
import {SharedService} from './services/shared.service';
import { Store } from '@ngrx/store';
@Component({
  selector: 'app-root',
  imports: [CommonModule, NgComponentOutlet, HassantukLoaderComponent, OtpPopupComponent],
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  showModal = false;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  header: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  footer: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  signup: any;
  private otpMpdalSvc = inject(OtpService);
  footerInjector!: EnvironmentInjector;
  headerInjector!: EnvironmentInjector;
  translatedText$!: Observable<string>;
  lang = '';
  cmsData: unknown;

  private modalSvc = inject(ModalService);
  private sharedDataService: SharedService = inject(SharedService);
  private translationSvc: TranslationService = inject(TranslationService);
  private store = inject(Store);
  async ngOnInit () {
    this.translatedText$ = this.translationSvc.translate$('headerMainText');
    const lang = this.getLanguage();
    this.translationSvc.setLanguage(lang);

    this.otpModalSetup();
    this.translationSvc.language$.subscribe((lang: string) => {
      this.lang = lang;
      this.sharedDataService.createFooterInjector().subscribe((footerInjector: EnvironmentInjector) => {
        this.footerInjector = footerInjector;
      });
    });
    this.headerInjector = this.sharedDataService.createHeaderInjector();

    // Load MFE components
    const components = await this.sharedDataService.loadComponents();
    this.header = components.header;
    this.footer = components.footer;
  }

  getLanguage (): string {
    return localStorage.getItem('language') || Constants.languages.english; // default English
  }

  otpModalSetup () {
    this.modalSvc.showModal$.subscribe((flag) => {
      this.showModal = flag;
      if (flag) this.otpMpdalSvc.openOtp();
      else this.otpMpdalSvc.closeOtp();
    });
  }
}
