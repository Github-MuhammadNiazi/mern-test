import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { HassantukLoaderComponent } from 'shared-state';
import { SharedService } from '../../services/shared.service';

@Component({
  selector: 'app-otp-popup',
  imports: [HassantukLoaderComponent],
  templateUrl: './otp-popup.component.html',
  styleUrl: './otp-popup.component.scss'
})
export class OtpPopupComponent implements OnInit {
  @ViewChild('contentLoader') contentLoader!: HassantukLoaderComponent;
  private sharedDataSvc = inject(SharedService);

  phone = '';

  ngOnInit (): void {
    console.log("OtpPopupComponent: phone::" + this.phone + "---");
    this.phone = this.sharedDataSvc.msisdn;
  }

}
