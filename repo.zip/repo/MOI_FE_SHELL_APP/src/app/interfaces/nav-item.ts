import { NavAction } from "../core/enums/enums";

export interface NavItem {
  label: string;
  translationKey: string;
  icon?: string; // Optional icon for the nav item
  url?: string; // Static URL for navigation
  dynamicUrl?: (userId: string) => string;
  action?: NavAction;
  callback?:() => void
}
