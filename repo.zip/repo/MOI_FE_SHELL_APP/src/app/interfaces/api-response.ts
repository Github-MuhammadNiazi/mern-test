export interface ApiResponse<T> {
  status: string;
  data: T;  // can be object or array
  message: string;
  accepted: boolean;
}
