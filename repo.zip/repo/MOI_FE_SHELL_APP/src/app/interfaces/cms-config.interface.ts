export interface CmsConfig {
  url: string; // The URL or identifier for the footer configuration
  locale: string; // The locale (e.g., 'en' for English, 'ar' for Arabic)
};
