// footer.model.ts
export interface ApiResponse {
    status: string;
    data: Data;
    message: string;
    accepted: boolean;
}

export interface Data {
    locale: string | null;
    header: string | null;
    footer: Footer;
    cmsBaseUri: string;
}

export interface Footer {
    data: FooterData;
}

export interface FooterData {
    footerByPath: FooterByPath;
}

export interface FooterByPath {
    item: FooterItem;
}

export interface FooterItem {
    footerLogo: FooterLogo;
    copyrightText: string;
    footerLinks: FooterLink[];
    topIcon: TopIcon;
}

export interface FooterLogo {
    _path: string;
    linkLabel: string | null;
    iconImage: IconImage;
    linkType: string | null;
    linkUrl: string;
    linkBehavior: string | null;
}

export interface FooterLink {
    _path: string;
    linkLabel: string;
    iconImage: IconImage | null;
    linkType: string | null;
    linkUrl: string;
    linkBehavior: string;
}

export interface TopIcon {
    _path: string;
    linkLabel: string | null;
    iconImage: IconImage;
    linkType: string | null;
    linkUrl: string;
    linkBehavior: string | null;
}

export interface IconImage {
    _path: string;
}