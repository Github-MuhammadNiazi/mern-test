export interface FooterLeftSection {
  _path: string;
  linkText: string | null;
  linkUrl: string;
  linkTarget: string;
  logoImage: string | null;
}

export interface LogoImage {
  _path: string;
}

export interface FooterRightSection {
  _path: string;
  linkText: string | null;
  linkUrl: string;
  linkTarget: string;
  logoImage: LogoImage | null;
}

export interface FooterItem {
  _path: string;
  callCenterText: string;
  footerLeftSection: FooterLeftSection[];
  footerRightSection: FooterRightSection[];
  copyRightText: string;
}

export interface FooterSectionByPath {
  item: FooterItem;
}

export interface FooterData {
  footerSectionByPath: FooterSectionByPath;
}

export interface Footer {
  data: FooterData;
}

export interface Data {
  locale: string | null;
  header: string | null;
  footer: Footer | null;
  topNav: string | null;
  mainNav: string | null;
  cmsBaseUri: string;
}

export interface ApiResponse {
  status: string;
  data: Data;
  message: string;
  accepted: boolean;
}
