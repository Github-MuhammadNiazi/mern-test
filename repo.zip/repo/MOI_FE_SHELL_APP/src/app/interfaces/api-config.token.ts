import {InjectionToken} from '@angular/core';


export interface ApiCfg {
  apiBase: string;
  otpSendUrl: string;
  otpVerifyUrl: string;
  otpVerifyLoginUrl?: string;
  otpSendLoginUrl?: string;
}

export const APP_CFG = new InjectionToken<ApiCfg>('APP_CFG');
