import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import {  provideHttpClient, withInterceptors } from '@angular/common/http';
import { AuthEffects } from './store/auth/auth.effects';
import { generalInterceptor } from './core/interceptors/general.interceptor';

import { provideAuthStore } from './store/auth/auth.store';
import { provideEffects } from '@ngrx/effects';
import { provideRouter } from '@angular/router';
import { provideStore } from '@ngrx/store';
import { routes } from './app.routes';



export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(withInterceptors([generalInterceptor])),
    // GeneralInterceptor,
    provideStore(),
    provideAuthStore,
    provideEffects(AuthEffects)
  ]
};
