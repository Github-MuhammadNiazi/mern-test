import { Constants, Enums, Models } from 'shared-state';
import { createReducer, on } from '@ngrx/store';
import { AuthActions } from './auth.actions';
import { AuthState } from '../../core/models/auth.model';


export function createEmptyUser (): Models.UserModel {
  return {
    active: false,
    isPartyExists: false,
    birthDate: '',
    creationDate: '',
    documentExpiryDate: '',
    documentNumber: '',
    documentStatus: '',
    documentStatusLabelEn: '',
    documentStatusLabelAr: '',
    documentId: '',
    documentType: Enums.DocType.EmiratesID,   // or default enum value
    email: '',
    landlineNumber: '',
    firstNameEn: '',
    fistNameAr: '',
    gender: Enums.GenderTitle.Mr,
    id: 0,
    isDeveloper: false,
    isEtisalatCustomer: false,
    lastNameAr: '',
    lastNameEn: '',
    lastUpdateDate: '',
    locale: Constants.languages.english,
    locked: false,
    nationality: '',
    partyId: '',
    password: '',
    passwordConfirm: '',
    passwordExpired: false,
    primaryMobileNumber: '',
    residentialProfileId: '',
    userDocuments: [],
    userRoles: [],
    accountDetails: {} as Models.AccountDetails,
    subsidizedAccountId: '',
    type: new Models.Status,
  };
}
export const initialState: AuthState = {

  user: localStorage.getItem('user')
    ? JSON.parse(localStorage.getItem('user') as string) as Models.UserModel
    : null,  // or new UserModel() if you want an empty instance
  token: localStorage.getItem('token'),
  isAuthenticated: !!localStorage.getItem('token'),
  tempEmail: null,
  error: null,
  isEtisilatUser: false
};

const emptyAuthState: AuthState = {
  user: null,
  token: null,
  isAuthenticated: false,
  tempEmail: null,
  error: null,
  isEtisilatUser: false
};

/**
 * The `authReducer` manages authentication-related state transitions in the application.
 * It handles actions such as setting the login form type, starting login/signup flows,
 * OTP verification, login success/failure, user account details retrieval, and logout.
 *
 * ### State Transitions:
 * - **setFormType**: Updates the user object with the selected form type (individual/developer).
 * - **loginStart**: Temporarily stores the user's email and clears any previous errors.
 * - **verifyOTPSuccess**: Maintains current state on successful OTP verification.
 * - **verifyOTPFailure**: Updates the error field on OTP verification failure.
 * - **loginSuccess**: Sets the authenticated user, token, and resets temporary fields and errors.
 * - **signupStart**: Updates or creates the user object with the provided mobile number.
 * - **getUserAccountDetailsSuccess**: Merges retrieved user details and sets Etisalat user flag in signup flow.
 * - **loginFailure**: Updates the error field on login failure.
 * - **logout**: Resets the authentication state to its initial empty state.
 *
 * @see AuthActions
 * @see initialState
 * @see createEmptyUser
 * @see emptyAuthState
 */
export const authReducer = createReducer(
  initialState,

  // set Form type as individual or developer when user switches tab on login-mfe form
  on(AuthActions.setFormType, (state, { isDeveloper }) => ({
    ...state,
    user: state.user
      ? { ...state.user, isDeveloper: isDeveloper }
      : { ...createEmptyUser(), isDeveloper: isDeveloper }
  })),

  // Login start
  on(AuthActions.loginStart, (state, { email }) => ({
    ...state,
    tempEmail: email, // store email temporarily until OTP verification
    error: null
  })),

  on(AuthActions.verifyOTPSuccess, state => ({
    ...state,
  })),

  on(AuthActions.verifyOTPFailure, (state, { error }) => ({
    ...state,
    error
  })),

  // Handle Login Success
  on(AuthActions.loginSuccess, (state, { user, token }:{ user: Models.UserModel; token: string }) => ({
    ...state,
    user: user,
    token,
    isAuthenticated: true,
    tempEmail: null,
    error: null
  })),

  on(AuthActions.signupStart, (state, { msisdn }) => ({
    ...state,
    user: state.user
      ? { ...state.user, primaryMobileNumber: msisdn }
      : { ...createEmptyUser(), primaryMobileNumber: msisdn }
  })),

  // Handle getting user account details success
  on(AuthActions.getUserAccountDetailsSuccess, (state, { isEtisalatUser, user }) => ({
    ...state,
    user: user
      ? { ...state.user, ...user }
      : state.user,
    isEtisilatUser: isEtisalatUser, // store email temporarily until OTP verification
    error: null
  })),


  // Handle login failure
  on(AuthActions.loginFailure, (state, { error }) => ({
    ...state,
    error
  })),

  // Logout
  on(AuthActions.logout, () => ({
    ...emptyAuthState
  }))
);
