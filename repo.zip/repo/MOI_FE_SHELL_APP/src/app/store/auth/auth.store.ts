import { authReducer } from './auth.reducer';
import { provideState } from '@ngrx/store';

export const provideAuthStore = provideState({ name: 'auth', reducer: authReducer });
