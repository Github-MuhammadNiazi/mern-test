
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AuthState } from '../../core/models/auth.model';

export const selectAuthState = createFeatureSelector<AuthState>('auth');

// use this selector on 2 places
// 1. signupConfig resolver for signup-mfe
// 2. loginConifig resolver to decide which dashboard to navigate to later after otp sucess for login
export const selectIsDeveloper = createSelector(
  selectAuthState,
  (state) => state.user?.isDeveloper
);

// show register user form on conditional basis
export const selectIsEtisalatUser = createSelector(
  selectAuthState,
  (state) => state.isEtisilatUser
);

export const selectTempEmail = createSelector(
  selectAuthState,
  (state) => state.tempEmail
);

export const selectUser = createSelector(
  selectAuthState,
  (state) => state.user
);

export const selectToken = createSelector(
  selectAuthState,
  (state) => state.token
);

export const selectIsAuthenticated = createSelector(
  selectAuthState,
  (state) => state.isAuthenticated
);

export const selectUserId = createSelector(
  selectUser,
  (user) => user?.id
);

export const selectLoginEmail = createSelector(
  selectUser,
  (user) => user?.email
);

export const selectPhoneNumber = createSelector(
  selectUser,
  (user) => user?.primaryMobileNumber
);
