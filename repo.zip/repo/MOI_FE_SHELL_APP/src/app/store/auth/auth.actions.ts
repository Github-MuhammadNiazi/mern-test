import { createActionGroup, emptyProps, props  } from '@ngrx/store';
import { Models } from 'shared-state';

export const AuthActions = createActionGroup({
  source: 'Auth',
  events: {

    "Set Form Type": props<{isDeveloper : boolean}>(),

    // Actions related to authentication
    'Login Start': props<{ email: string }>(),

    // Login OTP flow - handle verification success and failure
    'Verify OTP Success': emptyProps(),
    'Verify OTP Failure': props<{ error: string }>(),

    'Signup Start': props<{msisdn: string}>(),
    // Signup OTP flow - handle otp verfication success and failure on signup case
    'Verify Signup OTP Success': props<{otp: number}>(),
    'Verify Signup OTP Failure': props<{ error: string }>(),

    // check if etisilat user or not
    'Get User By Account Number': props<{accountNumber: string, otp: string}>(),

    // if success and user is not empty - means isEtisilat user else not - show signup form accordingly
    'Get User Account Details Success': props<{isEtisalatUser: boolean, user: Models.UserModel}>(),
    'Get User Account Details Failure':  props<{ error: string }>(),

    // Final login API
    'Login': props<{ email: string }>(),
    'Login Success': props<{ user: Models.UserModel; token: string }>(),
    'Login Failure': props<{ error: string }>(),

    // Logout
    'Logout': emptyProps(),
  },
});
