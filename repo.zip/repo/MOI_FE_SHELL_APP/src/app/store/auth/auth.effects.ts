import { Actions, createEffect, ofType } from "@ngrx/effects";

import { Injectable, inject } from "@angular/core";
import { catchError ,map, of, switchMap, tap } from "rxjs";

import { AuthActions } from "./auth.actions";
import { AuthService } from "../../services/auth.service";
import { Models } from "shared-state";
import { Router } from "@angular/router";
import { SessionStorageService } from '../../services/local-storage.service';
import { UserService } from "../../services/user.service";

@Injectable()
export class AuthEffects {
  loginAfterOtp$;
  loginSuccessNavigate$;
  getUserAccountDetails$;
  registerUserFormNavigate$;
  logout$;

  private router = inject(Router);
  private actions$ = inject(Actions);
  private authService = inject(AuthService);
  private userService = inject(UserService);
  private sessionStorageSvc: SessionStorageService = inject(SessionStorageService);

  constructor () {
    // Auto-login after OTP success
    this.loginAfterOtp$ = createEffect(() =>
      this.actions$.pipe(
        ofType(AuthActions.verifyOTPSuccess),
        switchMap(() =>
          // this.authService.login().pipe(
          this.userService.getCurrentUser().pipe(
            map(({ user, token }: { user: Models.UserModel; token: string }) => {
              return AuthActions.loginSuccess({ user, token });
            }),
            catchError((error) => {
              console.error('Error during login:', error);
              return of(AuthActions.loginFailure({ error }));
            })
          )
        )
      )
    );


    // Get user account details by account number and verified otp to check if it is etisalat user
    this.getUserAccountDetails$ = createEffect(() =>
      this.actions$.pipe(
        ofType(AuthActions.getUserByAccountNumber),
        switchMap((action) =>
          this.authService.getUserByAccountNo(action.accountNumber, action.otp).pipe(
            map((response) => {
              const user = response.data as Models.UserModel || null;
              if(user){
                return AuthActions.getUserAccountDetailsSuccess({isEtisalatUser: true, user});
              }
              else {
                return AuthActions.getUserAccountDetailsSuccess({isEtisalatUser: false, user});
              }
            }),
            catchError((error) => of(AuthActions.getUserAccountDetailsFailure({ error })))
          )
        )
      )
    );

    // Navigate to dashboard on login success
    this.loginSuccessNavigate$ = createEffect(
      () =>
        this.actions$.pipe(
          ofType(AuthActions.loginSuccess),
          tap(({  user, token }) => {
            localStorage.setItem('token', token);
            localStorage.setItem('user', JSON.stringify(user));
            const id = user.id;
            if(this.sessionStorageSvc.getPreLoginOrder())
              this.router.navigate([`home/location`]);
            else
              this.router.navigate([`/user/${id}/dashboard`]);
          })
        ),
      { dispatch: false }
    );

    // Navigate to register user form i.e signup-mfe
    this.registerUserFormNavigate$ = createEffect(
      () =>
        this.actions$.pipe(
          ofType(AuthActions.getUserAccountDetailsSuccess),
          tap(({user}) => {
            localStorage.setItem('user', JSON.stringify(user));
            sessionStorage.setItem('fromInApp', 'true');
            this.router.navigate([`/signup/register-user`]);
          })
        ),
      { dispatch: false }
    );

    this.logout$ = createEffect(
      () =>
        this.actions$.pipe(
          ofType(AuthActions.logout),
          tap(() => {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            this.router.navigate(['/login']);
          })
        ),
      { dispatch: false }
    );
  }
}
