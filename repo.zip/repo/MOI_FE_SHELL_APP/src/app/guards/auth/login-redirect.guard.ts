
import { CanActivate, Router } from "@angular/router";
import { Injectable, inject  } from "@angular/core";
import { Observable, map, take, tap,  } from "rxjs";
import { selectIsAuthenticated, selectUserId } from "../../store/auth/auth.selectors";

import { Store } from "@ngrx/store";

@Injectable({ providedIn: 'root' })
export class LoginRedirectGuard implements CanActivate {
  private store = inject(Store);
  private router = inject(Router);

  /**
     * Guard to redirect authenticated users away from the login page.
     * If the user is authenticated, they are redirected to their dashboard.
     * If not authenticated, they can access the login page.
     */
  canActivate (): Observable<boolean> {
    return this.store.select(selectIsAuthenticated).pipe(
      take(1),
      tap(isAuth => {
        if (isAuth) {
          this.store.select(selectUserId).pipe(take(1)).subscribe(userId => {
            this.router.navigate([`/user/${userId}/dashboard`]);
          });
        }
      }),
      map(isAuth => !isAuth) // only allow login page if not authenticated
    );
  }
}
