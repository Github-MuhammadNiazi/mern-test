
import { CanActivate, Router } from "@angular/router";
import { Injectable, inject } from "@angular/core";
import { Observable, take, tap } from "rxjs";

import { Store } from "@ngrx/store";
import { selectIsAuthenticated } from "../../../public-api";

@Injectable({ providedIn: 'root' })
export class DashboardGuard implements CanActivate {
  private store = inject(Store);
  private router = inject(Router);

  /**
   * Guard to check if the user is authenticated before accessing the dashboard.
   * If not authenticated, redirects to the login page.
  */
  canActivate (): Observable<boolean> {
    return this.store.select(selectIsAuthenticated).pipe(
      take(1),
      tap(isAuth => {
        if (!isAuth) {
          console.warn('Access denied - User not authenticated');
          this.router.navigate(['/login']); // go back to login if not logged in
        }
      })
    );
  }
}
