import { ActivatedRouteSnapshot, CanActivateFn, Router, RouterStateSnapshot } from '@angular/router';
import { inject } from '@angular/core';

/**
 * Guard to control navigation to login and signup routes based on session state.
 *
 * - Always allows access to the base `/login` and `/signup` pages.
 * - For routes starting with `/login` or `/signup`, checks if the user navigated from within the app
 *   (by verifying the `fromInApp` flag in sessionStorage).
 *   - If `fromInApp` is `true`, allows navigation.
 *   - Otherwise, redirects to the respective base route.
 * - Removes the `fromInApp` flag from sessionStorage after checking.
 * - Allows navigation for all other routes.
 *
 * @param _route The activated route snapshot.
 * @param state The router state snapshot.
 * @returns `true` if navigation is allowed, or a `UrlTree` to redirect otherwise.
 */
export const OtpStepGuard: CanActivateFn = (
  _route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
) => {
  const router = inject(Router);

  // Always allow base login and signup pages
  if (state.url === '/login' || state.url === '/signup') return true;

  const fromContinue = sessionStorage.getItem('fromInApp') === 'true';

  // Clear after use immediately
  sessionStorage.removeItem('fromInApp');

  if (state.url.startsWith('/login')) {
    return fromContinue ? true : router.createUrlTree(['/login']);
  }

  if (state.url.startsWith('/signup')) {
    return fromContinue ? true : router.createUrlTree(['/signup']);
  }

  // True for all other routes without restrictions
  return true;
};
