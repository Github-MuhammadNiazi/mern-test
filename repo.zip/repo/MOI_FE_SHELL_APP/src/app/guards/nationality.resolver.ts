/* eslint-disable */
import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from '../services/user.service';

@Injectable({ providedIn: 'root' })
export class NationalityResolver implements Resolve<any> {
  constructor(private userService: UserService) {}

  resolve(): Observable<any> | Promise<any> | any {
    return this.userService.getNationality();
  }
}