const API_VERSION = 'v1';
const PUBLIC_API = `api/${API_VERSION}/p`;
const SECURE_API = `api/${API_VERSION}/s`;


export const environment = {
  production: false,
  // MFE REMOTE URLS
  remotes: {
    MFE_HEADER_URL: 'https://header-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_FOOTER_URL: 'https://footer-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_LOGIN_URL: 'https://login-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_SIGNUP_URL: 'https://signup-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_OTP_URL: 'https://otp-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_USER_DASHBOARD_URL: 'https://user-dashboard-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_ERROR_PAGE_URL: 'http://localhost:4338/remoteEntry.json',
    MFE_HOME_DASHBOARD_URL: 'https://home-dashboard-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_PLANS_URL: 'https://plans-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/remoteEntry.json',
    MFE_GIS_MODULE_URL: 'https://localhost:4336/remoteEntry.json',
    MFE_BOQ_URL: 'http://localhost:4337/remoteEntry.json'
  },
  API_BASE_URL: 'https://firealarm-hassantuk-dev.apps.ocpnonprodau02.etisalat.corp.ae/moi-web',
  //cms-endpoint
  CMS_ENDPOINT: `${PUBLIC_API}/cms`,

  //auth-endpoints
  OTP_SEND_ENDPOINT_LOGIN: `${PUBLIC_API}/auth/send-otp-for-login`,
  OTP_VERIFY_ENDPOINT_LOGIN: `${PUBLIC_API}/auth/verify-otp-for-login`,

  //register-endpoints
  OTP_VERIFY_ENDPOINT: `${PUBLIC_API}/register/verifyotp`,
  OTP_SEND_ENDPOINT: `${PUBLIC_API}/register/sendotp`,
  REGISTER_USER_ENDPOINT: `${PUBLIC_API}/register/user`,
  REGISTER_DEVELOPER_ENDPOINT: `${PUBLIC_API}/register/registerDeveloper`,
  VERIFY_DEVELOPER_ENDPOINT: `${PUBLIC_API}/register/verifyDeveloperProfile`,
  VALIDATE_EID_ENDPOINT: `${PUBLIC_API}/register/user/validateEid`,
  CHECK_USER_EXISTS_ENDPOINT: `${PUBLIC_API}/register/user/exist`,


  //Plans and pakages endpoints
  GET_PACKAGES_ENDPOINT: `${PUBLIC_API}/packages`,
  GET_DEVICES_CONFIG: `${PUBLIC_API}/devicesConfig`,

  ORDER :`${SECURE_API}/order`,
  POST_PAID_ELIGIBILITY_CHECK: `${SECURE_API}/user/postPaidEligibilityCheck`,

  POST_PAID_ELIGIBILITY_CHECK_PUBLIC: `${PUBLIC_API}/register/postPaidEligibilityCheck`,

  //order-endpoints
  GIS_GET_ACCESSTOKEN: `${SECURE_API}/order/home/gis/token`,
  GIS_GET_MAPVIEWURL: `${SECURE_API}/order/home/gis/mapviewerurl`,
  GET_ORDER: `${SECURE_API}/order/{{orderId}}`,
  PATCH_ORDER: `${SECURE_API}/order/{{orderId}}`,
  CREATE_ORDER: `${SECURE_API}/order/create`,
  GET_ORDER_QUOTE: `${SECURE_API}/order/{{orderId}}/quote`,
  APPLY_PROMO_CODE: `${SECURE_API}/order/{{orderId}}/applypromocode/`,
  GET_PROCESS_ORDER: `${SECURE_API}/order/{{orderId}}/process`,
  GET_PROCESS_AUTO_PAY_ORDER: `${SECURE_API}/order/{{orderId}}/process-auto-pay`,
  GET_PAYMENT_STATUS: `${SECURE_API}/order/{{orderId}}/payment-status`,
  GET_POSTPAID_BILL: `${PUBLIC_API}/order/postpaid/bill`,

  DEFAULT_CONFIG: 'moi-uat',
  API_DEV_NEW:'https://devnew-sfas.etisalat.ae',
};
