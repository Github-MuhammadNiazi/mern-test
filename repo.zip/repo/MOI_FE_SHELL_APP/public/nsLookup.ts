export const nsLookup = [
    {
        "Nationality": "United Kingdom",
        "EIDA_READER_CODE": "GBR",
        "PASSPORT_READER_CODE": "GBR",
        "SEGMENT_VALUE_ID": 526
    },
    {
        "Nationality": "Unserviced Destn.",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 527
    },
    {
        "Nationality": "Uruguay",
        "EIDA_READER_CODE": "URY",
        "PASSPORT_READER_CODE": "URY",
        "SEGMENT_VALUE_ID": 528
    },
    {
        "Nationality": "Uzbekistan",
        "EIDA_READER_CODE": "UZB",
        "PASSPORT_READER_CODE": "UZB",
        "SEGMENT_VALUE_ID": 529
    },
    {
        "Nationality": "Vanuatu",
        "EIDA_READER_CODE": "VUT",
        "PASSPORT_READER_CODE": "VUT",
        "SEGMENT_VALUE_ID": 530
    },
    {
        "Nationality": "Holy See (Vatican)",
        "EIDA_READER_CODE": "VAT",
        "PASSPORT_READER_CODE": "VAT",
        "SEGMENT_VALUE_ID": 531
    },
    {
        "Nationality": "Venda",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 532
    },
    {
        "Nationality": "Venezuela",
        "EIDA_READER_CODE": "VEN",
        "PASSPORT_READER_CODE": "VEN",
        "SEGMENT_VALUE_ID": 533
    },
    {
        "Nationality": "Vietnam",
        "EIDA_READER_CODE": "VNM",
        "PASSPORT_READER_CODE": "VNM",
        "SEGMENT_VALUE_ID": 534
    },
    {
        "Nationality": "Virgin Islands",
        "EIDA_READER_CODE": "VIR",
        "PASSPORT_READER_CODE": "VIR",
        "SEGMENT_VALUE_ID": 535
    },
    {
        "Nationality": "Virgin Isl. (Brit)",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 536
    },
    {
        "Nationality": "Wake Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 537
    },
    {
        "Nationality": "Wallis and Futuna",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 538
    },
    {
        "Nationality": "Yemen",
        "EIDA_READER_CODE": "YEM",
        "PASSPORT_READER_CODE": "YEM",
        "SEGMENT_VALUE_ID": 539
    },
    {
        "Nationality": "Yemen People Dem.Rep",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 540
    },
    {
        "Nationality": "Yugoslavia",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 541
    },
    {
        "Nationality": "Zaire",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 542
    },
    {
        "Nationality": "Zambia",
        "EIDA_READER_CODE": "ZMB",
        "PASSPORT_READER_CODE": "ZMB",
        "SEGMENT_VALUE_ID": 543
    },
    {
        "Nationality": "Zimbabwe",
        "EIDA_READER_CODE": "ZWE",
        "PASSPORT_READER_CODE": "ZWE",
        "SEGMENT_VALUE_ID": 544
    },
    {
        "Nationality": "South Sudan",
        "EIDA_READER_CODE": "SSD",
        "PASSPORT_READER_CODE": "SSD",
        "SEGMENT_VALUE_ID": 880
    },
    {
        "Nationality": "Kosovo",
        "EIDA_READER_CODE": "RKS",
        "PASSPORT_READER_CODE": "UNK",
        "SEGMENT_VALUE_ID": 1240
    },
    {
        "Nationality": "Montenegro",
        "EIDA_READER_CODE": "MNE",
        "PASSPORT_READER_CODE": "MNE",
        "SEGMENT_VALUE_ID": 1241
    },
    {
        "Nationality": "Serbia",
        "EIDA_READER_CODE": "SRB",
        "PASSPORT_READER_CODE": "SRB",
        "SEGMENT_VALUE_ID": 1242
    },
    {
        "Nationality": "U S Minor Outlying Isl.",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 1243
    },
    {
        "Nationality": "Timor-Leste",
        "EIDA_READER_CODE": "TLS",
        "PASSPORT_READER_CODE": "TLS",
        "SEGMENT_VALUE_ID": 1244
    },
    {
        "Nationality": "Svalbard and Jan Mayen",
        "EIDA_READER_CODE": "SJM",
        "PASSPORT_READER_CODE": "SJM",
        "SEGMENT_VALUE_ID": 1245
    },
    {
        "Nationality": "Serbia and Montenegro",
        "EIDA_READER_CODE": "SCG",
        "PASSPORT_READER_CODE": "SCG",
        "SEGMENT_VALUE_ID": 1246
    },
    {
        "Nationality": "Myanmar",
        "EIDA_READER_CODE": "MMR",
        "PASSPORT_READER_CODE": "MMR",
        "SEGMENT_VALUE_ID": 1247
    },
    {
        "Nationality": "LIBYA",
        "EIDA_READER_CODE": "LBY",
        "PASSPORT_READER_CODE": "LBY",
        "SEGMENT_VALUE_ID": 1248
    },
    {
        "Nationality": "Brit. Indian Ocean Terr.",
        "EIDA_READER_CODE": "IOT",
        "PASSPORT_READER_CODE": "IOT",
        "SEGMENT_VALUE_ID": 1249
    },
    {
        "Nationality": "French Guiana",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 1250
    },
    {
        "Nationality": "Heard and McDonald Isl.",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 1251
    },
    {
        "Nationality": "Western Sahara",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 1252
    },
    {
        "Nationality": "Congo",
        "EIDA_READER_CODE": "COG",
        "PASSPORT_READER_CODE": "COG",
        "SEGMENT_VALUE_ID": 1253
    },
    {
        "Nationality": "Cote dlvoire",
        "EIDA_READER_CODE": "CIV",
        "PASSPORT_READER_CODE": "CIV",
        "SEGMENT_VALUE_ID": 1254
    },
    {
        "Nationality": "Bouvet Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 1255
    },
    {
        "Nationality": "Central African Republic",
        "EIDA_READER_CODE": "CAF",
        "PASSPORT_READER_CODE": "CAF",
        "SEGMENT_VALUE_ID": 1256
    },
    {
        "Nationality": "Belarus",
        "EIDA_READER_CODE": "BLR",
        "PASSPORT_READER_CODE": "BLR",
        "SEGMENT_VALUE_ID": 1257
    },
    {
        "Nationality": "Antarctica",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 1258
    },
    {
        "Nationality": "Sao Tome and Principe",
        "EIDA_READER_CODE": "STP",
        "PASSPORT_READER_CODE": "STP",
        "SEGMENT_VALUE_ID": 1320
    },
    {
        "Nationality": "TUVALU",
        "EIDA_READER_CODE": "TUV",
        "PASSPORT_READER_CODE": "TUV",
        "SEGMENT_VALUE_ID": 269801335
    },
    {
        "Nationality": "MACAU",
        "EIDA_READER_CODE": "MAC",
        "PASSPORT_READER_CODE": "MAC",
        "SEGMENT_VALUE_ID": 269801336
    },
    {
        "Nationality": "Albania",
        "EIDA_READER_CODE": "ALB",
        "PASSPORT_READER_CODE": "ALB",
        "SEGMENT_VALUE_ID": 279
    },
    {
        "Nationality": "Guatemala",
        "EIDA_READER_CODE": "GTM",
        "PASSPORT_READER_CODE": "GTM",
        "SEGMENT_VALUE_ID": 368
    },
    {
        "Nationality": "Liberia",
        "EIDA_READER_CODE": "LBR",
        "PASSPORT_READER_CODE": "LBR",
        "SEGMENT_VALUE_ID": 416
    },
    {
        "Nationality": "Expat Arabs",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 715
    },
    {
        "Nationality": "Expat Asians",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 716
    },
    {
        "Nationality": "GCC National",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 717
    },
    {
        "Nationality": "Westerners",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 718
    },
    {
        "Nationality": "Iran, Islamic Republic of",
        "EIDA_READER_CODE": "IRN",
        "PASSPORT_READER_CODE": "IRN",
        "SEGMENT_VALUE_ID": 1360
    },
    {
        "Nationality": "South Korea, Republic of",
        "EIDA_READER_CODE": "KOR",
        "PASSPORT_READER_CODE": "KOR",
        "SEGMENT_VALUE_ID": 1361
    },
    {
        "Nationality": "Palestine, State of",
        "EIDA_READER_CODE": "PSE",
        "PASSPORT_READER_CODE": "PSE",
        "SEGMENT_VALUE_ID": 1362
    },
    {
        "Nationality": "Honduras",
        "EIDA_READER_CODE": "HND",
        "PASSPORT_READER_CODE": "HND",
        "SEGMENT_VALUE_ID": 373
    },
    {
        "Nationality": "Japan",
        "EIDA_READER_CODE": "JPN",
        "PASSPORT_READER_CODE": "JPN",
        "SEGMENT_VALUE_ID": 400
    },
    {
        "Nationality": "Liechtenstein",
        "EIDA_READER_CODE": "LIE",
        "PASSPORT_READER_CODE": "LIE",
        "SEGMENT_VALUE_ID": 418
    },
    {
        "Nationality": "Mauritius",
        "EIDA_READER_CODE": "MUS",
        "PASSPORT_READER_CODE": "MUS",
        "SEGMENT_VALUE_ID": 433
    },
    {
        "Nationality": "Portugal",
        "EIDA_READER_CODE": "PRT",
        "PASSPORT_READER_CODE": "PRT",
        "SEGMENT_VALUE_ID": 467
    },
    {
        "Nationality": "Slovenia",
        "EIDA_READER_CODE": "SVN",
        "PASSPORT_READER_CODE": "SVN",
        "SEGMENT_VALUE_ID": 487
    },
    {
        "Nationality": "Austria",
        "EIDA_READER_CODE": "AUT",
        "PASSPORT_READER_CODE": "AUT",
        "SEGMENT_VALUE_ID": 291
    },
    {
        "Nationality": "Brunei Darussalam",
        "EIDA_READER_CODE": "BRN",
        "PASSPORT_READER_CODE": "BRN",
        "SEGMENT_VALUE_ID": 307
    },
    {
        "Nationality": "Taiwan",
        "EIDA_READER_CODE": "TWN",
        "PASSPORT_READER_CODE": "TWN",
        "SEGMENT_VALUE_ID": 505
    },
    {
        "Nationality": "Bouvet Island",
        "EIDA_READER_CODE": "BVT",
        "PASSPORT_READER_CODE": "BVT",
        "SEGMENT_VALUE_ID": 273309844
    },
    {
        "Nationality": "Faroe Islands",
        "EIDA_READER_CODE": "FRO",
        "PASSPORT_READER_CODE": "FRO",
        "SEGMENT_VALUE_ID": 273309845
    },
    {
        "Nationality": "Western Sahara",
        "EIDA_READER_CODE": "ESH",
        "PASSPORT_READER_CODE": "ESH",
        "SEGMENT_VALUE_ID": 273309846
    },
    {
        "Nationality": "Virgin Islands, British",
        "EIDA_READER_CODE": "VGB",
        "PASSPORT_READER_CODE": "VGB",
        "SEGMENT_VALUE_ID": 273309847
    },
    {
        "Nationality": "Antarctica",
        "EIDA_READER_CODE": "ATA",
        "PASSPORT_READER_CODE": "ATA",
        "SEGMENT_VALUE_ID": 273309848
    },
    {
        "Nationality": "Saint Pierre and Miquelon",
        "EIDA_READER_CODE": "SPM",
        "PASSPORT_READER_CODE": "SPM",
        "SEGMENT_VALUE_ID": 273309849
    },
    {
        "Nationality": "Mayotte",
        "EIDA_READER_CODE": "MYT",
        "PASSPORT_READER_CODE": "MYT",
        "SEGMENT_VALUE_ID": 273309850
    },
    {
        "Nationality": "Cayman Islands",
        "EIDA_READER_CODE": "CYM",
        "PASSPORT_READER_CODE": "CYM",
        "SEGMENT_VALUE_ID": 273309851
    },
    {
        "Nationality": "Guam",
        "EIDA_READER_CODE": "GUM",
        "PASSPORT_READER_CODE": "GUM",
        "SEGMENT_VALUE_ID": 273309852
    },
    {
        "Nationality": "Christmas Island",
        "EIDA_READER_CODE": "CXR",
        "PASSPORT_READER_CODE": "CXR",
        "SEGMENT_VALUE_ID": 273309853
    },
    {
        "Nationality": "Cocos (Keeling) Islands",
        "EIDA_READER_CODE": "CCK",
        "PASSPORT_READER_CODE": "CCK",
        "SEGMENT_VALUE_ID": 273309854
    },
    {
        "Nationality": "Kiribati",
        "EIDA_READER_CODE": "KIR",
        "PASSPORT_READER_CODE": "KIR",
        "SEGMENT_VALUE_ID": 273309855
    },
    {
        "Nationality": "Heard and McDonald Isl.",
        "EIDA_READER_CODE": "HMD",
        "PASSPORT_READER_CODE": "HMD",
        "SEGMENT_VALUE_ID": 273309856
    },
    {
        "Nationality": "U S Minor Outlying Isl.",
        "EIDA_READER_CODE": "UMI",
        "PASSPORT_READER_CODE": "UMI",
        "SEGMENT_VALUE_ID": 273309857
    },
    {
        "Nationality": "Cape Verde",
        "EIDA_READER_CODE": "CPV",
        "PASSPORT_READER_CODE": "CPV",
        "SEGMENT_VALUE_ID": 317
    },
    {
        "Nationality": "INMARSAT AOR-E",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 675
    },
    {
        "Nationality": "INMARSAT SVC-A POR",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 687
    },
    {
        "Nationality": "INMARSAT SVC-M POR",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 686
    },
    {
        "Nationality": "INMARSAT SVC-A AOR-W",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 685
    },
    {
        "Nationality": "INMARSAT SVC-B IOR",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 684
    },
    {
        "Nationality": "INMARSAT SVC-A AOR-E",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 683
    },
    {
        "Nationality": "INMARSAT SVC-M AOR-W",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 682
    },
    {
        "Nationality": "INMARSAT SVC-M IOR",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 681
    },
    {
        "Nationality": "INMARSAT AERO POR",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 680
    },
    {
        "Nationality": "INMARSAT AOR-W",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 679
    },
    {
        "Nationality": "NMARSAT SVC-M AOR-E",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 678
    },
    {
        "Nationality": "INMARSAT AERO IOR",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 677
    },
    {
        "Nationality": "INMARSAT SVC-A IOR",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 676
    },
    {
        "Nationality": "INMARSAT SVC-M AOR-E",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 755
    },
    {
        "Nationality": "BEDOON",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 756
    },
    {
        "Nationality": "Federated States of Micronesia",
        "EIDA_READER_CODE": "FSM",
        "PASSPORT_READER_CODE": "FSM",
        "SEGMENT_VALUE_ID": 1340
    },
    {
        "Nationality": "Israel",
        "EIDA_READER_CODE": "ISR",
        "PASSPORT_READER_CODE": "ISR",
        "SEGMENT_VALUE_ID": 270891166
    },
    {
        "Nationality": "Republic of Equatorial Guinea",
        "EIDA_READER_CODE": "GNQ",
        "PASSPORT_READER_CODE": "GNQ",
        "SEGMENT_VALUE_ID": 272083185
    },
    {
        "Nationality": "Lao Peoples Democratic Republic",
        "EIDA_READER_CODE": "LAO",
        "PASSPORT_READER_CODE": "LAO",
        "SEGMENT_VALUE_ID": 272083186
    },
    {
        "Nationality": "Bosnia and Herzegovina",
        "EIDA_READER_CODE": "BIH",
        "PASSPORT_READER_CODE": "BIH",
        "SEGMENT_VALUE_ID": 735
    },
    {
        "Nationality": "Benin",
        "EIDA_READER_CODE": "BEN",
        "PASSPORT_READER_CODE": "BEN",
        "SEGMENT_VALUE_ID": 300
    },
    {
        "Nationality": "Brazil",
        "EIDA_READER_CODE": "BRA",
        "PASSPORT_READER_CODE": "BRA",
        "SEGMENT_VALUE_ID": 306
    },
    {
        "Nationality": "Burundi",
        "EIDA_READER_CODE": "BDI",
        "PASSPORT_READER_CODE": "BDI",
        "SEGMENT_VALUE_ID": 311
    },
    {
        "Nationality": "Malta",
        "EIDA_READER_CODE": "MLT",
        "PASSPORT_READER_CODE": "MLT",
        "SEGMENT_VALUE_ID": 428
    },
    {
        "Nationality": "Mexico",
        "EIDA_READER_CODE": "MEX",
        "PASSPORT_READER_CODE": "MEX",
        "SEGMENT_VALUE_ID": 435
    },
    {
        "Nationality": "Morocco",
        "EIDA_READER_CODE": "MAR",
        "PASSPORT_READER_CODE": "MAR",
        "SEGMENT_VALUE_ID": 442
    },
    {
        "Nationality": "Netherlands",
        "EIDA_READER_CODE": "NLD",
        "PASSPORT_READER_CODE": "NLD",
        "SEGMENT_VALUE_ID": 447
    },
    {
        "Nationality": "Norway",
        "EIDA_READER_CODE": "NOR",
        "PASSPORT_READER_CODE": "NOR",
        "SEGMENT_VALUE_ID": 455
    },
    {
        "Nationality": "Panama",
        "EIDA_READER_CODE": "PAN",
        "PASSPORT_READER_CODE": "PAN",
        "SEGMENT_VALUE_ID": 460
    },
    {
        "Nationality": "Philippines",
        "EIDA_READER_CODE": "PHL",
        "PASSPORT_READER_CODE": "PHL",
        "SEGMENT_VALUE_ID": 464
    },
    {
        "Nationality": "Qatar",
        "EIDA_READER_CODE": "QAT",
        "PASSPORT_READER_CODE": "QAT",
        "SEGMENT_VALUE_ID": 470
    },
    {
        "Nationality": "Saudi Arabia",
        "EIDA_READER_CODE": "SAU",
        "PASSPORT_READER_CODE": "SAU",
        "SEGMENT_VALUE_ID": 481
    },
    {
        "Nationality": "Singapore",
        "EIDA_READER_CODE": "SGP",
        "PASSPORT_READER_CODE": "SGP",
        "SEGMENT_VALUE_ID": 485
    },
    {
        "Nationality": "Somalia",
        "EIDA_READER_CODE": "SOM",
        "PASSPORT_READER_CODE": "SOM",
        "SEGMENT_VALUE_ID": 489
    },
    {
        "Nationality": "Sudan",
        "EIDA_READER_CODE": "SDN",
        "PASSPORT_READER_CODE": "SDN",
        "SEGMENT_VALUE_ID": 499
    },
    {
        "Nationality": "Cayman Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 320
    },
    {
        "Nationality": "Central African Rep.",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 321
    },
    {
        "Nationality": "Chad",
        "EIDA_READER_CODE": "TCD",
        "PASSPORT_READER_CODE": "TCD",
        "SEGMENT_VALUE_ID": 322
    },
    {
        "Nationality": "Chile",
        "EIDA_READER_CODE": "CHL",
        "PASSPORT_READER_CODE": "CHL",
        "SEGMENT_VALUE_ID": 323
    },
    {
        "Nationality": "China",
        "EIDA_READER_CODE": "CHN",
        "PASSPORT_READER_CODE": "CHN",
        "SEGMENT_VALUE_ID": 324
    },
    {
        "Nationality": "Christmas Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 325
    },
    {
        "Nationality": "Cocos-Keeling Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 326
    },
    {
        "Nationality": "Colombia",
        "EIDA_READER_CODE": "COL",
        "PASSPORT_READER_CODE": "COL",
        "SEGMENT_VALUE_ID": 327
    },
    {
        "Nationality": "Comoros",
        "EIDA_READER_CODE": "COM",
        "PASSPORT_READER_CODE": "COM",
        "SEGMENT_VALUE_ID": 328
    },
    {
        "Nationality": "Democratic Rep. of Congo",
        "EIDA_READER_CODE": "COD",
        "PASSPORT_READER_CODE": "COD",
        "SEGMENT_VALUE_ID": 329
    },
    {
        "Nationality": "Cook Islands",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 330
    },
    {
        "Nationality": "Costa Rica",
        "EIDA_READER_CODE": "CRI",
        "PASSPORT_READER_CODE": "CRI",
        "SEGMENT_VALUE_ID": 331
    },
    {
        "Nationality": "Croatia",
        "EIDA_READER_CODE": "HRV",
        "PASSPORT_READER_CODE": "HRV",
        "SEGMENT_VALUE_ID": 332
    },
    {
        "Nationality": "Cuba",
        "EIDA_READER_CODE": "CUB",
        "PASSPORT_READER_CODE": "CUB",
        "SEGMENT_VALUE_ID": 333
    },
    {
        "Nationality": "Cyprus",
        "EIDA_READER_CODE": "CYP",
        "PASSPORT_READER_CODE": "CYP",
        "SEGMENT_VALUE_ID": 334
    },
    {
        "Nationality": "Czech Republic",
        "EIDA_READER_CODE": "CZE",
        "PASSPORT_READER_CODE": "CZE",
        "SEGMENT_VALUE_ID": 335
    },
    {
        "Nationality": "Denmark",
        "EIDA_READER_CODE": "DNK",
        "PASSPORT_READER_CODE": "DNK",
        "SEGMENT_VALUE_ID": 336
    },
    {
        "Nationality": "Diego Garcia",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 337
    },
    {
        "Nationality": "Djibouti",
        "EIDA_READER_CODE": "DJI",
        "PASSPORT_READER_CODE": "DJI",
        "SEGMENT_VALUE_ID": 338
    },
    {
        "Nationality": "Dom.Rep/Trin.andTobago",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 339
    },
    {
        "Nationality": "Dominica",
        "EIDA_READER_CODE": "DMA",
        "PASSPORT_READER_CODE": "DMA",
        "SEGMENT_VALUE_ID": 340
    },
    {
        "Nationality": "Dominican Republic",
        "EIDA_READER_CODE": "DOM",
        "PASSPORT_READER_CODE": "DOM",
        "SEGMENT_VALUE_ID": 341
    },
    {
        "Nationality": "Ecuador",
        "EIDA_READER_CODE": "ECU",
        "PASSPORT_READER_CODE": "ECU",
        "SEGMENT_VALUE_ID": 342
    },
    {
        "Nationality": "Egypt",
        "EIDA_READER_CODE": "EGY",
        "PASSPORT_READER_CODE": "EGY",
        "SEGMENT_VALUE_ID": 343
    },
    {
        "Nationality": "El Salvador",
        "EIDA_READER_CODE": "SLV",
        "PASSPORT_READER_CODE": "SLV",
        "SEGMENT_VALUE_ID": 344
    },
    {
        "Nationality": "Equatorial Guinea",
        "EIDA_READER_CODE": "GNQ",
        "PASSPORT_READER_CODE": "GNQ",
        "SEGMENT_VALUE_ID": 345
    },
    {
        "Nationality": "Eritrea",
        "EIDA_READER_CODE": "ERI",
        "PASSPORT_READER_CODE": "ERI",
        "SEGMENT_VALUE_ID": 346
    },
    {
        "Nationality": "Estonia",
        "EIDA_READER_CODE": "EST",
        "PASSPORT_READER_CODE": "EST",
        "SEGMENT_VALUE_ID": 347
    },
    {
        "Nationality": "Ethiopia",
        "EIDA_READER_CODE": "ETH",
        "PASSPORT_READER_CODE": "ETH",
        "SEGMENT_VALUE_ID": 348
    },
    {
        "Nationality": "Falkland Islands",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 349
    },
    {
        "Nationality": "Faroe Islands",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 350
    },
    {
        "Nationality": "Fiji",
        "EIDA_READER_CODE": "FJI",
        "PASSPORT_READER_CODE": "FJI",
        "SEGMENT_VALUE_ID": 351
    },
    {
        "Nationality": "Finland",
        "EIDA_READER_CODE": "FIN",
        "PASSPORT_READER_CODE": "FIN",
        "SEGMENT_VALUE_ID": 352
    },
    {
        "Nationality": "France",
        "EIDA_READER_CODE": "FRA",
        "PASSPORT_READER_CODE": "FRA",
        "SEGMENT_VALUE_ID": 353
    },
    {
        "Nationality": "French Guyana",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 354
    },
    {
        "Nationality": "French Polynesia",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 355
    },
    {
        "Nationality": "Gabon",
        "EIDA_READER_CODE": "GAB",
        "PASSPORT_READER_CODE": "GAB",
        "SEGMENT_VALUE_ID": 356
    },
    {
        "Nationality": "Gambia",
        "EIDA_READER_CODE": "GMB",
        "PASSPORT_READER_CODE": "GMB",
        "SEGMENT_VALUE_ID": 357
    },
    {
        "Nationality": "Georgia",
        "EIDA_READER_CODE": "GEO",
        "PASSPORT_READER_CODE": "GEO",
        "SEGMENT_VALUE_ID": 358
    },
    {
        "Nationality": "German Dem. Rep.",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 359
    },
    {
        "Nationality": "Germany",
        "EIDA_READER_CODE": "DEU",
        "PASSPORT_READER_CODE": "D",
        "SEGMENT_VALUE_ID": 360
    },
    {
        "Nationality": "Ghana",
        "EIDA_READER_CODE": "GHA",
        "PASSPORT_READER_CODE": "GHA",
        "SEGMENT_VALUE_ID": 361
    },
    {
        "Nationality": "Gibraltar",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 362
    },
    {
        "Nationality": "Greece",
        "EIDA_READER_CODE": "GRC",
        "PASSPORT_READER_CODE": "GRC",
        "SEGMENT_VALUE_ID": 363
    },
    {
        "Nationality": "Greenland",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 364
    },
    {
        "Nationality": "Grenada",
        "EIDA_READER_CODE": "GRD",
        "PASSPORT_READER_CODE": "GRD",
        "SEGMENT_VALUE_ID": 365
    },
    {
        "Nationality": "Guadeloupe",
        "EIDA_READER_CODE": "GLP",
        "PASSPORT_READER_CODE": "GLP",
        "SEGMENT_VALUE_ID": 366
    },
    {
        "Nationality": "Guam",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 367
    },
    {
        "Nationality": "Guinea",
        "EIDA_READER_CODE": "GIN",
        "PASSPORT_READER_CODE": "GIN",
        "SEGMENT_VALUE_ID": 369
    },
    {
        "Nationality": "Guinea-Bissau",
        "EIDA_READER_CODE": "GNB",
        "PASSPORT_READER_CODE": "GNB",
        "SEGMENT_VALUE_ID": 370
    },
    {
        "Nationality": "Guyana",
        "EIDA_READER_CODE": "GUY",
        "PASSPORT_READER_CODE": "GUY",
        "SEGMENT_VALUE_ID": 371
    },
    {
        "Nationality": "Haiti",
        "EIDA_READER_CODE": "HTI",
        "PASSPORT_READER_CODE": "HTI",
        "SEGMENT_VALUE_ID": 372
    },
    {
        "Nationality": "Hong Kong",
        "EIDA_READER_CODE": "HKG",
        "PASSPORT_READER_CODE": "HKG",
        "SEGMENT_VALUE_ID": 374
    },
    {
        "Nationality": "Hungary",
        "EIDA_READER_CODE": "HUN",
        "PASSPORT_READER_CODE": "HUN",
        "SEGMENT_VALUE_ID": 375
    },
    {
        "Nationality": "Iceland",
        "EIDA_READER_CODE": "ISL",
        "PASSPORT_READER_CODE": "ISL",
        "SEGMENT_VALUE_ID": 390
    },
    {
        "Nationality": "India",
        "EIDA_READER_CODE": "IND",
        "PASSPORT_READER_CODE": "IND",
        "SEGMENT_VALUE_ID": 391
    },
    {
        "Nationality": "Indonesia",
        "EIDA_READER_CODE": "IDN",
        "PASSPORT_READER_CODE": "IDN",
        "SEGMENT_VALUE_ID": 392
    },
    {
        "Nationality": "Iran",
        "EIDA_READER_CODE": "IRN",
        "PASSPORT_READER_CODE": "IRN",
        "SEGMENT_VALUE_ID": 393
    },
    {
        "Nationality": "Iraq",
        "EIDA_READER_CODE": "IRQ",
        "PASSPORT_READER_CODE": "IRQ",
        "SEGMENT_VALUE_ID": 394
    },
    {
        "Nationality": "Ireland",
        "EIDA_READER_CODE": "IRL",
        "PASSPORT_READER_CODE": "IRL",
        "SEGMENT_VALUE_ID": 395
    },
    {
        "Nationality": "Italy",
        "EIDA_READER_CODE": "ITA",
        "PASSPORT_READER_CODE": "ITA",
        "SEGMENT_VALUE_ID": 396
    },
    {
        "Nationality": "Ivory Coast",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 397
    },
    {
        "Nationality": "Jamaica",
        "EIDA_READER_CODE": "JAM",
        "PASSPORT_READER_CODE": "JAM",
        "SEGMENT_VALUE_ID": 398
    },
    {
        "Nationality": "Jamaica/Cayman Islds",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 399
    },
    {
        "Nationality": "Johnston Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 401
    },
    {
        "Nationality": "Jordan",
        "EIDA_READER_CODE": "JOR",
        "PASSPORT_READER_CODE": "JOR",
        "SEGMENT_VALUE_ID": 402
    },
    {
        "Nationality": "KALININGRAD",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 403
    },
    {
        "Nationality": "Kazakstan",
        "EIDA_READER_CODE": "KAZ",
        "PASSPORT_READER_CODE": "KAZ",
        "SEGMENT_VALUE_ID": 404
    },
    {
        "Nationality": "Kenya",
        "EIDA_READER_CODE": "KEN",
        "PASSPORT_READER_CODE": "KEN",
        "SEGMENT_VALUE_ID": 405
    },
    {
        "Nationality": "Kerguelen Archipelag",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 406
    },
    {
        "Nationality": "Kyrgyzstan",
        "EIDA_READER_CODE": "KGZ",
        "PASSPORT_READER_CODE": "KGZ",
        "SEGMENT_VALUE_ID": 407
    },
    {
        "Nationality": "Kiribati",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 408
    },
    {
        "Nationality": "Korea North",
        "EIDA_READER_CODE": "PRK",
        "PASSPORT_READER_CODE": "PKR",
        "SEGMENT_VALUE_ID": 409
    },
    {
        "Nationality": "Korea South",
        "EIDA_READER_CODE": "KOR",
        "PASSPORT_READER_CODE": "KOR",
        "SEGMENT_VALUE_ID": 410
    },
    {
        "Nationality": "Kuwait",
        "EIDA_READER_CODE": "KWT",
        "PASSPORT_READER_CODE": "KWT",
        "SEGMENT_VALUE_ID": 411
    },
    {
        "Nationality": "Laos",
        "EIDA_READER_CODE": "LAO",
        "PASSPORT_READER_CODE": "LAO",
        "SEGMENT_VALUE_ID": 412
    },
    {
        "Nationality": "Latvia",
        "EIDA_READER_CODE": "LVA",
        "PASSPORT_READER_CODE": "LVA",
        "SEGMENT_VALUE_ID": 413
    },
    {
        "Nationality": "Lebanon",
        "EIDA_READER_CODE": "LBN",
        "PASSPORT_READER_CODE": "LBN",
        "SEGMENT_VALUE_ID": 414
    },
    {
        "Nationality": "Lesotho",
        "EIDA_READER_CODE": "LSO",
        "PASSPORT_READER_CODE": "LSO",
        "SEGMENT_VALUE_ID": 415
    },
    {
        "Nationality": " Libya",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 417
    },
    {
        "Nationality": "Lithuania",
        "EIDA_READER_CODE": "LTU",
        "PASSPORT_READER_CODE": "LTU",
        "SEGMENT_VALUE_ID": 419
    },
    {
        "Nationality": "Luxembourg",
        "EIDA_READER_CODE": "LUX",
        "PASSPORT_READER_CODE": "LUX",
        "SEGMENT_VALUE_ID": 420
    },
    {
        "Nationality": "Macedonia",
        "EIDA_READER_CODE": "MKD",
        "PASSPORT_READER_CODE": "MKD",
        "SEGMENT_VALUE_ID": 421
    },
    {
        "Nationality": "Macao",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 422
    },
    {
        "Nationality": "Madagascar",
        "EIDA_READER_CODE": "MDG",
        "PASSPORT_READER_CODE": "MDG",
        "SEGMENT_VALUE_ID": 423
    },
    {
        "Nationality": "Malawi",
        "EIDA_READER_CODE": "MWI",
        "PASSPORT_READER_CODE": "MWI",
        "SEGMENT_VALUE_ID": 424
    },
    {
        "Nationality": "Malaysia",
        "EIDA_READER_CODE": "MYS",
        "PASSPORT_READER_CODE": "MYS",
        "SEGMENT_VALUE_ID": 425
    },
    {
        "Nationality": "Maldives",
        "EIDA_READER_CODE": "MDV",
        "PASSPORT_READER_CODE": "MDV",
        "SEGMENT_VALUE_ID": 426
    },
    {
        "Nationality": "Mali",
        "EIDA_READER_CODE": "MLI",
        "PASSPORT_READER_CODE": "MLI",
        "SEGMENT_VALUE_ID": 427
    },
    {
        "Nationality": "Mariana Islands",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 429
    },
    {
        "Nationality": "Marshall Islands",
        "EIDA_READER_CODE": "MHL",
        "PASSPORT_READER_CODE": "MHL",
        "SEGMENT_VALUE_ID": 430
    },
    {
        "Nationality": "Martinique",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 431
    },
    {
        "Nationality": "Mauritania",
        "EIDA_READER_CODE": "MRT",
        "PASSPORT_READER_CODE": "MRT",
        "SEGMENT_VALUE_ID": 432
    },
    {
        "Nationality": "Mayotte Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 434
    },
    {
        "Nationality": "Micronesia",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 436
    },
    {
        "Nationality": "Midway Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 437
    },
    {
        "Nationality": "Moldova",
        "EIDA_READER_CODE": "MOA",
        "PASSPORT_READER_CODE": "MDA",
        "SEGMENT_VALUE_ID": 438
    },
    {
        "Nationality": "Monaco",
        "EIDA_READER_CODE": "MCO",
        "PASSPORT_READER_CODE": "MCO",
        "SEGMENT_VALUE_ID": 439
    },
    {
        "Nationality": "Mongolia",
        "EIDA_READER_CODE": "MNG",
        "PASSPORT_READER_CODE": "MNG",
        "SEGMENT_VALUE_ID": 440
    },
    {
        "Nationality": "Montserrat",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 441
    },
    {
        "Nationality": "Mozambique",
        "EIDA_READER_CODE": "MOZ",
        "PASSPORT_READER_CODE": "MOZ",
        "SEGMENT_VALUE_ID": 443
    },
    {
        "Nationality": "Namibia",
        "EIDA_READER_CODE": "NAM",
        "PASSPORT_READER_CODE": "NAM",
        "SEGMENT_VALUE_ID": 444
    },
    {
        "Nationality": "Nauru",
        "EIDA_READER_CODE": "NRU",
        "PASSPORT_READER_CODE": "NRU",
        "SEGMENT_VALUE_ID": 445
    },
    {
        "Nationality": "Nepal",
        "EIDA_READER_CODE": "NPL",
        "PASSPORT_READER_CODE": "NPL",
        "SEGMENT_VALUE_ID": 446
    },
    {
        "Nationality": "Netherlands Antilles",
        "EIDA_READER_CODE": "ANT",
        "PASSPORT_READER_CODE": "ANT",
        "SEGMENT_VALUE_ID": 448
    },
    {
        "Nationality": "New Caledonia",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 449
    },
    {
        "Nationality": "New Zealand",
        "EIDA_READER_CODE": "NZL",
        "PASSPORT_READER_CODE": "NZL",
        "SEGMENT_VALUE_ID": 450
    },
    {
        "Nationality": "Nicaragua",
        "EIDA_READER_CODE": "NIC",
        "PASSPORT_READER_CODE": "NIC",
        "SEGMENT_VALUE_ID": 451
    },
    {
        "Nationality": "Nigeria",
        "EIDA_READER_CODE": "NGA",
        "PASSPORT_READER_CODE": "NGA",
        "SEGMENT_VALUE_ID": 452
    },
    {
        "Nationality": "Niue Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 453
    },
    {
        "Nationality": "Norfolk Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 454
    },
    {
        "Nationality": "Oman",
        "EIDA_READER_CODE": "OMN",
        "PASSPORT_READER_CODE": "OMN",
        "SEGMENT_VALUE_ID": 456
    },
    {
        "Nationality": "Pakistan",
        "EIDA_READER_CODE": "PAK",
        "PASSPORT_READER_CODE": "PAK",
        "SEGMENT_VALUE_ID": 457
    },
    {
        "Nationality": "Palau",
        "EIDA_READER_CODE": "PLW",
        "PASSPORT_READER_CODE": "PLW",
        "SEGMENT_VALUE_ID": 458
    },
    {
        "Nationality": "Palestinian Territory",
        "EIDA_READER_CODE": "PSE",
        "PASSPORT_READER_CODE": "PSE",
        "SEGMENT_VALUE_ID": 459
    },
    {
        "Nationality": "Papua New Guinea",
        "EIDA_READER_CODE": "PNG",
        "PASSPORT_READER_CODE": "PNG",
        "SEGMENT_VALUE_ID": 461
    },
    {
        "Nationality": "Paraguay",
        "EIDA_READER_CODE": "PRY",
        "PASSPORT_READER_CODE": "PRY",
        "SEGMENT_VALUE_ID": 462
    },
    {
        "Nationality": "Peru",
        "EIDA_READER_CODE": "PER",
        "PASSPORT_READER_CODE": "PER",
        "SEGMENT_VALUE_ID": 463
    },
    {
        "Nationality": "Pitcairn Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 465
    },
    {
        "Nationality": "Poland",
        "EIDA_READER_CODE": "POL",
        "PASSPORT_READER_CODE": "POL",
        "SEGMENT_VALUE_ID": 466
    },
    {
        "Nationality": "Puert Rico/Vir Isl A",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 468
    },
    {
        "Nationality": "Puerto Rico",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 469
    },
    {
        "Nationality": "Rep. of Niger",
        "EIDA_READER_CODE": "NER",
        "PASSPORT_READER_CODE": "NER",
        "SEGMENT_VALUE_ID": 471
    },
    {
        "Nationality": "Reunion",
        "EIDA_READER_CODE": "REU",
        "PASSPORT_READER_CODE": "REU",
        "SEGMENT_VALUE_ID": 472
    },
    {
        "Nationality": "Rodriguez Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 473
    },
    {
        "Nationality": "Romania",
        "EIDA_READER_CODE": "ROU",
        "PASSPORT_READER_CODE": "ROU",
        "SEGMENT_VALUE_ID": 474
    },
    {
        "Nationality": "Russian Federation",
        "EIDA_READER_CODE": "RUS",
        "PASSPORT_READER_CODE": "RUS",
        "SEGMENT_VALUE_ID": 475
    },
    {
        "Nationality": "Rwanda",
        "EIDA_READER_CODE": "RWA",
        "PASSPORT_READER_CODE": "RWA",
        "SEGMENT_VALUE_ID": 476
    },
    {
        "Nationality": "SCOTT BASE",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 477
    },
    {
        "Nationality": "Samao (American)",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 478
    },
    {
        "Nationality": "Samoa",
        "EIDA_READER_CODE": "WSM",
        "PASSPORT_READER_CODE": "WSM",
        "SEGMENT_VALUE_ID": 479
    },
    {
        "Nationality": "San Marino",
        "EIDA_READER_CODE": "SMR",
        "PASSPORT_READER_CODE": "SMR",
        "SEGMENT_VALUE_ID": 480
    },
    {
        "Nationality": "Senegal",
        "EIDA_READER_CODE": "SEN",
        "PASSPORT_READER_CODE": "SEN",
        "SEGMENT_VALUE_ID": 482
    },
    {
        "Nationality": "Seychelles",
        "EIDA_READER_CODE": "SYC",
        "PASSPORT_READER_CODE": "SYC",
        "SEGMENT_VALUE_ID": 483
    },
    {
        "Nationality": "Sierra Leone",
        "EIDA_READER_CODE": "SLE",
        "PASSPORT_READER_CODE": "SLE",
        "SEGMENT_VALUE_ID": 484
    },
    {
        "Nationality": "Slovakia",
        "EIDA_READER_CODE": "SVK",
        "PASSPORT_READER_CODE": "SVK",
        "SEGMENT_VALUE_ID": 486
    },
    {
        "Nationality": "Solomon Islands",
        "EIDA_READER_CODE": "SLB",
        "PASSPORT_READER_CODE": "SLB",
        "SEGMENT_VALUE_ID": 488
    },
    {
        "Nationality": "South Africa",
        "EIDA_READER_CODE": "ZAF",
        "PASSPORT_READER_CODE": "ZAF",
        "SEGMENT_VALUE_ID": 490
    },
    {
        "Nationality": "Spain",
        "EIDA_READER_CODE": "ESP",
        "PASSPORT_READER_CODE": "ESP",
        "SEGMENT_VALUE_ID": 491
    },
    {
        "Nationality": "Sri Lanka",
        "EIDA_READER_CODE": "LKA",
        "PASSPORT_READER_CODE": "LKA",
        "SEGMENT_VALUE_ID": 492
    },
    {
        "Nationality": "Adelie Land",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 277
    },
    {
        "Nationality": "Afghanistan",
        "EIDA_READER_CODE": "AFG",
        "PASSPORT_READER_CODE": "AFG",
        "SEGMENT_VALUE_ID": 278
    },
    {
        "Nationality": "Algeria",
        "EIDA_READER_CODE": "DZA",
        "PASSPORT_READER_CODE": "DZA",
        "SEGMENT_VALUE_ID": 280
    },
    {
        "Nationality": "United States of America",
        "EIDA_READER_CODE": "USA",
        "PASSPORT_READER_CODE": "USA",
        "SEGMENT_VALUE_ID": 281
    },
    {
        "Nationality": "Andorra",
        "EIDA_READER_CODE": "AND",
        "PASSPORT_READER_CODE": "AND",
        "SEGMENT_VALUE_ID": 282
    },
    {
        "Nationality": "Angola",
        "EIDA_READER_CODE": "AGO",
        "PASSPORT_READER_CODE": "AGO",
        "SEGMENT_VALUE_ID": 283
    },
    {
        "Nationality": "Anguilla",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 284
    },
    {
        "Nationality": "Antigua",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 285
    },
    {
        "Nationality": "Antigua and Barbuda",
        "EIDA_READER_CODE": "ATG",
        "PASSPORT_READER_CODE": "ATG",
        "SEGMENT_VALUE_ID": 286
    },
    {
        "Nationality": "Argentina",
        "EIDA_READER_CODE": "ARG",
        "PASSPORT_READER_CODE": "ARG",
        "SEGMENT_VALUE_ID": 287
    },
    {
        "Nationality": "Armenia",
        "EIDA_READER_CODE": "ARM",
        "PASSPORT_READER_CODE": "ARM",
        "SEGMENT_VALUE_ID": 288
    },
    {
        "Nationality": "Aruba",
        "EIDA_READER_CODE": "ABW",
        "PASSPORT_READER_CODE": "ABW",
        "SEGMENT_VALUE_ID": 289
    },
    {
        "Nationality": "Ascension Island",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 290
    },
    {
        "Nationality": "Australia",
        "EIDA_READER_CODE": "AUS",
        "PASSPORT_READER_CODE": "AUS",
        "SEGMENT_VALUE_ID": 292
    },
    {
        "Nationality": "Azerbaijan",
        "EIDA_READER_CODE": "AZE",
        "PASSPORT_READER_CODE": "AZE",
        "SEGMENT_VALUE_ID": 293
    },
    {
        "Nationality": "Bahamas",
        "EIDA_READER_CODE": "BHS",
        "PASSPORT_READER_CODE": "BHS",
        "SEGMENT_VALUE_ID": 294
    },
    {
        "Nationality": "Bahrain",
        "EIDA_READER_CODE": "BHR",
        "PASSPORT_READER_CODE": "BHR",
        "SEGMENT_VALUE_ID": 295
    },
    {
        "Nationality": "Bangladesh",
        "EIDA_READER_CODE": "BGD",
        "PASSPORT_READER_CODE": "BGD",
        "SEGMENT_VALUE_ID": 296
    },
    {
        "Nationality": "Barbados",
        "EIDA_READER_CODE": "BRB",
        "PASSPORT_READER_CODE": "BRB",
        "SEGMENT_VALUE_ID": 297
    },
    {
        "Nationality": "Belgium",
        "EIDA_READER_CODE": "BEL",
        "PASSPORT_READER_CODE": "BEL",
        "SEGMENT_VALUE_ID": 298
    },
    {
        "Nationality": "Belize",
        "EIDA_READER_CODE": "BLZ",
        "PASSPORT_READER_CODE": "BLZ",
        "SEGMENT_VALUE_ID": 299
    },
    {
        "Nationality": "Bermuda",
        "EIDA_READER_CODE": "BMU",
        "PASSPORT_READER_CODE": "BMU",
        "SEGMENT_VALUE_ID": 301
    },
    {
        "Nationality": "Bhutan",
        "EIDA_READER_CODE": "BTN",
        "PASSPORT_READER_CODE": "BTN",
        "SEGMENT_VALUE_ID": 302
    },
    {
        "Nationality": "Bolivia",
        "EIDA_READER_CODE": "BOL",
        "PASSPORT_READER_CODE": "BOL",
        "SEGMENT_VALUE_ID": 303
    },
    {
        "Nationality": "Bophuthatswana",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 304
    },
    {
        "Nationality": "Botswana",
        "EIDA_READER_CODE": "BWA",
        "PASSPORT_READER_CODE": "BWA",
        "SEGMENT_VALUE_ID": 305
    },
    {
        "Nationality": "Bulgaria",
        "EIDA_READER_CODE": "BGR",
        "PASSPORT_READER_CODE": "BGR",
        "SEGMENT_VALUE_ID": 308
    },
    {
        "Nationality": "Burkina Faso",
        "EIDA_READER_CODE": "BFA",
        "PASSPORT_READER_CODE": "BFA",
        "SEGMENT_VALUE_ID": 309
    },
    {
        "Nationality": "Burma",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 310
    },
    {
        "Nationality": "Byelorussia",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 312
    },
    {
        "Nationality": "Cambodia",
        "EIDA_READER_CODE": "KHM",
        "PASSPORT_READER_CODE": "KHM",
        "SEGMENT_VALUE_ID": 313
    },
    {
        "Nationality": "Cameroon",
        "EIDA_READER_CODE": "CMR",
        "PASSPORT_READER_CODE": "CMR",
        "SEGMENT_VALUE_ID": 314
    },
    {
        "Nationality": "Canada",
        "EIDA_READER_CODE": "CAN",
        "PASSPORT_READER_CODE": "CAN",
        "SEGMENT_VALUE_ID": 315
    },
    {
        "Nationality": "Canada/U.S.A",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 316
    },
    {
        "Nationality": "Caroline Islands",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 318
    },
    {
        "Nationality": "Carriacou",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 319
    },
    {
        "Nationality": "St Pierre and Miquelon",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 493
    },
    {
        "Nationality": "St Thome and Principe",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 494
    },
    {
        "Nationality": "St. Helena",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 495
    },
    {
        "Nationality": "Saint Kitts and Nevis",
        "EIDA_READER_CODE": "KNA",
        "PASSPORT_READER_CODE": "KNA",
        "SEGMENT_VALUE_ID": 496
    },
    {
        "Nationality": "Saint Lucia",
        "EIDA_READER_CODE": "LCA",
        "PASSPORT_READER_CODE": "LCA",
        "SEGMENT_VALUE_ID": 497
    },
    {
        "Nationality": "St Vincent and Grenadines",
        "EIDA_READER_CODE": "VCT",
        "PASSPORT_READER_CODE": "VCT",
        "SEGMENT_VALUE_ID": 498
    },
    {
        "Nationality": "Suriname",
        "EIDA_READER_CODE": "SUR",
        "PASSPORT_READER_CODE": "SUR",
        "SEGMENT_VALUE_ID": 500
    },
    {
        "Nationality": "Swaziland",
        "EIDA_READER_CODE": "SWZ",
        "PASSPORT_READER_CODE": "SWZ",
        "SEGMENT_VALUE_ID": 501
    },
    {
        "Nationality": "Sweden",
        "EIDA_READER_CODE": "SWE",
        "PASSPORT_READER_CODE": "SWE",
        "SEGMENT_VALUE_ID": 502
    },
    {
        "Nationality": "Switzerland",
        "EIDA_READER_CODE": "CHE",
        "PASSPORT_READER_CODE": "CHE",
        "SEGMENT_VALUE_ID": 503
    },
    {
        "Nationality": "Syrian Arab Republic",
        "EIDA_READER_CODE": "SYR",
        "PASSPORT_READER_CODE": "SYR",
        "SEGMENT_VALUE_ID": 504
    },
    {
        "Nationality": "Tajikistan",
        "EIDA_READER_CODE": "TJK",
        "PASSPORT_READER_CODE": "TJK",
        "SEGMENT_VALUE_ID": 506
    },
    {
        "Nationality": "Tanzania",
        "EIDA_READER_CODE": "TZA",
        "PASSPORT_READER_CODE": "TZA",
        "SEGMENT_VALUE_ID": 507
    },
    {
        "Nationality": "Tatarstan",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 508
    },
    {
        "Nationality": "Thailand",
        "EIDA_READER_CODE": "THA",
        "PASSPORT_READER_CODE": "THA",
        "SEGMENT_VALUE_ID": 509
    },
    {
        "Nationality": "Togo",
        "EIDA_READER_CODE": "TGO",
        "PASSPORT_READER_CODE": "TGO",
        "SEGMENT_VALUE_ID": 510
    },
    {
        "Nationality": "Tokelau Islands",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 511
    },
    {
        "Nationality": "Tonga",
        "EIDA_READER_CODE": "TON",
        "PASSPORT_READER_CODE": "TON",
        "SEGMENT_VALUE_ID": 512
    },
    {
        "Nationality": "Transkei",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 513
    },
    {
        "Nationality": "Trinidad and Tobago",
        "EIDA_READER_CODE": "TTO",
        "PASSPORT_READER_CODE": "TTO",
        "SEGMENT_VALUE_ID": 514
    },
    {
        "Nationality": "Tristan Da Cunha",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 515
    },
    {
        "Nationality": "Tunisia",
        "EIDA_READER_CODE": "TUN",
        "PASSPORT_READER_CODE": "TUN",
        "SEGMENT_VALUE_ID": 516
    },
    {
        "Nationality": "Turkey",
        "EIDA_READER_CODE": "TUR",
        "PASSPORT_READER_CODE": "TUR",
        "SEGMENT_VALUE_ID": 517
    },
    {
        "Nationality": "Turkmenistan",
        "EIDA_READER_CODE": "TKM",
        "PASSPORT_READER_CODE": "TKM",
        "SEGMENT_VALUE_ID": 518
    },
    {
        "Nationality": "Turks and Caicos Isl.",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 519
    },
    {
        "Nationality": "Tuvalu",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 520
    },
    {
        "Nationality": "U.S.A.Hawaii",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 521
    },
    {
        "Nationality": "USA (Mainland)",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 522
    },
    {
        "Nationality": "Uganda",
        "EIDA_READER_CODE": "UGA",
        "PASSPORT_READER_CODE": "UGA",
        "SEGMENT_VALUE_ID": 523
    },
    {
        "Nationality": "Ukraine",
        "EIDA_READER_CODE": "UKR",
        "PASSPORT_READER_CODE": "UKR",
        "SEGMENT_VALUE_ID": 524
    },
    {
        "Nationality": "United Arab Emirates",
        "EIDA_READER_CODE": "ARE",
        "PASSPORT_READER_CODE": "ARE",
        "SEGMENT_VALUE_ID": 525
    },
    {
        "Nationality": "Inmarsat",
        "EIDA_READER_CODE": "",
        "PASSPORT_READER_CODE": "",
        "SEGMENT_VALUE_ID": 655
    },
    {
        "Nationality": "American Samoa",
        "EIDA_READER_CODE": "ASM",
        "PASSPORT_READER_CODE": "ASM",
        "SEGMENT_VALUE_ID": 273303054
    },
    {
        "Nationality": "French Southern Terr.",
        "EIDA_READER_CODE": "ATF",
        "PASSPORT_READER_CODE": "ATF",
        "SEGMENT_VALUE_ID": 273303055
    },
    {
        "Nationality": "Georgia, Sandwich Isl.",
        "EIDA_READER_CODE": "SGS",
        "PASSPORT_READER_CODE": "SGS",
        "SEGMENT_VALUE_ID": 273303056
    },
    {
        "Nationality": "Northern Mariana Islands",
        "EIDA_READER_CODE": "MNP",
        "PASSPORT_READER_CODE": "MNP",
        "SEGMENT_VALUE_ID": 273303057
    },
    {
        "Nationality": "Saint Helena",
        "EIDA_READER_CODE": "SHN",
        "PASSPORT_READER_CODE": "SHN",
        "SEGMENT_VALUE_ID": 273303058
    },
    {
        "Nationality": "Without Nationality",
        "EIDA_READER_CODE": "WNT",
        "PASSPORT_READER_CODE": "WNT",
        "SEGMENT_VALUE_ID": 273303059
    }
]
