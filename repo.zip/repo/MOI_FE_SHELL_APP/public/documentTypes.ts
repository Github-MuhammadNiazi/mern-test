export const docTypes  =   [
    { "id": 1, "name": "ESTABLISHMENT CARD" },
    { "id": 2, "name": "Tax Registration Certificate" },
    { "id": 3, "name": "Trade License" }
]