const { withNativeFederation, shareAll } = require('@angular-architects/native-federation/config');
const { environment } = require('./src/environments/environment.ts');
const { mapRemotes } = require("./src/app/utils/remote-mapper");

const remoteEnvironments = mapRemotes(environment.remotes);

module.exports = withNativeFederation({
  name: "shell",

  remotes: remoteEnvironments,

  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: "auto",
    }),
    "shared-state": { singleton: true, strictVersion: true },
  },

  skip: [
    "rxjs/ajax",
    "rxjs/fetch",
    "rxjs/testing",
    "rxjs/webSocket",
    // Add further packages you don't need at runtime
  ],

  // Please read our FAQ about sharing libs:
  // https://shorturl.at/jmzH0

  features: {
    // New feature for more performance and avoiding
    // issues with node libs. Comment this out to
    // get the traditional behavior:
    ignoreUnusedDeps: true,
  },
});
