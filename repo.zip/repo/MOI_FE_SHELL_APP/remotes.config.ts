export const REMOTE_URLS = {
  "header-mfe": "http://localhost:4301/remoteEntry.json",
  "footer-mfe": "http://localhost:4302/remoteEntry.json",
  "login-mfe": "http://localhost:4331/remoteEntry.json",
  "signup-mfe": "http://localhost:4332/remoteEntry.json",
  "otp-mfe": "http://localhost:4330/remoteEntry.json",
  "user-dashboard-mfe": "http://localhost:4334/remoteEntry.json",
  "plans-mfe": "http://localhost:4333/remoteEntry.json",
  "error-page-mfe": "http://localhost:4338/remoteEntry.json",
  "gis-module-mfe": "http://localhost:4336/remoteEntry.json",
  "boq-mfe": "http://localhost:4337/remoteEntry.json"
};
