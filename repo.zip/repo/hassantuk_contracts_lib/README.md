# Shared-state Library in Shell and MFEs + (CI/CD & Development Guide)

## Prerequisites
- Angular CLI: 19.2.14
- Node: 22.17.1
- Package Manager: npm 10.9.2
- Native federation: 20.0.6

## 1. Clone the repo

```bash
git clone https://github.etisalat.corp.ae/NNADEEM/hassantuk_contracts_lib.git
```

## 2. Build the Library

From the library project (`hassantuk_contracts_lib`), run:

```bash
npm i
ng build
```

This creates the library at:

```
dist/shared-state
```

## 3. Configure Dependencies

In each Shell and MFE project, update `package.json` to include the `shared-state` library using a relative path:

```json
"dependencies": {
  "shared-state": "file:../path-to-dist/shared-state"
}
```

In **CI/CD pipelines**, update this path to wherever the `shared-state` folder is created during the build process.

---

## 4. Install

In any Shell/MFE project, run:

```bash
npm install
```

---

## 5. Verification

### A. Development (local)
* Check node-modules to ensure `shared-state` is available in Shell/MFE

* Start the Shell/MFE

```bash
npm start
```

If the project starts without errors, the dependency is correctly linked.

### B. CI/CD (pipeline)

#### Build/test step in Shell/MFE

```bash
npm run build
```

If `shared-state` is missing, this step will fail.

#### Dependency resolution check (optional)

```bash
node -e "require.resolve('shared-state')"
```

Exits with error if the package is not installed.

#### Lockfile check

* Confirm `package-lock.json` contains an entry for `shared-state`.

---

## Success Criteria

* **Development**: `npm start` runs successfully without errors.
* **CI/CD**: Build/test step passes without `shared-state` related issues.
