// Commenting to resolve @typescript-eslint/no-unsused-vars
// import { OrderConfigurationModel } from './orderConfiguration-model';
// import { DocumentModel } from './user-model';

export class BulkOrderModel {
  mainAccountNumber: string;
  orderName: string;
  locale: string;
  bulkQuotes: BulkQuoteModel[] = [];
}

export class BulkQuoteModel {
  locale: string;
  quoteNumber: string;
  quoteVATAmount: string;
  totalQuoteAmount: string;
  totalVillaQuantity: string;
  villaDetails: QuoteVillaDetailModel[]=[];
}

export class QuoteVillaDetailModel {
  villaQuantity: string;
  villaType: string;
};
