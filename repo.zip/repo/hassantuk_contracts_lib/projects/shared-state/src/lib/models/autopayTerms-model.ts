export class AutopayTerms {
  isAutopayFlag: boolean;
  paymentDay: number;
  paymentMethordId: number;
}
