import { OrderModel } from "./order-model";

export class OrderSummary {
  id: number;
  accountNumber: string;
  requestId: string;
  status: string;
  orderName: string;
  warningState: string;
  errorState: string;
  registrationDate: string;
  paymentDate: string;
  boqGenerationdate: string;
  invoice: unknown;
  postPaidBill: unknown;
  type: unknown;
  subOrders: OrderModel[] = [];
  isSubOrder: boolean;
  paymentMethodId: number;
  paymentDay: number;
  planType: string;
  transferFlow: string;
}

export class RequestSummary {
  requestID: number;
  requestStatus = '';
  snagList: string[];
  snagListCleared: boolean;
  totalPaidAmount: string;
}

