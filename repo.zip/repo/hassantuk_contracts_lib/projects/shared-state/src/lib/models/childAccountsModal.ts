export class ChildAccountDetails {
  accountNumber: string;
  villaAddress: string;
  city:string;
  state:string;
  accountActivationDate:string;
}
