

export class paginationModal {
  pageSize: number;
  pageNumber: number;
}
