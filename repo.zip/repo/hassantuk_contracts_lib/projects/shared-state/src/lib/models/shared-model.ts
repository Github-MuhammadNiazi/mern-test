export class IDocType {
  id: number;
  filename: string;
  filetype: string;
  value: string;
}


export interface IDocTypeRes {
  data: IDocType[];
}

export class SidebarData{
  fullname: string;
  orderStatus: number;
}

export class Loader{
  show = false;
  message = '';
}

export class MVConfigModel{
  isvalid = false;
  token = '';
  url = '';
}

export class PaymentTransactionModel{
  paymentTransactionId:string;
  paymentPortalURL:string;
  showLogo:boolean;
}
interface Scripts {
  name: string;
  src: string;
}

export const ScriptStore: Scripts[] = [
  {name: 'topNave', src: '/assets/js/modules/01-topNav.min.js'},
  {name: 'mainMenu', src: '/assets/js/modules/02-main-mega-menu.min.js'},
  {name: 'footer', src: '/assets/js/modules/14-footer.js'}
];
