// Commenting to resolve @typescript-eslint/no-unsused-vars
// import { OrderConfigurationModel } from './orderConfiguration-model';
// import { DocumentModel } from './user-model';

export class BillModel {
  accountID: string;
  accountName: string;
  accountNumber: string;
  accountStatus: string;
  asOfNowAmountDue: string;
  billDateFrom: string;
  billDateTo: string;
  billedAmnt: string;
  deliveryID: string;
  dueDate: string;
  eccRemainingBalance: string;
  invoiceDate: string;
  invoiceNumber: string;
  locale: string;
  openAmount: string;
  totalAmountDue: number;
  totalBilledAmntDue: string;
  email: string;
  mobile: string;
  paymentStatus: string;
}
