export class PlanModel {

}

export class SpecModal{

}
