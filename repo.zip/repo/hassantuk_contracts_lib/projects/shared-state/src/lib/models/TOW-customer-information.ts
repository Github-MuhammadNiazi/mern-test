export class customerInformationTOW {
  fullname: string;
  email: string;
  contact: string;
}
