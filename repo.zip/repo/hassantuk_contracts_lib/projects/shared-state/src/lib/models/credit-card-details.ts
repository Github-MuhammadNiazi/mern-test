export class creditCardDetails {
  cardName: string;
  expiryDate: string;
  cardNumberMasked: string;
  paymentMethordId:string;
  brandName:string;
}
