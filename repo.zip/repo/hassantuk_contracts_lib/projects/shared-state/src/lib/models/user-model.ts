import { DocType, GenderTitle } from '../enums/enums';

export class UserData {
  data: UserModel;
}

export class UserModel {
  active: boolean;
  isPartyExists: boolean;
  birthDate = '';
  creationDate: string;
  documentExpiryDate = '';
  documentNumber: string;
  documentStatus: string;
  documentStatusLabelEn: string;
  documentStatusLabelAr: string;
  documentId: string;
  documentType: DocType;
  email: string;
  landlineNumber: string;
  firstNameEn = '';
  fistNameAr = '';
  gender: GenderTitle;
  id: number;
  isDeveloper: boolean;
  isEtisalatCustomer: boolean;
  lastNameAr = '';
  lastNameEn = '';
  lastUpdateDate: string;
  locale: string;
  locked: boolean;
  nationality: string;
  partyId: string;
  password: string;
  passwordConfirm: string;
  passwordExpired: boolean;
  primaryMobileNumber: string;
  residentialProfileId: string;
  userDocuments: DocumentModel[] = [];
  userRoles: Role[] = [];
  accountDetails: AccountDetails;
  subsidizedAccountId: string;
  type: Status;
}

export class AdminModel {
  active: boolean;
  creationDate: string;
  email: string;
  firstName = '';
  fistName = '';
  gender: GenderTitle;
  id: number;
  isSuperAdmin: boolean;
  lastName = '';
  locale: string;
  password: string;
  passwordConfirm: string;
  primaryMobileNumber: string;
  employeeNumber: string;
  sdNumber: string;
  userRoles: Role[] = [];
  adminRoles: AdminRole[] = [];
}

export class DocumentModel {
  creationDate: string;
  document: string;
  id: number;
  lastUpdateDate: string;
  status: string;
  documentType: DocType;
}

export class Role {
  active?: boolean;
  comments?: string;
  displayName?: string;
  id?: number;
  name?: string;
}

export class ChangePasswordModel {
  password: string;
  otp: string;
  email: string;
}

export class VillasServiceModel {
  TransactionID: string;
  accountDetails: AccountDetails;
};


export class AccountDetails {
  accountActivationDate: string;
  accountCessationDate: string;
  accountId: number;
  accountNumber: string;
  accountStatus: AccountStatus;
  productGroup: Status;
  accountSuffix: string;
  accountType: string;
  createdBy: string;
  modifiedBy: string;
  createdDate: string;
  modifiedDate: string;
  profileId: number;
  customerId: string;
  billingCycleId: string;
  linkedPrivileges: LinkedPrivileges;
};

export class AccountStatus {
  code: string;
  name: string;
  id: string;
  description: string;
}

export class LinkedPrivileges {
  privilegeType: Status;
  documentType: DocumentType;
  documentNumber: string;
  addresses: Addresses;
};

export class PrivilegeType {
  id: number;
  code: string;
  name: string;
};

export class DocumentType {
  code: string;
  name: string;
  id: string;
  description: string;
};

export class Addresses {
  contactName: string;
  contactMobileNo: string;
  email: string;
  newAddress: boolean;
  addressLine1: string;
  addressLine2: string;
  villaLongitude: string;
  villaLatitude: string;
  buildingName: string;
  villaorBuildingNbr: string;
  makaniOwmaniNbr: string;
  community: Status;
  city: Status;
  state: Status;
  plot: string;
  poBox: string;
  alreadyProcessedOrderID: string;
  alreadyProcessed = false;
};

export class Status {
  code: string;
  name: string;
  id: string;
  description: string;
};

export class AdminRole {
  id?: string;
  role?: Role;
}

export class Document {
  documentType: string;
  documentID: string;
  documentExpiryDate: string;
  additionalInfo: AdditionalInfo[];
}

export class PostPaidOrders {
  transactionID: string;
  customerDetails: CustomerDetails;
  orderDetails: OrderDetails[];
  additionalInfo: AdditionalInfo[];
  customerPremiseDetails: CustomerPremiseDetails;
  workOrderDetails: WorkOrderDetails;
  iotdetails?: unknown;
}
export class OrderDetails {
  requestID: string;
  accountNumber: string;
  requestStatus: string;
  additionalInfo: AdditionalInfo[];
  errorCode: string;
  errorDescription: string;
}
export class Profile {
  profileID: string;
  typeCode: string;
  typeName: string;
  subTypeCode: string;
  subTypeName: string;
  statusCode: string;
  statusName: string;
  additionalInfo: AdditionalInfo[];
}

export class CustomerDetails {
  partyID: number;
  firstNameEng: string;
  lastNameEng: string;
  firstNameArabic: string;
  lastNameArabic: string;
  dateOfBirth: string;
  nationality: string;
  gender: string;
  primaryMobileNumber?: unknown;
  secondaryMobileNumber?: unknown;
  email: string;
  etisalatLandlineNumber?: unknown;
  errorCode?: unknown;
  errorDescription?: unknown;
  documents: Document[];
  profiles: Profile[];
  additionalInfo: AdditionalInfo[];
}

export class AdditionalInfo {
  name: string;
  value: string;
}
export class CustomerPremiseDetails {
  longitude?: unknown;
  latitude?: unknown;
  eid?: unknown;
  villaNumber?: unknown;
  premiseType?: unknown;
  landlineNo?: unknown;
  premiseName?: unknown;
  emirate?: unknown;
  community?: unknown;
  plotNumber?: unknown;
  addressRefNumber?: unknown;
  city?: unknown;
  villaAddress?: unknown;
  errorCode?: unknown;
  errorDescription?: unknown;
  additionalInfo: AdditionalInfo[];
}

export class WorkOrderDetails {
  workOrderNumber?: unknown;
  taskNumber?: unknown;
  taskName?: unknown;
  taskStatus?: unknown;
  technicianID?: unknown;
  pendingTeam?: unknown;
  scheduleStartDate?: unknown;
  actualEndDate?: unknown;
  errorCode?: unknown;
  errorDescription?: unknown;
  additionalInfo: AdditionalInfo[];
}
