export class invoiceModel {
  dueAmount:number;
  invoiceNumber:string;
  accountNumber:string;
  invoiceDate:string;
  activationAmount: number;
}
