export class OrderType {

  public static readonly DEFAULT = new OrderType(1, 'Default');
  public static readonly SHARJAH_SUBSIDIZED = new OrderType(2, 'Sharjah_Subsidized');
  public static readonly POSTPAID = new OrderType(3, 'Postpaid');

  private constructor (public readonly ID : number, public readonly NAME : string) {
  }
}
