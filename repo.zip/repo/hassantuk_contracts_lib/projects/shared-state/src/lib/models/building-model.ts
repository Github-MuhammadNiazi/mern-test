import {BuildingType, RoomType} from '../enums/enums';

export class BuildingModel {
  buildingName: string;
  creationDate: string;
  floors: FloorModel[];
  id: number;
  lastUpdateDate: string;
  type: BuildingType;
}

export class  FloorModel {
  creationDate: string;
  floorName: string;
  floorNumber: string;
  id: number;
  lastUpdateDate: string;
  tags: string[];
  type: string;
}
export class RoomModel {
  code: string;
  comments: string;
  creationDate: string;
  id: number;
  lastUpdateDate: string;
  ratePlan: string;
  type: RoomType;
}
