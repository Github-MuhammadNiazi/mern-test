

export class mainAccountDetails {
  accountNumber: string;
  address: string;
}
