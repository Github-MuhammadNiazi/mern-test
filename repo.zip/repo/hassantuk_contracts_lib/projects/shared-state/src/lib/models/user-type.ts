export class UserType {

  public static readonly DEFAULT = new UserType(1, 'Default');
  public static readonly SHARJAH_SUBSIDIZED = new UserType(2, 'Sharjah_Subsidized');
  public static readonly POSTPAID = new UserType(3, 'Postpaid');

  private constructor (public readonly ID : number, public readonly NAME : string) {
  }
}
