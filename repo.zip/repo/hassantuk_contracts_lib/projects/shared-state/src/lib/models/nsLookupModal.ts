export class nsLookupModal {
  Nationality: string;
  EIDA_READER_CODE: string;
  PASSPORT_READER_CODE: string;
  SEGMENT_VALUE_ID:number;
}
