import { BuildingModel } from './building-model';

export class OrderConfigurationModel {
  buildingConfiguration: BuildingModel[];
  creationDate: string;
  deviceSpecificationsIdentifier: string;
  deviceSpecificationsImportIdentifer: string;
  selectedPostPaidBundle: string;
  postPaidOrderAdditionalDevices: object;
  id: number;
  lastUpdateDate: string;
}
