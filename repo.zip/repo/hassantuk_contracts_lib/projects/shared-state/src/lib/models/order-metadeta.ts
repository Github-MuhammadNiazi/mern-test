export class OrdersMetadata {
  id:number;
  isTowDueAmountPaid :boolean;
  paymentMethodId:number;
  paymentDay:number;
  transferFlow:string;
  orderId:number;
  sourcePlan:string;
  targetPlan:string;
  accountActivationDate:string;

}
