export class developerRegisterModel {
  primaryMobileNumber: number;
  documentCode: string;
  documentId: string;
  partyId:number;
  firstName:string;
  lastName:string;
  email:string;
  password:string;
  locale: string;
}
