import {PlanCategory, PlanContractDuration, PlanType} from "../enums/enums";

export class PlanDetailModel {
  planType: PlanType;
  planContractDuration: PlanContractDuration;
  planCategory: PlanCategory;
}
