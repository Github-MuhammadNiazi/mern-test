export class ToBeTransferredAccountsModel {
  accountNumber:string;
  name:string;
  email:string;
  mobileNumber:string;
  address:string;
  city:string;
  state:string;
  plan:string;
  fromOrderId:number;
  accountActivationDate:string;
}
