import { OrderConfigurationModel } from './orderConfiguration-model';
import { DocumentModel, UserModel } from './user-model';
import { BillModel } from './bill-model';
import { OrdersMetadata } from "./order-metadeta";

export class OrderModel {
  accountNumber: string;
  orderName: string;
  address: string;
  attendantContactNumber: string;
  attendantName: string;
  boqId: string;
  city: string;
  community: string;
  creationDate: string;
  eidNumber: string;
  etisalatLandlineNumber: string;
  id: number;
  lastUpdateDate: string;
  latitude: string;
  longitude: string;
  makani: string;
  orderConfiguration: OrderConfigurationModel | null;
  paymentStatus: string;
  villaNumber: string;
  plotNumber: string;
  premiseName: string;
  premiseType: string;
  gisPremiseId: string;
  primaryMobileNumber: string;
  requestId: string;
  secondaryMobileNumber: string;
  status: string;
  subRequestId: string;
  isSubsidized: boolean;
  orderDocuments: DocumentModel[] = [];
  type: unknown;
  invoice: unknown;
  postPaidBill: BillModel;
  subOrders: OrderModel[] = [];
  subOrder: boolean;
  planType: string;
  user: UserModel;
  paymentMethodId: number;
  paymentDay: number;
  boqGenerationDate: unknown;
  orderDiscount: unknown;
  transferFlow: string;
  ordersMetadata: OrdersMetadata;
  emirate: string;
}

export class OrderContactsModel {
  name: string;
  number: string;
}

export class OrderServiceModel {
  qty = 0;
  unit = 0;
  total = 0;
};
