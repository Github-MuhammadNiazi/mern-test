import {UserModel} from './user-model';

export class AuthModel {
  token = '';
  isAuthenticated = false;
  user: UserModel = new UserModel();
}
