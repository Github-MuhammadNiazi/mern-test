export class CorporateAddress {
  addressLineOneEn: string;
  addressLineTwoEn: string;
  addressLineOneAr: string;
  addressLineTwoAr: string;
  city:string;
  zipCode:number;
}
