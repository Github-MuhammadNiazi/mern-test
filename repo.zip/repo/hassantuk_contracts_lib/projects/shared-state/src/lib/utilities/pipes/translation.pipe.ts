import { Pipe, PipeTransform, inject } from "@angular/core";
import { TranslationService } from "../../translation.service";

@Pipe({
  name: 'translate$',
  standalone: true,
  pure: true
})
export class TranslateAsyncPipe implements PipeTransform {
  private translationSvc = inject(TranslationService);

  transform (key: string) {
    return this.translationSvc.translate$(key);
  }
}
