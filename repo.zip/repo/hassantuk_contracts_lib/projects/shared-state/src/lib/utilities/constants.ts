export const Constants = {
  languages: {
    english: 'en',
    arabic: 'ar',
  },
  languageLabels: {
    english: 'English',
    arabic: 'العربية',
  },
  languageDirectionality: {
    left: 'left',
    right: 'right',
    leftToRight: 'ltr',
    rightToLeft: 'rtl',
  },
} as const;

// Exporting individual constants for convenience
export const { languages, languageDirectionality, languageLabels } = Constants;
