
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError,distinctUntilChanged, map, tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class TranslationService {
  private langSubject = new BehaviorSubject<string>('en');
  private translationsSubject = new BehaviorSubject<Record<string, string>>({});

  language$ = this.langSubject.asObservable();
  translations$ = this.translationsSubject.asObservable();

  constructor (private http: HttpClient) {}

  setLanguage (lang: string) {
    document.documentElement.setAttribute('lang', lang);
    this.langSubject.next(lang);
    this.setDirection(lang);
    this.loadTranslations(lang);
    console.log(`Language changed to: ${lang}`);
  }

  private setDirection (lang: string) {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('dir', dir);
    document.body.setAttribute('dir', dir);
  }

  getCurrentLanguage (): string {
    return this.langSubject.value;
  }

  private loadTranslations (lang: string): void {
    const path = `assets/i18n/${lang}.json`;

    this.http.get<Record<string, string>>(path).pipe(
      tap(data => {
        this.translationsSubject.next(data); // Notify subscribers once language is updated
      }),
      catchError(err => {
        console.error(`Failed to load translations: ${path}`, err);
        this.translationsSubject.next({});
        return of({});
      })
    ).subscribe();
  }

  private getNestedTranslation ( translations: Record<string, unknown>, key: string ): string {
    const result = key.split('.').reduce<unknown> ((obj, part) => {
      if (obj && typeof obj === 'object' && part in obj) {
        return (obj as Record<string, unknown>)[part];
      }
      return undefined;
    }, translations);

    return typeof result === 'string' ? result : key;
  }

  /**
   * Reactive translation stream for templates and components - we will use this for custom pipe
   */
  translate$ (key: string): Observable<string> {
    return this.translations$.pipe(
      map(translations => this.getNestedTranslation(translations, key)),
      distinctUntilChanged()
    );
  }

  /**
   * Optional: For quick access in code without waiting
   */
  translateSync (key: string): string {
    const translations = this.translationsSubject?.value || {};
    return this.getNestedTranslation(translations, key);
  }
}
