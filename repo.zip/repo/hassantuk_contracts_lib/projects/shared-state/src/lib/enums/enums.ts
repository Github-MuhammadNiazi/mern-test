export enum BuildingType {
  MainHouse = 'MNBLK',
  Garage = 'CGBLK',
  Annex = 'AXBLK'
}

export enum FloorType {
  Basement = 'UGF',
  GroundFloor = 'GF',
  FirstFloor = 'FL1',
  SecondFloor = 'FL2',
  ThirdFloor = 'FL3',
  FourthFloor = 'FL4',
  FifthFloor = 'FL5',
}

export enum RoomType {
  Bed, Living, Dining, Kitchen, Bath, Store, Other
}

export enum DocType {
  EmiratesID = 'EMIRATES_ID',
  Passport = 'PASSPORT',
  Registration = 'REGISTRATION',
  EmiratesNumber = 'EMIRATES_Number',
  TitleDeed = 'TITLE_DEED',
  UaeIdentityCard ='UAE Identity card',
  EstablishmentCard = 'ESTABLISHMENT_CARD',
}

export enum DocStatus {
  APPROVAL_PENDING = 'APPROVAL_PENDING',
  APPROVED = 'APPROVED',
  INVALID = 'INVALID',
  EXPIRED = 'EXPIRED'
}

export enum GenderTitle {
  Mr = 'MALE', Mrs = 'FEMALE'
}

export enum GenderTitleAr {
  السيد = 'MALE', السيدة = 'FEMALE'
}

export enum Lang {
  EN = 'en', AR = 'ar'
}

export enum UserType {
  Customer, Admin
}

export enum TransferFlowStatus {
  DEVELOPERTONORMAL = 'DEVELOPER_TO_NORMAL',
  NORMALTONORMAL = 'NORMAL_TO_NORMAL'
}

export enum OrderStatus {
  AddVillaDocs = 'ADD_VILLA_DOCUMENTS',
  AddMainHouse = 'ADD_VILLA_MNBLK_FLOORS',
  AddAnnex = 'ADD_VILLA_ANNEX_FLOORS',
  AddVillaConfig = 'ADD_VILLA_CONFIGURATION',
  GetQuote = 'GENERATE_QUOTE',
  PartyCreationPending = 'PENDING_PARTY_ORDER_CREATION',
  InitialPaymentPending = 'PENDING_INITIAL_PAYMENT',
  SurveyInProgress = 'SURVEY_IN_PROGRESS',
  PendingAdditionalPayment = 'PENDING_PAYMENT',
  PendingSnagsClearance = 'PENDING_SNAGS_CLEARANCE',
  PendingInstallation = 'PENDING_INSTALLATION',
  Cancelled = 'CANCELLED',
  Closed = 'CLOSED',
  PendingSurvey = 'PENDING_SURVEY',
  Fail = 'FAIL',
  PaymentReversel = 'PAYMENT_REVERSEL',
  PLAN_DETAILS = 'PLAN_DETAILS',
  ORDER_REVIEW = 'ORDER_REVIEW',
  CHOOSE_PLAN = 'CHOOSE_PLAN'
}

export enum OrderStatusVal {
  ADD_VILLA_DOCUMENTS = 1,
  ADD_VILLA_MNBLK_FLOORS = 2,
  ADD_VILLA_ANNEX_FLOORS = 3,
  ADD_VILLA_CONFIGURATION = 4,
  GENERATE_QUOTE = 5,
  PENDING_PARTY_ORDER_CREATION = 6,
  PENDING_INITIAL_PAYMENT = 7,
  SURVEY_IN_PROGRESS = 8,
  PENDING_PAYMENT = 9,
  PENDING_SNAGS_CLEARANCE = 10,
  PENDING_INSTALLATION = 11,
  CANCELLED = 12,
  CLOSED = 13,
  FAIL = 14,
  CHOOSE_PLAN = 15,
  PLAN_DETAIL = 16,
  ORDER_REVIEW = 17

}

export enum OrderPaymentStatus {
  Successful = 'SUCCESSFUL',
  Pending = 'PENDING',
  Failed = 'FAILED',
  PendingOffline = 'PENDING_OFFLINE',
}

export enum RequestStatus {
  PendingSurvey = 'pending survey',
  PendingPayment = 'pending payment',
  PendingSnagsClearance = 'pending snaglist',
  PendingInstallation = 'pending installation',
  OrderClosed = 'close',
  OrderCancelled = 'cancel',
  OrderFailed = 'fail'
}

export enum RequestStatusVal {
  PendingSurvey = 1,
  PendingPayment = 2,
  PendingSnagsClearance = 3,
  PendingInstallation = 4,
  OrderClosed = 5,
  OrderCancelled = 6,
  OrderFailed = 7
}

export enum HttpResponseStatus {
  INTERNAL_SERVER_ERROR = 'INTERNAL_SERVER_ERROR'
}

export enum PlanType{
  CUSTOM = 'CUSTOM',
  MONTHLY = 'MONTHLY'
}

export enum PlanCategory{
  BASIC = 'BASIC',
  ADVANCE = 'ADVANCE'
}

export enum PlanContractDuration{
  MONTHS_12 = 'MONTHS_12',
  MONTHS_24 = 'MONTHS_24',
  ONETIME = 'ONETIME'
}

export enum CPS_CODES_12_MONTHS {
  MONTHS_12 = 6763
}

export enum CPS_CODES_24_MONTHS {
  MONTHS_24 = 6770
}

