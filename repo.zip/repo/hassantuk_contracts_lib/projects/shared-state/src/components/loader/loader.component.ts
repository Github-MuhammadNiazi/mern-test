import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  Renderer2,
} from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hassantuk-loader',
  imports: [CommonModule],
  templateUrl: './loader.component.html',
  styleUrl: './loader.component.css'
})
export class HassantukLoaderComponent implements OnInit, OnChanges {
  visible = false;
  @Input() message = '';
  @Input() variant: 'default' | 'small' | 'large' = 'default';
  @Input() customClass = '';
  @Input() spinnerColor = '';
  @Input() textColor = '';
  @Input() backgroundColor = '';
  @Input() width = '';
  @Input() height = '';
  @Input()
  get isVisible (): boolean {
    return this.visible;
  }
  set isVisible (value: boolean) {
    this.visible = value;
    this.updateVisibility();
  }
  @Output() isVisibleChange = new EventEmitter<boolean>();

  constructor (private elementRef: ElementRef, private renderer: Renderer2) {}

  ngOnInit (): void {
    this.adaptToParent();
    this.applyVariant();
    this.applyCustomColors();
    this.applyCustomDimensions();
  }

  ngOnChanges (): void {
    this.applyVariant();
    this.applyCustomColors();
    this.applyCustomDimensions();
  }

  private adaptToParent (): void {
    const parentElement = this.elementRef.nativeElement.parentElement;

    if (parentElement) {
      // Ensure parent has relative positioning for absolute positioning to work
      const parentPosition = getComputedStyle(parentElement).position;
      if (parentPosition === 'static') {
        this.renderer.setStyle(parentElement, 'position', 'relative');
      }

      // Auto-detect colors from parent if not explicitly provided
      if (!this.textColor) {
        const parentColor = getComputedStyle(parentElement).color;
        this.textColor = parentColor || '#242424';
      }

      // Check if parent has business class for theme detection
      const hasBusinessClass = parentElement.closest('.business') !== null;
      if (hasBusinessClass && !this.spinnerColor) {
        this.spinnerColor = '#cfb43b';
      } else if (!this.spinnerColor) {
        this.spinnerColor = '#b68a35';
      }
    }
  }

  private applyVariant (): void {
    const container = this.elementRef.nativeElement.querySelector(
      '.hassantuk-loader-container'
    );
    if (container) {
      // Remove existing variant classes
      container.classList.remove('dark', 'small', 'large');

      // Add current variant class
      if (this.variant !== 'default') {
        container.classList.add(this.variant);
      }
    }
  }

  private applyCustomColors (): void {
    const container = this.elementRef.nativeElement.querySelector(
      '.hassantuk-loader-container'
    );
    const spinner =
      this.elementRef.nativeElement.querySelector('.hassantuk-spinner');
    const message = this.elementRef.nativeElement.querySelector(
      '.hassantuk-loader-message'
    );

    if (container && this.backgroundColor) {
      this.renderer.setStyle(
        container,
        'background-color',
        this.backgroundColor
      );
    }

    if (spinner && this.spinnerColor) {
      this.renderer.setStyle(spinner, 'border-top-color', this.spinnerColor);
    }

    if (message && this.textColor) {
      this.renderer.setStyle(message, 'color', this.textColor);
    }
  }

  private applyCustomDimensions (): void {
    const container = this.elementRef.nativeElement.querySelector(
      '.hassantuk-loader-container'
    );

    if (container) {
      if (this.width) {
        this.renderer.setStyle(container, 'width', this.width);
      }

      if (this.height) {
        this.renderer.setStyle(container, 'height', this.height);
      }
    }
  }

  show (): void {
    this.isVisible = true;
    this.isVisibleChange.emit(this.visible);
  }

  hide (): void {
    this.isVisible = false;
    this.isVisibleChange.emit(this.visible);
  }

  toggle (): void {
    this.isVisible = !this.visible;
    this.isVisibleChange.emit(this.visible);
  }

  private updateVisibility (): void {
    const container = this.elementRef.nativeElement.querySelector(
      '.hassantuk-loader-container'
    );

    if (container) {
      this.renderer.setStyle(
        container,
        'display',
        this.visible ? 'flex' : 'none'
      );
    }
  }
}
