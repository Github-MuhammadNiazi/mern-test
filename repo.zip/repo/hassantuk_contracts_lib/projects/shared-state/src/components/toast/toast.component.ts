import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { languageDirectionality, languages } from '../../lib/utilities/constants';
import { CommonModule } from '@angular/common';
import { TranslationService } from '../../lib/translation.service';

export type ToastType = 'success' | 'warning' | 'error';
export type ToastSize = 'small' | 'medium' | 'full';
export type ToastPosition = 'top-left' | 'top-center' | 'top-right' | 'middle-left' | 'middle-center' | 'middle-right' | 'bottom-left' | 'bottom-center' | 'bottom-right';
export type ToastSlideFrom = 'left' | 'right' | 'top' | 'bottom';
export type ToastFadeFrom = 'left' | 'right' | 'top' | 'bottom' | 'center';

export interface ToastConfig {
  title: string;
  message: string;
  type: ToastType;
  duration?: number;
  size?: ToastSize;
  position?: ToastPosition;
  customWidth?: string;
  slideFrom?: ToastSlideFrom;
  fadeFrom?: ToastFadeFrom;
}

@Component({
  selector: 'ht-toast',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.css'],
  encapsulation: ViewEncapsulation.None,
  host: { 'class': 'ht-toast' }
})
export class ToastComponent implements OnInit, OnDestroy {
  @Input() config!: ToastConfig;
  @Input() animationType: 'fade' | 'slide' = 'slide';
  @Output() closed = new EventEmitter<void>();

  private timeoutId?: number;
  public isVisible = false;

  constructor (private translationService: TranslationService) {}

  ngOnInit () {
    // Trigger animation
    setTimeout(() => {
      this.isVisible = true;
    }, 10);

    const duration = this.config.duration || 3000;
    this.timeoutId = window.setTimeout(() => {
      this.close();
    }, duration);
  }

  ngOnDestroy () {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  close () {
    this.isVisible = false;
    // Wait for animation to complete before emitting closed event
    setTimeout(() => {
      this.closed.emit();
    }, 300);
  }

  getIconPath (): string {
    const iconMap = {
      success: './assets/icons/success-icon.svg',
      warning: './assets/icons/warning-icon.svg',
      error: './assets/icons/error-icon.svg'
    };
    return iconMap[this.config.type];
  }

  getIconAlt (): string {
    const altMap = {
      success: 'Success',
      warning: 'Warning',
      error: 'Error'
    };
    return altMap[this.config.type];
  }

  getToastTitle (): string {
    if (this.config.type === 'success') {
      return this.config.title || 'Success';
    }
    return this.config.title || 'Oops!';
  }

  getToastClasses (): string {
    const baseClasses = 'alert d-flex align-items-center w-100';
    const typeClass = this.config.type; // success, warning, error
    const sizeClass = this.getSizeClass();
    const positionClass = this.getPositionClass();
    const animationClass = this.getAnimationClass();

    return `${baseClasses} ${typeClass} ${sizeClass} ${positionClass} ${animationClass}`;
  }

  private getAnimationClass (): string {
    const baseAnimation = `toast-${this.animationType}`;
    const visibilityClass = this.isVisible ? 'toast-visible' : 'toast-hidden';
    const directionClass = this.getAnimationDirection();
    return `${baseAnimation} ${visibilityClass} ${directionClass}`.trim();
  }

  private getAnimationDirection (): string {
    if (this.animationType === 'slide') {
      const slideFrom = this.config.slideFrom || this.getDefaultSlideDirection();
      return `toast-slide-${slideFrom}`;
    } else if (this.animationType === 'fade') {
      const fadeFrom = this.config.fadeFrom || this.getDefaultFadeDirection();
      return `toast-fade-${fadeFrom}`;
    }
    return '';
  }

  private getDefaultSlideDirection (): ToastSlideFrom {
    const currentLanguage = this.translationService.getCurrentLanguage();
    // Arabic: slide from left, English: slide from right
    return currentLanguage === languages.arabic ? languageDirectionality.left : languageDirectionality.right;
  }

  private getDefaultFadeDirection (): ToastFadeFrom {
    const currentLanguage = this.translationService.getCurrentLanguage();
    // Arabic: fade from left, English: fade from right
    return currentLanguage === languages.arabic ? languageDirectionality.left : languageDirectionality.right;
  }

  private getSlideDirection (): string {
    const slideFrom = this.config.slideFrom || 'right';
    return `toast-slide-${slideFrom}`;
  }

  private getSizeClass (): string {
    if (this.config.customWidth) {
      return 'custom-width';
    }

    const sizeMap = {
      small: 'toast-small',
      medium: 'toast-medium',
      full: 'toast-full'
    };
    return sizeMap[this.config.size || 'medium'];
  }

  private getPositionClass (): string {
    const position = this.config.position || 'top-right';
    return `toast-${position}`;
  }

  getCustomStyles (): object {
    if (this.config.customWidth) {
      return { width: this.config.customWidth };
    }
    return {};
  }
}
