import { ApplicationRef, ComponentRef, EnvironmentInjector, Injectable, createComponent } from '@angular/core';
import { ToastComponent, ToastConfig, ToastFadeFrom, ToastPosition, ToastSize, ToastSlideFrom } from './toast.component';
import { languageDirectionality, languages } from '../../lib/utilities/constants';
import { TranslationService } from '../../lib/translation.service';

export interface ToastOptions {
  duration?: number;
  size?: ToastSize;
  position?: ToastPosition;
  customWidth?: string;
  animationType?: 'fade' | 'slide';
  slideFrom?: ToastSlideFrom;
  fadeFrom?: ToastFadeFrom;
}

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  private toastContainers = new Map<ToastPosition, HTMLElement>();
  private activeToasts = new Set<ComponentRef<ToastComponent>>();

  constructor (
    private appRef: ApplicationRef,
    private environmentInjector: EnvironmentInjector,
    private translationService: TranslationService
  ) {}

  /**
   * Show a success toast
   */
  success (title: string, message: string, options?: ToastOptions): void {
    this.showToast({
      title,
      message,
      type: 'success',
      ...options
    });
  }

  /**
   * Show an error toast
   */
  error (title: string, message: string, options?: ToastOptions): void {
    this.showToast({
      title,
      message,
      type: 'error',
      ...options
    });
  }

  /**
   * Show a warning toast
   */
  warning (title: string, message: string, options?: ToastOptions): void {
    this.showToast({
      title,
      message,
      type: 'warning',
      ...options
    });
  }

  /**
   * Show a toast with custom configuration
   */
  show (config: ToastConfig, options?: ToastOptions): void {
    this.showToast({
      ...config,
      ...options
    });
  }

  /**
   * Clear all active toasts
   */
  clear (): void {
    this.activeToasts.forEach(toast => {
      this.removeToast(toast);
    });
  }

  /**
   * Translate text if translation exists, otherwise return the original text
   */
  private translateText (text: string): string {
    const translated = this.translationService.translateSync(text);
    // If translation service returns the same key, it means no translation exists
    return translated !== text ? translated : text;
  }

  private showToast (config: ToastConfig & ToastOptions): void {
    const position = config.position || 'top-right';
    const container = this.getOrCreateContainer(position);

    // Translate title and message if translations exist
    const translatedTitle = this.translateText(config.title);
    const translatedMessage = this.translateText(config.message);

    // Get language-based defaults
    const currentLanguage = this.translationService.getCurrentLanguage();
    const defaultSlideFrom = currentLanguage === languages.arabic ? languageDirectionality.left : languageDirectionality.right;
    const defaultFadeFrom = currentLanguage === languages.arabic ? languageDirectionality.left : languageDirectionality.right;

    // Create component
    const componentRef = createComponent(ToastComponent, {
      environmentInjector: this.environmentInjector
    });

    // Set component inputs
    componentRef.instance.config = {
      title: translatedTitle,
      message: translatedMessage,
      type: config.type,
      duration: config.duration || 3000,
      size: config.size || 'medium',
      position: position,
      customWidth: config.customWidth,
      slideFrom: config.slideFrom || defaultSlideFrom,
      fadeFrom: config.fadeFrom || defaultFadeFrom,
    };

    componentRef.instance.animationType = config.animationType || 'slide';

    // Handle close event
    const subscription = componentRef.instance.closed.subscribe(() => {
      this.removeToast(componentRef);
      subscription.unsubscribe();
    });

    // Attach to DOM
    container.appendChild(componentRef.location.nativeElement);
    this.appRef.attachView(componentRef.hostView);
    this.activeToasts.add(componentRef);

    // Trigger change detection
    componentRef.changeDetectorRef.detectChanges();
  }

  private getOrCreateContainer (position: ToastPosition): HTMLElement {
    if (this.toastContainers.has(position)) {
      return this.toastContainers.get(position)!;
    }

    const container = document.createElement('div');
    container.className = `toast-container toast-${position}`;
    document.body.appendChild(container);

    this.toastContainers.set(position, container);
    return container;
  }

  private removeToast (componentRef: ComponentRef<ToastComponent>): void {
    this.activeToasts.delete(componentRef);
    this.appRef.detachView(componentRef.hostView);
    componentRef.destroy();
  }
}
