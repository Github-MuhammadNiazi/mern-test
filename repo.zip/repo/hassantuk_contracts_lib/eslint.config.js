// @ts-check
const eslint = require("@eslint/js");
const tseslint = require("typescript-eslint");
const angular = require("angular-eslint");

module.exports = tseslint.config(
  {
    ignores: ["dist/**", "node_modules/**", "**/*.d.ts"],
  },
  {
    files: ["**/*.ts"],
    extends: [
      eslint.configs.recommended,
      ...tseslint.configs.recommended,
      ...tseslint.configs.stylistic,
      ...angular.configs.tsRecommended,
    ],
    processor: angular.processInlineTemplates,
    rules: {
      "prefer-arrow-callback": "error", // Enforce arrow functions as callbacks
      "no-useless-return": "error", // Disallow return statements that do not return a value
      "indent": ["error", 2], // Enforce consistent indentation (2 spaces)
      "space-before-function-paren": ["error", "always"], // Require space before function parentheses
      "no-mixed-spaces-and-tabs": "error", // Disallow mixing spaces and tabs for indentation
      "no-trailing-spaces": "error", // Disallow trailing whitespace at the end of lines
      "eol-last": ["error", "always"], // Enforce at least one newline at the end of files
      "semi": ["error", "always"], // Require semicolons
      "prefer-const": "error", // Suggest using const when a variable is never reassigned
      "no-unused-expressions": "error", // Disallow expressions with no effect
      "no-empty-function": "error", // Disallow empty functions
      "camelcase": ["error", { properties: "always" }], // Enforce camelCase naming convention
      "no-underscore-dangle": ["error", { allowAfterThis: false }], // Disallow dangling underscores in identifiers
      "sort-imports": [
        "error",
        {
          ignoreCase: false,
          ignoreDeclarationSort: true,
          memberSyntaxSortOrder: ["none", "all", "multiple", "single"],
        },
      ], // Enforce sorting of import statements
      "no-duplicate-imports": "error", // Disallow duplicate imports from the same module
      "@angular-eslint/prefer-inject": "off", // Disable prefer inject rule for now
    }
  }
);