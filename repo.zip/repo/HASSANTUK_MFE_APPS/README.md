# HASSANTUK_MFE_APPS

## Overview
HASSANTUK_MFE_APPS is a collection of Micro Frontends (MFEs) that are dynamically loaded into relevant shell applications using Angular's Native Federation. This project aims to provide modular and scalable solutions for enterprise applications.

## Prerequisites
- Angular CLI: 19.2.14
- Node: 22.17.1
- Package Manager: npm 10.9.2
- Native federation: 20.0.6

## Project Setup
Step-by-step instructions for setting up the project locally:
1. Clone the repository:
   ```bash
   git clone https://github.etisalat.corp.ae/NNADEEM/HASSANTUK_MFE_APPS.git
   ```
2. Navigate to MFE
    ```bash
    cd mfe-name
    ```
3. Install dependencies:
   ```bash
   npm install
   ```
## Running the Application
Instructions for running the application:
1. Start the development server:
   ```bash
   npm start
   ```
2. Access the application at 
   ```bash
   localhost:port
   ```
   Note: The port is defined in the angular.json file under the serve options. Update it if necessary.

## Adding a new MFE aka Remote
   **Create new  MFE - strict versions**
   ```bash
1.  ng new my-mfe --standalone --routing --style=scss 
2.  cd my-mfe 
3.  npm install @angular/animations@19.2.14 \
@angular/common@19.2.14 \
@angular/compiler@19.2.14 \
@angular/core@19.2.14 \
@angular/forms@19.2.14 \
@angular/platform-browser@19.2.14 \
@angular/platform-browser-dynamic@19.2.14 \
@angular/router@19.2.14 \
@angular/cli@19.2.14 --save
4.  npm i @angular-architects/native-federation@20.0.6 --save-dev 
5.  ng add @angular-architects/native-federation --project my-mfe --type remote --port 4301 
6.  check if native federation version is `20.0.6` otherwise change it to `20.0.6`
7.  ng s
```

## Deployment
    Steps for deploying the application to production.
## Contributing
- Clone the repository.
- Switch to `main` branch
- Pull/Fetch from `main`
- Create a feature branch from `main`:
  ```bash
  git checkout -b feature/<feature-name>
  ```
- Commit your changes and push to your branch.
- Submit a pull request for review.

## Useful Links
- [Angular Native Federation Documentation](https://www.npmjs.com/package/@angular-architects/native-federation)
- [Node.js Download](https://nodejs.org/)