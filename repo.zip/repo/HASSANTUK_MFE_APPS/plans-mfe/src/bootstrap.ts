import { PlansComponent } from './app/plans.component';
import { appConfig } from './app/app.config';
import { bootstrapApplication } from '@angular/platform-browser';

bootstrapApplication(PlansComponent, appConfig)
  .catch((err) => console.error(err));
