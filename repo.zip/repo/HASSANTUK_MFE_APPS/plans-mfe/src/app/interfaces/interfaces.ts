import { Models } from 'shared-state';

export interface ApiResponse<T> {
  status: string;
  data: T;
  message: string;
  accepted: boolean;
}
export interface AllocatedDvcI{
  name: string,
  count: number,
  image: string,
  type?: string
}

export interface DevicesConfig {
  smokedetector?: string[];
  siren?: string[];
  heatdetector?: string[];
  wirelessrepeater?: string[];
  atepay?: string[];
}

export interface Product {
  locale?: null;
  id?: number;
  defaultName?: string;
  labelAr?: null;
  labelEn?: null | string;
  deviceSpecificationsImportIdentifer?: string;
  description?: null;
  min?: null;
  max?: null;
  deviceSpecifications?: DeviceSpecification[];
  subProducts?: SubProduct[];
  test?: string;
  deviceSpecs?: DeviceSpec[];
  totalDevicesPrice?: number;
  totalSubsidizedDevicesPrice?: number;
  serviceSpecs?: ServiceSpec[];
  totalServicesPrice?: number;
  totalBuffer?: number;
  totalSubsidizedBuffer?: number;
  totalPrice?: number;
  totalSubsidizedPrice?: number;
  totalVatPrice?: number;
  againstOrder?: Models.OrderModel;
  subsidyApplied?: boolean;
  totalCalculatedPrice?: number; // added now
}

export interface ServiceSpec {
  locale?: null;
  unit?: number;
  unitPrice: string;
  unitSubsidizedPrice?: null;
  unitPriceForCalc?: number;
  vat?: number;
  subsidizedVat?: number;
  vatPercentage?: number;
  totalPrice?: string;
  totalSubsidizedPrice?: null;
  serviceType?: string;
  serviceCode?: string;
  serviceLabel?: string;
}

export interface DeviceSpec {
  locale?: null;
  unit?: number;
  unitPrice: string;
  unitSubsidizedPrice?: null;
  unitPriceForCalc?: number;
  vat?: number;
  subsidizedVat?: number;
  vatPercentage?: number;
  totalPrice?: string;
  totalSubsidizedPrice?: null;
  buildingType?: string;
  buildingLabel?: string;
  floorNumber?: string;
  floorLabel?: string;
  roomType?: string;
  roomLabel?: string;
  deviceCode?: string;
  deviceLabel?: null;
  description?: string;
  visible?: boolean;
  subsidizedAccounts?: null;
  additionalDevice?: boolean;
}

export interface SubProduct {
  id?: number;
  defaultName?: string;
  labelAr?: null;
  labelEn?: string;
  deviceSpecificationsImportIdentifer?: string;
  description?: null;
  min?: number | null;
  max?: number | null;
  deviceSpecifications?: DeviceSpecification[];
  creationDate?: string;
  lastUpdateDate?: string;
  subProducts?: [];
}

export interface DeviceSpecification {
  id?: number;
  code?: string;
  deviceLabelAr?: null;
  deviceLabelEn?: string;
  description?: string;
  type?: string;
  expired?: boolean;
  taxCode?: string;
  taxType?: null | string;
  taxDescription?: null;
  taxNature?: null | string;
  taxPercentage?: number | null;
  chargeDetails?: ChargeDetail[];
  specAttributes?: [];
}

export interface ChargeDetail {
    id?:                number;
    type?:              ChargeDetailType;
    description?:       null | string;
    amount?:            number;
    preset?:            number | null;
    offset?:            number | null;
    saleFromDate?:      null | string;
    saleTillDate?:      null;
    proratingRequired?: boolean;
}

export enum ChargeDetailType {
    Onetime = "ONETIME",
    Prepaymentamount = "PREPAYMENTAMOUNT",
    Recurring = "RECURRING",
}
