import { PlansComponent } from './plans.component';
import { Routes } from '@angular/router';

export const routes: Routes = [{ path: '', component: PlansComponent }];
