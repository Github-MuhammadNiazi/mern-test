import { PlansComponent } from './plans.component';
import { TestBed } from '@angular/core/testing';


describe('PlansComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PlansComponent],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(PlansComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have the 'plans-mfe' title`, () => {
    const fixture = TestBed.createComponent(PlansComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('plans-mfe');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(PlansComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h1')?.textContent).toContain('Hello, plans-mfe');
  });
});
