import { Component, ElementRef, Input, OnChanges, OnInit, QueryList, SimpleChanges, ViewChildren } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateAsyncPipe } from 'shared-state';

@Component({
  selector: 'app-rooms-selector',
  imports: [CommonModule,TranslateAsyncPipe],
  templateUrl: './rooms-selector.component.html',
  styleUrl: './rooms-selector.component.scss'
})
export class RoomsSelectorComponent implements OnChanges, OnInit{

  @Input() roomsCount = 0;
  selectedRoom = '';
  // @Output() roomSelected= new EventEmitter<string>();

  @ViewChildren('roomInput') roomInputs!: QueryList<ElementRef<HTMLInputElement>>;

  ngOnInit (): void {
    this.updateSelectedRoom();
  }


  /**
   * Executes everytime smokedetector count changes
   * @param changes
   */
  ngOnChanges (changes: SimpleChanges): void {
    if(changes['roomsCount']){
      this.updateSelectedRoom();
    }
  }

  updateSelectedRoom (){
    if (this.roomsCount >= 1 && this.roomsCount <= 3) {
      this.selectedRoom = '1-3';
    } else if (this.roomsCount >= 4 && this.roomsCount <= 6) {
      this.selectedRoom = '4-6';
    } else if (this.roomsCount >= 7 && this.roomsCount <= 9) {
      this.selectedRoom = '7-9';
    } else if (this.roomsCount > 9) {
      this.selectedRoom = 'custom';
    } else {
      this.selectedRoom = '';
    }
  }

  // DO NOT DELETE THIS
  // ngAfterViewInit (): void {
  //   this.roomInputs.forEach((input: ElementRef<HTMLInputElement>, index: number) => {
  //     input.nativeElement.addEventListener('change', () => {
  //       switch (index) {
  //       case 0: this.roomSelected.emit('1-3'); break;
  //       case 1: this.roomSelected.emit('4-6'); break;
  //       case 2: this.roomSelected.emit('7-9'); break;
  //       case 3: this.roomSelected.emit('custom'); break;
  //       }
  //     });
  //   });
  // }

}
