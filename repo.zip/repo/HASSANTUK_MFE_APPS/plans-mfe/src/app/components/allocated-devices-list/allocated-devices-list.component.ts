import { AllocatedDvcI, Product } from '../../interfaces/interfaces';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component,Input, OnInit, Signal, inject  } from '@angular/core';
import { TranslateAsyncPipe, TranslationService } from 'shared-state';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../services/order-service';
import {toSignal} from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-allocated-devices-list',
  imports: [ CommonModule, TranslateAsyncPipe],
  templateUrl: './allocated-devices-list.component.html',
  styleUrl: './allocated-devices-list.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AllocatedDevicesListComponent implements OnInit{
  @Input () plans: Product[] = [];
  orderSvc = inject(OrderService);
  private cdr = inject(ChangeDetectorRef);
  private translationSvc = inject(TranslationService);
  devices: AllocatedDvcI[] = [];

  ngOnInit (): void {
    this.orderSvc.currentOrderObv$.subscribe(() => {
      this.loadDevices();
      this.cdr.detectChanges();
    });
  }

  readonly lblSmokeDetector: Signal<string> = toSignal(
    this.translationSvc.translate$('label.somkDetector'),
    {initialValue: ''}
  );

  readonly lblRepeater: Signal<string> = toSignal(
    this.translationSvc.translate$('label.repeater'),
    {initialValue: ''}
  );

  readonly lblHeatDetector: Signal<string> = toSignal(
    this.translationSvc.translate$('label.heatDetector'),
    {initialValue: ''}
  );

  readonly lblAlarm: Signal<string> = toSignal(
    this.translationSvc.translate$('label.FireAlaramPanel'),
    {initialValue: ''}
  );

  getLabels (device : AllocatedDvcI){
    switch(device.type){
    case 'smoke': return this.lblSmokeDetector();
    case 'repeater': return this.lblRepeater();
    case 'heat': return this.lblHeatDetector();
    case 'panel': return this.lblAlarm();
    }
    return '';
  }

  loadDevices () {
    this.devices = [
      {
        name: this.lblSmokeDetector(), // 'Smoke Detector',
        count: this.orderSvc.countTotalSmokeDetectors(this.plans), // pass plans if needed
        image: '../../images/media/product/smoke-detector.png',
        type: 'smoke'
      },
      {
        name: 'Wireless Repeater',
        count: this.orderSvc.countTotalWirelessRepeater(this.plans),
        image: '../../images/media/product/wireless-reapter.png',
        type: 'repeater'
      },
      {
        name: 'Heat Detector',
        count: this.orderSvc.countTotalHeatDetectors(this.plans),
        image: '../../images/media/product/heat-detector.png',
        type: 'heat'
      },
      {
        name: 'Alarm Panel',
        count: 1, // always at least one
        image: '../../images/media/product/alarm.png',
        type: 'panel'
      }
    ];
  }


  increment (device: AllocatedDvcI) {
    switch (device.type) {
    case "smoke":
    {
      if(!this.orderSvc.getIsAddMoreDevicesEnabled())
        this.orderSvc.addAdditionalDevices(this.orderSvc.extractAdditionalWirelessSmokeDetectorRatePlan(this.orderSvc.preSelectedBundle()));
      else
        this.orderSvc.addAdditionalDevices(this.orderSvc.extractAdditionalWirelessSmokeDetectorRatePlan(this.orderSvc.getOneTimePlan()));
      break;
    }
    case "repeater":  {
      if(!this.orderSvc.getIsAddMoreDevicesEnabled())
        this.orderSvc.addAdditionalDevices(this.orderSvc.extractAdditionalWirelessRepeaterRatePlan(this.orderSvc.preSelectedBundle()));
      else
        this.orderSvc.addAdditionalDevices(this.orderSvc.extractAdditionalWirelessRepeaterRatePlan(this.orderSvc.getOneTimePlan()));
      break;
    }
    case "heat": {
      if(!this.orderSvc.getIsAddMoreDevicesEnabled())
        this.orderSvc.addAdditionalDevices(this.orderSvc.extractAdditionalHeatDetectorRatePlan(this.orderSvc.preSelectedBundle()));
      else
        this.orderSvc.addAdditionalDevices(this.orderSvc.extractAdditionalHeatDetectorRatePlan(this.orderSvc.getOneTimePlan()));
      break;
    }
    case "panel": break;
    }

    device.count++;
  }

  decrement (device: AllocatedDvcI) {
    switch (device.type) {
    case "smoke":
    {
      if(!this.orderSvc.getIsAddMoreDevicesEnabled())
        this.orderSvc.removeAdditionalDevices(this.orderSvc.extractAdditionalWirelessSmokeDetectorRatePlan(this.orderSvc.preSelectedBundle()));
      else
        this.orderSvc.removeAdditionalDevices(this.orderSvc.extractAdditionalWirelessSmokeDetectorRatePlan(this.orderSvc.getOneTimePlan()));
      break;
    }
    case "repeater":  {
      if(!this.orderSvc.getIsAddMoreDevicesEnabled())
        this.orderSvc.removeAdditionalDevices(this.orderSvc.extractAdditionalWirelessRepeaterRatePlan(this.orderSvc.preSelectedBundle()));
      else
        this.orderSvc.removeAdditionalDevices(this.orderSvc.extractAdditionalWirelessRepeaterRatePlan(this.orderSvc.getOneTimePlan()));
      break;
    }
    case "heat": {
      if(!this.orderSvc.getIsAddMoreDevicesEnabled())
        this.orderSvc.removeAdditionalDevices(this.orderSvc.extractAdditionalHeatDetectorRatePlan(this.orderSvc.preSelectedBundle()));
      else
        this.orderSvc.removeAdditionalDevices(this.orderSvc.extractAdditionalHeatDetectorRatePlan(this.orderSvc.getOneTimePlan()));
      break;
    }
    case "panel": break;
    }

    device.count--;
  }


  isAddDeviceDisabled (device: AllocatedDvcI) {
    switch(device.type){
    case "smoke":
      return this.orderSvc.countTotalSmokeDetectors(this.plans) == this.orderSvc.getmaxRooms();
    case "repeater":
      return this.orderSvc.countTotalWirelessRepeater(this.plans) == this.orderSvc.getMaxFloors();
    case "heat":
      return this.orderSvc.countTotalHeatDetectors(this.plans) == this.orderSvc.getMaxKitchens();
    case "panel":
      return true;
    }
    return true;
  }

  isRemoveDeviceDisabled (device: AllocatedDvcI){
    switch(device.type){
    case "smoke":
      return this.orderSvc.disableSmokeDetectors(this.plans);
    case "repeater":
      return this.orderSvc.disableWirelessRepeator(this.plans);
    case "heat":
      return this.orderSvc.disableHeatDetectors(this.plans);
    case "panel":
      return true;
    }
    return false;
  }

  trackByName (index: number, device: AllocatedDvcI) {
    return device.name;
  }
}
