import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocatedDevicesListComponent } from './allocated-devices-list.component';

describe('AllocatedDevicesListComponent', () => {
  let component: AllocatedDevicesListComponent;
  let fixture: ComponentFixture<AllocatedDevicesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AllocatedDevicesListComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(AllocatedDevicesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
