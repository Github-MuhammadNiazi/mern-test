import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../services/order-service';
import { Product } from '../../interfaces/interfaces';
import { TranslateAsyncPipe } from 'shared-state';

@Component({
  selector: 'app-checkout-summary',
  imports: [CommonModule, TranslateAsyncPipe],
  templateUrl: './checkout-summary.component.html',
  styleUrl: './checkout-summary.component.scss'
})
export class CheckoutSummaryComponent {
    @Input () plans: Product[] = [];
    @Output() checkout= new EventEmitter<string>();
    orderSvc = inject(OrderService);

    proceedToCheckout (){
      this.checkout.emit('checkout');
    }

    getTotalAmount () {
      const bundle = this.orderSvc.preSelectedBundle();
      const charges = this.orderSvc.calculateAggregatedMonthlyCharges( bundle, this.plans);
      return charges;
    }
}
