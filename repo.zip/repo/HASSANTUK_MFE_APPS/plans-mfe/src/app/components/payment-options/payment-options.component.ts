
import { ChangeDetectionStrategy, Component,  EventEmitter,  Input, OnInit, Output, inject } from '@angular/core';
import { ChargeDetail, Product, SubProduct } from '../../interfaces/interfaces';
import {  CommonModule } from '@angular/common';

import { OrderService } from '../../services/order-service';
import { PlanDuration } from '../../configs/order-rate-plan.config';
import { TranslateAsyncPipe } from 'shared-state';

@Component({
  standalone: true,
  selector: 'app-payment-options',
  templateUrl: './payment-options.component.html',
  imports: [TranslateAsyncPipe, CommonModule],
  styleUrl: './payment-options.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentOptionsComponent implements OnInit{

  @Input () plans: Product[] = [];
  @Input () oneTimePlan?: Product = undefined;
  @Output() planSelect = new EventEmitter<Product>();
  private orderSvc = inject(OrderService);
  selectedPlan?: Product = {};

  ngOnInit (): void {
    // one time selected by default
    this.selectedPlan = this.plans[2];
    this.orderSvc.setOneTimePaymentBundleInCurrentOrder();
  }

  selectPlan (plan: Product){
    if(plan){
      this.selectedPlan = plan;
      this.planSelect.emit(plan);
    }
  }

  extractMonthlyRecurringCharges (product: Product | SubProduct | undefined) {
    if (!product)
      return 0;
    if (product.defaultName) {
      if (this.orderSvc.currentOrder.transferFlow){
        return 40.95;
      } else {
        if (product.deviceSpecifications && product.deviceSpecifications.length > 0
          && product.deviceSpecifications[0].chargeDetails && product.deviceSpecifications[0].chargeDetails.length > 0) {
          const charge = product.deviceSpecifications[0].chargeDetails.find((charge : ChargeDetail) => charge.type == "RECURRING");
          return (charge && charge.amount) ? charge.amount * 1.05 : 0;
        } else
          return 0;
      }
    } else {
      if (this.orderSvc.currentOrder.transferFlow){
        return 435.75;
      } else {
        return this.oneTimePlan ? this.orderSvc.calculateAggregatedMonthlyChargesForOneTimePayment(this.plans) : 0.0;
      }
    }
  }

  getMonthlyPlanRates (plan: Product) {
    if (plan.defaultName) {
      if (plan.defaultName === PlanDuration.CPS_MOI12M_NEW) //twelveMonthCPSPackage)
        return plan.subProducts?.find((x: SubProduct) => x.defaultName == "RPMOIPOST12") ;
      else if (plan.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return plan.subProducts?.find((x: SubProduct) => x.defaultName == "RPMOIPOST24");
    }
    return this.oneTimePlan;
  }

}
