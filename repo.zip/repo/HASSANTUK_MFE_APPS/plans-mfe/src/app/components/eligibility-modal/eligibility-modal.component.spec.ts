import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EligibilityModalComponent } from './eligibility-modal.component';

describe('EligibilityModalComponent', () => {
  let component: EligibilityModalComponent;
  let fixture: ComponentFixture<EligibilityModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EligibilityModalComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(EligibilityModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
