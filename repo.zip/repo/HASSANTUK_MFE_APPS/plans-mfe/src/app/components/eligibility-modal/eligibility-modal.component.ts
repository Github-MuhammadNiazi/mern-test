import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare const bootstrap: any;
@Component({
  selector: 'app-eligibility-modal',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './eligibility-modal.component.html',
  styleUrl: './eligibility-modal.component.scss'
})

export class EligibilityModalComponent implements OnInit {
 @Input() isAuthenticated = false;
  @Input() userPhoneNumber?: string;
  @Output() verify = new EventEmitter<string>();
  eligibilityForm!: FormGroup;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private modalInstance?: any;

  private fb = inject(FormBuilder);
 @ViewChild('loginModal', { static: false }) loginModal!: ElementRef;

 showModal (): void {
   this.modalInstance = new bootstrap.Modal(this.loginModal.nativeElement);
   this.modalInstance.show();
 }

 hideModal (): void {
   if(this.modalInstance){
     this.modalInstance.hide();
     this.modalInstance = undefined;
   }
 }
 ngOnInit (): void {
   this.eligibilityForm = this.fb.group({
     phone: [
       '',
       [
         Validators.required,
         Validators.pattern(/^0[5][0-9]{8}$/), // UAE mobile pattern example
       ],
     ],
   });

   if (this.isAuthenticated && this.userPhoneNumber) {
     this.eligibilityForm.patchValue({ phone: this.userPhoneNumber });
     this.eligibilityForm.get('phone')?.disable();
     this.onVerify();
   }
 }

 onVerify () {
   if (this.eligibilityForm.invalid) {
     this.eligibilityForm.markAllAsTouched();
     return;
   }
   this.verify.emit(this.eligibilityForm.getRawValue().phone);
 }
}
