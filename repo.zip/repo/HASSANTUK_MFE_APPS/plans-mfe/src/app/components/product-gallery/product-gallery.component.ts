import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-product-gallery',
  imports: [CommonModule],
  templateUrl: './product-gallery.component.html',
  styleUrl: './product-gallery.component.scss'
})
export class ProductGalleryComponent {
  images = [
    '../../images/media/product/p1.jpg',
    '../../images/media/product/p2.jpg',
    '../../images/media/product/p3.jpg',
    '../../images/media/product/p4.jpg'
  ];

  selectedImage = this.images[0];

  changeImage (image: string) {
    this.selectedImage = image;
  }
}
