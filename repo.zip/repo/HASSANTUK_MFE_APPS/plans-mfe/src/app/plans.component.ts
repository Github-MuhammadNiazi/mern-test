/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable sort-imports */

import {
  ChangeDetectorRef,
  Component,
  Inject,
  OnInit,
  Optional,
  ViewChild,
  inject,
} from '@angular/core';
import { AllocatedDevicesListComponent } from './components/allocated-devices-list/allocated-devices-list.component';
import { CheckoutSummaryComponent } from './components/checkout-summary/checkout-summary.component';
import { Observable } from 'rxjs';
import { PaymentOptionsComponent } from './components/payment-options/payment-options.component';
import { AllocatedDvcI, DevicesConfig, Product } from './interfaces/interfaces';
import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';
import { RoomsSelectorComponent } from './components/rooms-selector/rooms-selector.component';
import { OrderService } from './services/order-service';
import { CommonModule } from '@angular/common';
import { ProductGalleryComponent } from './components/product-gallery/product-gallery.component';
import {
  HassantukLoaderComponent,
  Models,
  ToastService,
  TranslateAsyncPipe,
} from 'shared-state';
import { EligibilityModalComponent } from './components/eligibility-modal/eligibility-modal.component';
// declare const bootstrap: any;
@Component({
  selector: 'app-root',
  imports: [
    RouterOutlet,
    RoomsSelectorComponent,
    AllocatedDevicesListComponent,
    PaymentOptionsComponent,
    CheckoutSummaryComponent,
    ProductGalleryComponent,
    EligibilityModalComponent,
    CommonModule,
    HassantukLoaderComponent,
    TranslateAsyncPipe,
  ],
  templateUrl: './plans.component.html',
  styleUrl: './plans.component.scss',
})
export class PlansComponent implements OnInit {
  title = 'plans-mfe';
  loading = true;
  orderId: number | undefined;
  isAuthenticated = false;
  plans: Product[] = [];
  modal: any;
  primaryMobile: string | undefined;
  showModal = false;
  deviceDetails: DevicesConfig = {};
  oneTimePlan?: Product = undefined;
  allocatedDevicesList: AllocatedDvcI[] = [];
  private orderSvc = inject(OrderService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private toastSvc = inject(ToastService);
  private cdr = inject(ChangeDetectorRef);
  @ViewChild('contentLoader') contentLoader!: HassantukLoaderComponent;
  @ViewChild('modalLoader') modalLoader!: HassantukLoaderComponent;
  constructor (
    @Optional()
    @Inject('getPackagesCallback')
    private getPackagesCallback: () => Observable<Product[]>,

    @Optional()
    @Inject('getDeviceConfigCallback')
    private getDeviceConfigCallback: () => Observable<DevicesConfig>,

    @Optional()
    @Inject('getOrderCallback')
    private getOrderCallback: (
      orderid: number
    ) => Observable<Models.OrderModel>,

    @Optional()
    @Inject('patchOrderCallback')
    private patchOrderCallback: (
      order: Models.OrderModel
    ) => Observable<Models.OrderModel>,

    @Optional()
    @Inject('postPaidEligibilityCheckCallback')
    private postPaidEligibilityCheckCallback: (
      phoneNumber: string
    ) => Observable<any>
  ) {
    this.orderId = Number(this.route.snapshot.paramMap.get('orderId'));
    this.route.data.subscribe((data) => {
      this.isAuthenticated = data['isAuthenticated'];
      if(this.isAuthenticated){

        const user =  localStorage.getItem('user')
          ? JSON.parse(localStorage.getItem('user') as string) as Models.UserModel
          : null;
        this.primaryMobile = user?.primaryMobileNumber;
      }
    });
  }

  async ngOnInit () {
    // Check if user is loggedin - move to auth listener later

    this.contentLoader?.show();
    this.fetchPackages();
    this.fetchDeviceConfigs();
  }

  /**
   * Fetch order id API call
   * Pre-req: user is logged in
   */
  async getOrderById (orderId: number) {
    this.getOrderCallback?.(orderId).subscribe({
      next: (response) => {
        this.contentLoader?.hide();
        this.orderSvc.updateOrder(response);
      },
      error: (error) => {
        this.contentLoader?.hide();
        this.toastSvc.error('Error fetching order', JSON.stringify(error));
      },
    });
  }

  /**
   * To select rooms on the basis of smoke detectors count
   * @returns number
   */
  roomsCount () {
    return this.orderSvc.countTotalSmokeDetectors(this.plans);
  }

  fetchPackages () {
    this.getPackagesCallback?.().subscribe({
      next: (response) => {
        this.contentLoader?.hide();
        this.plans = response;
        this.orderSvc.setMonthlyPlans(this.plans);
        this.orderSvc.setOneTimePlan(this.plans);
        this.oneTimePlan = this.orderSvc.getOneTimePlan();
        this.cdr.markForCheck();
        if (this.orderId && this.isAuthenticated) {
          this.contentLoader?.show();
          this.getOrderById(this.orderId!);
        }
      },
      error: (error) => {
        this.contentLoader?.hide();
        this.plans = [];
        this.cdr.markForCheck();
        this.toastSvc.error('Error fetching packages', '');
        console.error(error);
      },
    });
  }

  fetchDeviceConfigs () {
    this.getDeviceConfigCallback?.().subscribe({
      next: (response) => {
        this.deviceDetails = response;
        this.orderSvc.setDeviceConfigs(this.deviceDetails);
      },
      error: (error) => {
        this.plans = [];
        this.toastSvc.error('Error fetching device configs', '');
        console.error('Error fetching device configs:', error);
      },
    });
  }

  /**
   * Temp method - Do not remove
   * Implmentation decision pending
   * @param room
   */
  onRoomSelection (room: string) {
    if (room === 'custom') {
      // popup already opens via data-bs-target
      console.info('Custom plan chosen → modal opens');
    } else {
      console.info('User selected room:', room);
    }
  }

  /**
   * Invoked when user selects payment plan
   * @param plan
   */
  onPlanSelect (plan: Product) {
    if (plan.defaultName) {
      // POST_PAID flow
      if (!this.isAuthenticated) {
        // set postpaid bundle in current order
        this.orderSvc.selectPostPaidBundle(plan.defaultName);
      } else {
        this.orderSvc.selectPostPaidBundle(plan.defaultName); // for testing added here only
        this.orderSvc.defaultPlanValue = plan.defaultName;
      }
    } else {
      // Prepaid flow - set one time bundle in current order
      this.orderSvc.setOneTimePaymentBundleInCurrentOrder();
    }
  }

  /**
   * Invoked when user clicks proceed to checkout button
   */
  onProceedToCheckout () {
    if (this.orderSvc.isCurrentOrderPostPaid()) {
      // POST_PAID flow - check eligibility
      if(!this.isAuthenticated){
        this.orderSvc.saveCurrentOrderInStorage();
        // this.router.navigate(['/login']);
        this.checkEligibility();
        // this.toastSvc.warning("Otp flow pending", "Order saved in session - Signup to continue");
      }
      else {
        // TODO: get current user and fetch his primary phone number
        this.checkEligibility();
      }
    } else {
      // if logged in - call update order api or else save in local
      if (!this.isAuthenticated) {
        this.orderSvc.saveCurrentOrderInStorage();
        this.router.navigate(['/signup']);
      } else {
        this.patchOrder();
      }
    }
  }
  @ViewChild(EligibilityModalComponent) eligibilityModal!: EligibilityModalComponent;

  /**
   * If user selects postpaid payment plan,show check postpaid eligibility modal
   */
  checkEligibility () {
    this.eligibilityModal.showModal();
    // this.showModal = true;
    // const modalEG = document.getElementById('loginModal');
    // if (modalEG) {
    //   this.modal = new bootstrap.Modal(modalEG);
    //   this.modal.show();
    // }
  }

  closeModal (){
    this.eligibilityModal.hideModal();
    // this.showModal = false;
    // const modalEG = document.getElementById('loginModal');
    // if (modalEG) {
    //   this.modal = new bootstrap.Modal(modalEG);
    //   this.modal.hide();
    // }
  }

  onEligibilityVerify (phone: string) {
    this.contentLoader?.show();
    this.postPaidEligibilityCheckCallback(phone).subscribe({
      next: (response) => {
        if (response?.status === 'SUCCESS') {
          this.contentLoader?.hide();
          if(this.isAuthenticated){
            this.closeModal();
            this.patchOrder();
          }
          else {
            this.closeModal();
            this.toastSvc.success("Postpaid Eligibility verified", "Signup to continue");
            this.router.navigate(['/signup']);

          }
        }
        else if (response?.status === 'INTERNAL_SERVER_ERROR'){
          this.contentLoader?.hide();
          this.closeModal();
          this.toastSvc.error('Unknown error occured', 'Try again later');
        }
        else {
          this.contentLoader?.hide();
          this.closeModal();
          this.toastSvc.error('Not eligible for Postpaid Plan', 'Select one time plan instead');
        }
      },
      error: (error) => {
        this.contentLoader?.hide();
        this.closeModal();
        this.toastSvc.error('Eligibility check failed', 'Please try again');
        console.error('Eligibility check failed:', error);
      },
    });
  }

  /**
   * Check postpaid eligibility against:
   * if loggedin - user primary phone number
   * if loggedout - provided phone number in eligibility modal
   */
  verifyPostPaidEligibility () {
    let phone = '';
    if (!this.isAuthenticated) {
      this.toastSvc.warning("OTP flow pending", "Login to continue");
      // TODO: show otp verification flow - load otp mfe from shell
    } else {
      phone = '0501000003';
      this.contentLoader?.show();
      this.postPaidEligibilityCheckCallback(phone).subscribe({
        next: (response) => {
          if (response && response.status === 'SUCCESS') {
            this.modal.hide();
            this.contentLoader?.hide();
            this.patchOrder(); // TODO: on success go to step 4 -> BOQ page
          } else {
            this.contentLoader?.hide();
            this.toastSvc.error("Not eligible for Postpaid Plan", "Select one time plan instead");
          }
        },
        error: (error) => {
          this.contentLoader?.hide();
          console.error('Eligibility check failed:', error);
          // TODO: Handle error
        },
      });
    }
  }

  /**
   * Once user selects plan and proceeds to checkout patch order is called
   * This goes to shell
   */
  patchOrder () {
    this.contentLoader?.show();
    const currentOrder = this.orderSvc.currentOrder;
    this.patchOrderCallback(currentOrder).subscribe((res) => {
      if (res) {
        this.contentLoader?.hide();
        this.orderSvc.updateOrder(res);
        this.toastSvc.success("Success", "Order details updated");
        this.router.navigate([`home/${res.id}/configuration/review-order`]);

      }
      else {
        this.contentLoader?.hide();
        this.toastSvc.error("Error", "Order details not updated");
      }
    });
  }
}
