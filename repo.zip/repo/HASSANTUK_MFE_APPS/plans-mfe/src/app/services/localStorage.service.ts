
import {Injectable} from '@angular/core';
import { Models } from 'shared-state';

@Injectable({
  providedIn: 'root',
})
export class LocalstorageService {

  getEligibleAccountNumber () {
    if(localStorage.getItem('eligibleAccountNumber') != "") {
      const config = localStorage.getItem('eligibleAccountNumber');
      return config ? JSON.parse(config) : null;
    }
  }

  setEligibleAccountNumber (accountNumber: string) {
    localStorage.setItem('eligibleAccountNumber', accountNumber);
  }

}


@Injectable({
  providedIn: 'root',
})
export class SessionStorageService {

  getDevicesOrder () {
    const config = sessionStorage.getItem('devicesOrder');
    return config ? JSON.parse(config) : null;
  }

  setDevicesOrder (order: Models.OrderModel) {
    sessionStorage.setItem('devicesOrder', JSON.stringify(order));
  }

  setPreLoginOrder (order: Models.OrderModel){
    sessionStorage.setItem('preLoginOrder', JSON.stringify(order));
  }

  getPreLoginOrder (){
    const preLoginOrder = sessionStorage.getItem("preLoginOrder");
    return preLoginOrder === null ? null : JSON.parse(preLoginOrder);
  }

  removePreLoginOrder (){
    sessionStorage.removeItem('preLoginOrder');
  }
}
