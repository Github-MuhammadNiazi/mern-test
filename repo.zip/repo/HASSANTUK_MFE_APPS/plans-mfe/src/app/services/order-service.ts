/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  ChargeDetail,
  ChargeDetailType,
  DeviceSpec,
  DevicesConfig,
  Product,
  ServiceSpec,
  SubProduct,
} from '../interfaces/interfaces';
import { Enums, Models } from 'shared-state';
import { Injectable, inject } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { PlanDuration } from '../configs/order-rate-plan.config';
import { SessionStorageService } from './localStorage.service';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private sessionStorage = inject(SessionStorageService);
  private twelveMonthPSMBundle?: Product = {};
  private twentyFourMonthPSMBundle?: Product = {};
  private oneTimePlan: Product = {};
  currentOrderSubject = new BehaviorSubject<Models.OrderModel>({} as Models.OrderModel);
  currentOrderObv$ = this.currentOrderSubject.asObservable();

  get currentOrder (): Models.OrderModel {
    return this.currentOrderSubject.getValue();
  }

  updateOrder (patch: Partial<Models.OrderModel>) {
    this.currentOrderSubject.next({
      ...this.currentOrder,
      ...patch,
    });
  }
  optionalSmokeDetector24 = 'RPMOISMOKEDVCOPT24';
  optionalSmokeDetector12 = 'RPMOISMOKEDVCOPT12';
  defaultSmokeDetector = ['RPMOISMOKEDVCJCI', 'RP_RESIDEO_SMOKE_DETECTOR'];
  optionalHeatDetector24 = 'RPMOIHEATDVCOPT24';
  optionalHeatDetector12 = 'RPMOIHEATDVCOPT12';
  optionalWirelessRepeater24 = 'RPMOIREPDVC24';
  optionalWirelessRepeater12 = 'RPMOIREPDVC12';
  defaultHeatDetector = ['RPMOIHEATDVCJCI', 'RP_RESIDEO_HEAT_DETECTOR'];
  defaultWirelessRepeater24 = 'RPMOIREPDVCBASIC24';
  defaultWirelessRepeater12 = 'RPMOIREPDVCBASIC12';
  defaultWirelessRepeater = ['RPMOIREPDVCJCI', 'RP_RESIDEO_REPEATER'];
  defaultATEPaymentCharges = ['RPMOIATEPAYJCI', 'RP_RESIDEO_ATE'];
  smokeDetectorRoomTags = [
    'Default_Bathroom',
    'Default_Bedroom',
    'Default_Majlis',
    'Default_Dinning',
    'Default_Living',
    'Default_Closed_Parking',
    'Default_Gym',
    'Default_Hall',
    'Default_Laundry',
    'Default_Maid_Room',
    'Default_Store',
    'Default_Other_Room',
  ];
  wirelessSmokeDetector: string[] = [];
  wirelessHeatDetector: string[] = [];
  wirelessRepeater: string[] = [];
  ATEPaymentCharges: string[] = [];
  sirenDevice: string[] = [];
  quotation: any;
  defaultPlanValue: any;

  private maxFloors = 10;
  private maxRooms = 29;
  private maxKitchens = 29;
  private isAddMoreDevicesEnabled = false;

  getIsAddMoreDevicesEnabled (){
    return this.isAddMoreDevicesEnabled;
  }
  getMaxFloors (){
    return this.maxFloors;
  }

  getmaxRooms (){
    return this.maxRooms;
  }

  getMaxKitchens (){
    return this.maxKitchens;
  }
  getOneTimePlan () {
    return this.oneTimePlan;
  }

  getTwelveMonthPlan () {
    return this.twelveMonthPSMBundle;
  }

  getTwentyFourMonthPlan () {
    return this.twentyFourMonthPSMBundle;
  }

  setDeviceConfigs (deviceDetails: DevicesConfig) {
    this.wirelessHeatDetector = deviceDetails.heatdetector || [];
    this.wirelessSmokeDetector = deviceDetails.smokedetector || [];
    this.wirelessRepeater = deviceDetails.wirelessrepeater || [];
    this.ATEPaymentCharges = deviceDetails.atepay || [];
    this.sirenDevice = deviceDetails.siren || [];
  }

  setMonthlyPlans (plans: Product[]) {
    this.twelveMonthPSMBundle = plans.find(
      (x) => x.defaultName == PlanDuration.CPS_MOI12M_NEW
    );
    this.twentyFourMonthPSMBundle = plans.find(
      (x) => x.defaultName == PlanDuration.CPS_MOI24M_NEW
    );
  }

  saveCurrentOrderInStorage () {
    this.sessionStorage.setPreLoginOrder(this.currentOrderSubject.getValue());
  }

  // Helper Methods
  selectPostPaidBundle (cpsCode: string) {
    // clone current order - avoid mutating original order
    const currentOrder = { ...this.currentOrderSubject.getValue() };

    // set order type
    currentOrder.type = { id: Models.OrderType.POSTPAID.ID };

    // ensure orderConfiguration exists
    if (!currentOrder.orderConfiguration) {
      currentOrder.orderConfiguration = new Models.OrderConfigurationModel();
    }

    // update configuration
    currentOrder.orderConfiguration.selectedPostPaidBundle = cpsCode;
    currentOrder.orderConfiguration.postPaidOrderAdditionalDevices = {};
    currentOrder.planType = Enums.PlanType.MONTHLY;

    // handle device spec mapping
    if (cpsCode === PlanDuration.CPS_MOI12M_NEW) {
      currentOrder.orderConfiguration.deviceSpecificationsImportIdentifer =
      this.twelveMonthPSMBundle?.deviceSpecificationsImportIdentifer || '';
    } else if (cpsCode === PlanDuration.CPS_MOI24M_NEW) {
      currentOrder.orderConfiguration.deviceSpecificationsImportIdentifer =
      this.twentyFourMonthPSMBundle?.deviceSpecificationsImportIdentifer || '';
    }

    // push updated order
    this.currentOrderSubject.next(currentOrder);
  }

  setOneTimePaymentBundleInCurrentOrder () {
    if (!this.currentOrderSubject)
      this.currentOrderSubject = new BehaviorSubject<Models.OrderModel>(
        JSON.parse(JSON.stringify(this.oneTimePlan.againstOrder))
      );
    else
      this.currentOrderSubject.getValue().orderConfiguration = JSON.parse(
        JSON.stringify(this.oneTimePlan.againstOrder?.orderConfiguration)
      );

    this.currentOrderSubject.getValue().planType = Enums.PlanType.CUSTOM;
    this.currentOrderSubject.getValue().type = {
      id: Models.OrderType.DEFAULT.ID,
    };
    this.updateOrder(this.currentOrderSubject.getValue());
  }

  setOneTimePlan (plans: Product[]) {
    this.oneTimePlan = JSON.parse(
      JSON.stringify(plans.find((x) => x.defaultName === undefined))
    );
    if (this.oneTimePlan) {
      this.oneTimePlan.totalCalculatedPrice =
        this.extractOneTimeCharges(this.oneTimePlan);
    }
  }

  extractOneTimeCharges (product: any): number {
    const charge = product?.deviceSpecifications?.[0]?.chargeDetails?.find(
      (c: any) => c.type === "ONETIME"
    );

    if (!charge?.amount) return 0;

    const discountUnknown: unknown = this.currentOrder.orderDiscount;
    const discountValue =
      discountUnknown && typeof discountUnknown === "object" && "discountValue" in discountUnknown
        ? (discountUnknown as { discountValue: number }).discountValue
        : 0;

    return charge.amount - discountValue;
  }

  /**
   * Calculates the aggregated monthly charges for a given bundle and set of plans.
   * The calculation includes charges for the monthly plan, monitoring and maintenance,
   * additional devices (such as smoke detectors, heat detectors, and wireless repeaters),
   * ATE payment charges, and total service prices. It also applies a 5% surcharge to the total.
   *
   * The method distinguishes between postpaid and prepaid orders, applying different
   * pricing logic accordingly.
   *
   * @param bundle - The bundle object containing device and service specifications.
   * @param plans - An array of Product objects representing the selected plans.
   * @returns The total aggregated monthly charges as a number.
   */
  calculateAggregatedMonthlyCharges (bundle: any, plans: Product[]) { // Monthly Plan + Monitoring and Maintenance + additional devices
    if (!plans || plans.length == 0 || !this.currentOrder || !this.currentOrder.orderConfiguration)
      return 0;
    let monthlyCharges = this.isCurrentOrderPostPaid() ? this.extractMonthlyRecurringCharges(this.extractMonthlyRecurringChargesRatePlan(bundle)) : 0.0;
    monthlyCharges = this.extractMonthlyRecurringCharges(this.extractMonthlyRecurringChargesRatePlan(bundle));
    if (this.extractAdditionalWirelessSmokeDetectorRatePlan(bundle)) // additional smoke detector price
      monthlyCharges += this.isCurrentOrderPostPaid() ?
        (this.countAdditionalDevices(this.extractAdditionalWirelessSmokeDetectorRatePlan(bundle))) * (this.extractAdditionalRecurringCharges(this.extractAdditionalWirelessSmokeDetectorRatePlan(bundle)))
        : (parseFloat(this.countTotalSmokeDetectors(plans)) * (parseFloat(this.extractAdditionalWirelessSmokeDetectorRatePlan(bundle).unitPrice)));
    if (this.extractAdditionalHeatDetectorRatePlan(bundle)) // additional Heat detector price
      monthlyCharges += this.isCurrentOrderPostPaid() ?
        (this.countAdditionalDevices(this.extractAdditionalHeatDetectorRatePlan(bundle))) * (this.extractAdditionalRecurringCharges(this.extractAdditionalHeatDetectorRatePlan(bundle)))
        : (parseFloat(this.countTotalHeatDetectors(plans)) * (parseFloat(this.extractAdditionalHeatDetectorRatePlan(bundle).unitPrice)));
    if (this.extractAdditionalWirelessRepeaterRatePlan(bundle))
      monthlyCharges += this.isCurrentOrderPostPaid() ?
        (this.countAdditionalDevices(this.extractAdditionalWirelessRepeaterRatePlan(bundle))) * (this.extractAdditionalRecurringCharges(this.extractAdditionalWirelessRepeaterRatePlan(bundle)))
        : (parseFloat(this.countTotalWirelessRepeater(plans)) * (parseFloat(this.extractAdditionalWirelessRepeaterRatePlan(bundle).unitPrice)));

    // DEFAULT "ATE Payment charges" + "totalServicesPrice"
    monthlyCharges += this.isCurrentOrderPostPaid() ? 0.0 : parseFloat(bundle.deviceSpecs.find( (x:DeviceSpec) => this.defaultATEPaymentCharges.includes(x.deviceCode!)).unitPrice);

    monthlyCharges += this.isCurrentOrderPostPaid() ? 0.0 : parseFloat(bundle.serviceSpecs.map( (x: ServiceSpec) => x.unitPrice).reduce((i:string, x:string) => parseFloat(i) + parseFloat(x)));

    monthlyCharges += monthlyCharges * 0.05;

    return monthlyCharges;
  }


  isCurrentOrderPostPaid () {
    const order = this.currentOrderSubject.getValue() as Models.OrderModel;
    return order.type != null &&
      typeof order.type === 'object' &&
      'id' in order.type
      ? (order.type as { id?: number }).id == Models.OrderType.POSTPAID.ID
      : order.planType != null
        ? order.planType == Enums.PlanType.MONTHLY
        : order.orderConfiguration
          ? order.orderConfiguration.selectedPostPaidBundle ==
          PlanDuration.CPS_MOI12M_NEW ||
        order.orderConfiguration.selectedPostPaidBundle ==
          PlanDuration.CPS_MOI24M_NEW
          : false;
  }

  extractMonthlyRecurringCharges (product: SubProduct | undefined): number {
    const chargeDetails = product?.deviceSpecifications?.[0]?.chargeDetails;
    if (chargeDetails && chargeDetails.length > 0) {
      const charge = product?.deviceSpecifications?.[0]?.chargeDetails?.find(
        (charge: ChargeDetail) => charge.type === ChargeDetailType.Recurring
      ) as ChargeDetail | undefined;
      return charge?.amount ?? 0.0;
    }
    return 0.0;
  }

  extractMonthlyRecurringChargesRatePlan (bundle: Product) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return bundle.subProducts.find((x) => x.defaultName == 'RPMOIPOST12');
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return bundle.subProducts.find((x) => x.defaultName == 'RPMOIPOST24');
    }
    return undefined;
  }

  extractAdditionalWirelessRepeaterRatePlan (
    bundle: Product,
    fromQuote = false
  ) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == this.optionalWirelessRepeater12
          )
          : bundle.subProducts.find(
            (x) => x.defaultName == this.optionalWirelessRepeater12
          );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == this.optionalWirelessRepeater24
          )
          : bundle.subProducts.find(
            (x) => x.defaultName == this.optionalWirelessRepeater24
          );
    } else if (bundle.deviceSpecs && bundle.deviceSpecs.length > 0) {
      return bundle.deviceSpecs.find((x: DeviceSpec) =>
        this.defaultWirelessRepeater.includes(x.deviceCode!)
      );
    }
  }

  countAdditionalDevices (product: Product) {
    const orderConfig = this.currentOrderSubject.getValue()?.orderConfiguration;
    const additionalDevices = orderConfig?.postPaidOrderAdditionalDevices as
      | Record<string, number>
      | undefined;
    if (product && product.defaultName && orderConfig && additionalDevices) {
      return product.defaultName in additionalDevices
        ? additionalDevices[product.defaultName]
        : 0;
    } else {
      return 0;
    }
  }

  extractAdditionalWirelessSmokeDetectorRatePlan (
    bundle: Product,
    fromQuote = false
  ) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == this.optionalSmokeDetector12
          )
          : bundle.subProducts.find(
            (x) => x.defaultName == 'RPMOISMOKEDVCOPT12'
          );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == this.optionalSmokeDetector24
          )
          : bundle.subProducts.find(
            (x) => x.defaultName == 'RPMOISMOKEDVCOPT24'
          );
    } else if (bundle.deviceSpecs && bundle.deviceSpecs.length > 0) {
      return bundle.deviceSpecs.find((x: DeviceSpec) =>
        this.defaultSmokeDetector.includes(x.deviceCode!)
      );
    }
  }

  extractAdditionalRecurringCharges (product: Product): number {
    if (
      product &&
      product.deviceSpecifications &&
      product.deviceSpecifications.length > 0 &&
      product.deviceSpecifications[0].chargeDetails &&
      product.deviceSpecifications[0].chargeDetails.length > 0
    ) {
      const charge = product.deviceSpecifications[0].chargeDetails.find(
        (charge: ChargeDetail) => charge.type == ChargeDetailType.Recurring
      );
      return charge && charge.amount ? charge.amount : 0;
    }
    return 0.0;
  }

  countTotalSmokeDetectors (plans : Product[]) {
    if (!plans || plans.length == 0 || !this.currentOrder  || !this.currentOrder.orderConfiguration)
      return 0;
    if (this.isCurrentOrderPostPaid()) {
      const productName =
        this.preSelectedBundle()?.defaultName == PlanDuration.CPS_MOI12M_NEW
          ? this.optionalSmokeDetector12
          : this.optionalSmokeDetector24;
      const additionalDevices = this.currentOrder.orderConfiguration?.postPaidOrderAdditionalDevices as
        | Record<string, number>
        | undefined;
      return (
        this.extractBasicWirelessSmokeDetectorRatePlan(this.preSelectedBundle())
          .max +
        (additionalDevices
          ? productName in additionalDevices
            ? additionalDevices[productName]
            : 0
          : 0)
      );
    } else if (!this.isCurrentOrderPostPaid() && this.currentOrder.orderConfiguration.buildingConfiguration
      && this.currentOrder.orderConfiguration.buildingConfiguration.length > 0 && this.currentOrder.orderConfiguration.buildingConfiguration[0].floors && this.currentOrder.orderConfiguration.buildingConfiguration[0].floors.length > 0) {
      return this.currentOrder.orderConfiguration.buildingConfiguration.map(x => x.floors).reduce((i, x) => i.concat(x)).map(x => x.tags).reduce((i, x) => i.concat(x)).filter(x => this.smokeDetectorRoomTags.includes(x) || x == this.extractAdditionalWirelessSmokeDetectorRatePlan(this.preSelectedBundle()).roomType).length;
    }

  }

  disableSmokeDetectors (plans : Product[]) {
    if (!plans || plans.length == 0 || !this.currentOrder  || !this.currentOrder.orderConfiguration)
      return true;
    if (this.isCurrentOrderPostPaid()) {
      return this.countTotalSmokeDetectors(plans) == this.extractBasicWirelessSmokeDetectorRatePlan(this.preSelectedBundle()).max ? true : false;
    }
    return this.countTotalSmokeDetectors(plans) == 0 ? true : false;
  }

  preSelectedBundle (): Product {
    if (
      this.currentOrderSubject &&
      this.currentOrder &&
      this.currentOrder.orderConfiguration &&
      this.currentOrder.orderConfiguration
        .selectedPostPaidBundle
    )
      return this.currentOrder.orderConfiguration
        .selectedPostPaidBundle == PlanDuration.CPS_MOI12M_NEW
        ? this.twelveMonthPSMBundle!
        : this.twentyFourMonthPSMBundle!;
    else return this.oneTimePlan!;
  }

  extractBasicWirelessSmokeDetectorRatePlan (
    bundle: Product,
    fromQuote = false
  ) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == 'RPMOISMOKEDVCBASC12'
          )
          : bundle.subProducts.find(
            (x) => x.defaultName == 'RPMOISMOKEDVCBASC12'
          );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == 'RPMOISMOKEDVCBASC24'
          )
          : bundle.subProducts.find(
            (x) => x.defaultName == 'RPMOISMOKEDVCBASC24'
          );
    }
  }

  countTotalWirelessRepeater (plans: Product[]) {
    if (
      !plans ||
      plans.length == 0 ||
      !this.currentOrderSubject ||
      !this.currentOrderSubject.getValue() ||
      !this.currentOrderSubject.getValue().orderConfiguration
    )
      return 0;
    if (this.isCurrentOrderPostPaid()) {
      const optionalProductName =
        this.preSelectedBundle()?.defaultName == PlanDuration.CPS_MOI12M_NEW
          ? this.optionalWirelessRepeater12
          : this.optionalWirelessRepeater24;
      const additionalDevices = this.currentOrder
        .orderConfiguration?.postPaidOrderAdditionalDevices as
        | Record<string, number>
        | undefined;
      return (
        this.extractBasicWirelessRepeaterRatePlan(this.preSelectedBundle())
          .max +
        (additionalDevices
          ? optionalProductName in additionalDevices
            ? additionalDevices[optionalProductName]
            : 0
          : 0)
      );
    } else if (
      this.currentOrder.orderConfiguration &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration.length > 0
    ) {
      return this.currentOrderSubject.getValue().planType ==
        Enums.PlanType.CUSTOM
        ? this.currentOrder
          .orderConfiguration.buildingConfiguration.reduce(
            (count, x) => count + x.floors.length,
            -1
          )
        : this.currentOrder
          .orderConfiguration.buildingConfiguration.reduce(
            (count, x) => count + x.floors.length,
            0
          );
    }
    return 0;
  }

  extractBasicWirelessRepeaterRatePlan (bundle: Product, fromQuote = false) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: DeviceSpec) => x.deviceCode == this.defaultWirelessRepeater12
          )
          : bundle.subProducts.find(
            (x) => x.defaultName == this.defaultWirelessRepeater12
          );
      // TODO this.globals.optionalWirelessDetector12
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: DeviceSpec) => x.deviceCode == this.defaultWirelessRepeater24
          )
          : bundle.subProducts.find(
            (x: SubProduct) => x.defaultName == this.defaultWirelessRepeater24
          ); //// TODO this.globals.optionalWirelessDetector24
    }
  }

  disableWirelessRepeator (plans : Product[]) {
    if (!plans || plans.length == 0 || !this.currentOrder || !this.currentOrder.orderConfiguration)
      return true;
    if (this.isCurrentOrderPostPaid()) {
      return this.countTotalWirelessRepeater(plans) == this.extractBasicWirelessRepeaterRatePlan(this.preSelectedBundle()).max ? true : false;
    }
    return this.countTotalWirelessRepeater(plans) == 0 ? true : false;
  }

  countTotalHeatDetectors (plans: Product[]) {
    if (
      !plans ||
      plans.length == 0 ||
      !this.currentOrderSubject ||
      !this.currentOrderSubject.getValue() ||
      !this.currentOrderSubject.getValue().orderConfiguration
    )
      return 0;
    if (this.isCurrentOrderPostPaid()) {
      const productName =
        this.preSelectedBundle()?.defaultName == PlanDuration.CPS_MOI12M_NEW
          ? this.optionalHeatDetector12
          : this.optionalHeatDetector24;
      const additionalDevices = this.currentOrder
        .orderConfiguration?.postPaidOrderAdditionalDevices as
        | Record<string, number>
        | undefined;
      return (
        this.extractBasicWirelessHeatDetectorRatePlan(this.preSelectedBundle())
          .max +
        (additionalDevices
          ? productName in additionalDevices
            ? additionalDevices[productName]
            : 0
          : 0)
      );
    } else if (
      !this.isCurrentOrderPostPaid() &&
      this.currentOrder.orderConfiguration?.buildingConfiguration &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration.length > 0 &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration[0].floors &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration[0].floors.length > 0
    ) {
      return this.currentOrder
        .orderConfiguration.buildingConfiguration.map((x) => x.floors)
        .reduce((i, x) => i.concat(x))
        .map((x) => x.tags)
        .reduce((i, x) => i.concat(x))
        .filter(
          (x) =>
            x ==
            this.extractAdditionalHeatDetectorRatePlan(this.preSelectedBundle())
              .roomType
        ).length;
    }
  }

  extractBasicWirelessHeatDetectorRatePlan (bundle: Product, fromQuote = false) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == 'RPMOIHEATDVCBASIC12'
          )
          : bundle.subProducts.find(
            (x: SubProduct) => x.defaultName == 'RPMOIHEATDVCBASIC12'
          );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) =>
              x.deviceCode == 'RPMOIHEATDVCBASIC24'
          )
          : bundle.subProducts.find(
            (x: SubProduct) => x.defaultName == 'RPMOIHEATDVCBASIC24'
          );
    }
  }

  extractAdditionalHeatDetectorRatePlan (bundle: Product, fromQuote = false) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) => x.deviceCode == 'RPMOIHEATDVCOPT12'
          )
          : bundle.subProducts.find(
            (x: SubProduct) => x.defaultName == 'RPMOIHEATDVCOPT12'
          );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return fromQuote && this.quotation && this.quotation.deviceSpecs
          ? this.quotation.deviceSpecs.find(
            (x: { deviceCode: string }) => x.deviceCode == 'RPMOIHEATDVCOPT24'
          )
          : bundle.subProducts.find(
            (x: SubProduct) => x.defaultName == 'RPMOIHEATDVCOPT24'
          );
    } else if (bundle.deviceSpecs && bundle.deviceSpecs.length > 0) {
      return bundle.deviceSpecs.find((x: DeviceSpec) =>
        this.defaultHeatDetector.includes(x.deviceCode!)
      );
    }
  }

  disableHeatDetectors (plans: Product[]) {
    if (!plans || plans.length == 0 || !this.currentOrder  || !this.currentOrder.orderConfiguration)
      return true;
    if (this.isCurrentOrderPostPaid()) {
      return this.countTotalHeatDetectors(plans) == this.extractBasicWirelessHeatDetectorRatePlan(this.preSelectedBundle()).max ? true : false;
    }
    return this.countTotalHeatDetectors(plans) == 0 ? true : false;
  }

  calculateAggregatedMonthlyChargesForOneTimePayment (plans: Product[]) {
    // Monthly Plan + Monitoring and Maintenance + additional devices
    if (!plans || plans.length == 0) return 0;
    let monthlyCharges = 0.0;
    if (this.extractAdditionalWirelessSmokeDetectorRatePlan(this.oneTimePlan))
      // additional smoke detector price
      monthlyCharges +=
        this.oneTimePlan?.againstOrder?.orderConfiguration?.buildingConfiguration
          .map((x) => x.floors)
          .reduce((i, x) => i.concat(x))
          .map((x) => x.tags)
          .reduce((i, x) => i.concat(x))
          .filter(
            (x) =>
              x ==
              this.extractAdditionalWirelessSmokeDetectorRatePlan(
                this.oneTimePlan
              ).roomType
          ).length ??
        0.0 *
          parseFloat(
            this.extractAdditionalWirelessSmokeDetectorRatePlan(
              this.oneTimePlan
            ).unitPrice
          );
    if (this.extractAdditionalHeatDetectorRatePlan(this.oneTimePlan))
      // additional Heat detector price
      monthlyCharges +=
        this.oneTimePlan?.againstOrder?.orderConfiguration?.buildingConfiguration
          .map((x) => x.floors)
          .reduce((i, x) => i.concat(x))
          .map((x) => x.tags)
          .reduce((i, x) => i.concat(x))
          .filter(
            (x) =>
              x ==
              this.extractAdditionalHeatDetectorRatePlan(this.oneTimePlan)
                .roomType
          ).length ??
        0.0 *
          parseFloat(
            this.extractAdditionalHeatDetectorRatePlan(this.oneTimePlan)
              .unitPrice
          );
    if (this.extractAdditionalWirelessRepeaterRatePlan(this.oneTimePlan))
      monthlyCharges +=
        (this.oneTimePlan?.againstOrder?.orderConfiguration?.buildingConfiguration[0].floors
          ? this.oneTimePlan?.againstOrder.orderConfiguration
            .buildingConfiguration[0].floors.length - 1
          : 0) *
        parseFloat(
          this.extractAdditionalWirelessRepeaterRatePlan(this.oneTimePlan)
            .unitPrice
        );

    // DEFAULT "ATE Payment charges" + "totalServicesPrice"
    monthlyCharges += parseFloat(
      this.oneTimePlan?.deviceSpecs?.find((x) =>
        this.defaultATEPaymentCharges.includes(x.deviceCode!)
      )?.unitPrice ?? '0'
    );

    monthlyCharges += parseFloat(
      this.oneTimePlan?.serviceSpecs
        ?.map((x) => x.unitPrice)
        .reduce((i, x) => i + x) ?? '0.0'
    );

    monthlyCharges += monthlyCharges * 0.05;

    return monthlyCharges;
  }

  removeAdditionalDevices (product: any) {
    if (!this.currentOrderSubject.getValue()) return;
    if (
      this.isCurrentOrderPostPaid() &&
      this.currentOrder.orderConfiguration &&
      this.currentOrder.orderConfiguration?.postPaidOrderAdditionalDevices &&
      this.currentOrder.orderConfiguration
        .postPaidOrderAdditionalDevices
    ) {
      const additionalDevices = this.currentOrder
        .orderConfiguration.postPaidOrderAdditionalDevices as Record<
        string,
        number
      >;
      if (
        product.defaultName in additionalDevices &&
        additionalDevices[product.defaultName] > 0
      )
        --additionalDevices[product.defaultName];
    } else if (
      !this.isCurrentOrderPostPaid() &&
      this.currentOrder.orderConfiguration &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration.length > 0 &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration[0].floors &&
      this.currentOrder.orderConfiguration
        .buildingConfiguration[0].floors.length > 0
    ) {
      if (
        this.defaultWirelessRepeater.includes(product.deviceCode) &&
        this.currentOrder.orderConfiguration
          .buildingConfiguration[0].floors.length > 1
      )
        this.currentOrder
          .orderConfiguration.buildingConfiguration[0].floors.pop();
      else if (
        this.currentOrder.orderConfiguration
          .buildingConfiguration[0].floors[0].tags &&
        this.currentOrder.orderConfiguration
          .buildingConfiguration[0].floors[0].tags.length > 0 &&
        this.currentOrder
          .orderConfiguration.buildingConfiguration[0].floors[0].tags.filter(
            (x) => x == product.roomType
          ).length > 0
      )
        this.currentOrder
          .orderConfiguration.buildingConfiguration[0].floors[0].tags.splice(
            this.currentOrder
              .orderConfiguration.buildingConfiguration[0].floors[0].tags.findIndex(
                (x) => x == product.roomType
              ),
            1
          );
    }
  }

  addAdditionalDevices (product: any) {
    if (!this.currentOrderSubject.getValue()) return;
    if (!this.currentOrderSubject.getValue().orderConfiguration)
      this.currentOrderSubject.getValue().orderConfiguration =
        new Models.OrderConfigurationModel();
    if (this.isCurrentOrderPostPaid()) {
      const additionalDevices = this.currentOrder.orderConfiguration?.postPaidOrderAdditionalDevices as Record<
        string,
        number
      >;
      if (product.defaultName in additionalDevices)
        ++additionalDevices[product.defaultName];
      else additionalDevices[product.defaultName] = 1;
    } else if (!this.isCurrentOrderPostPaid()) {
      if (
        this.currentOrder.orderConfiguration?.buildingConfiguration &&
        this.currentOrder.orderConfiguration
          .buildingConfiguration.length > 0 &&
        this.currentOrder.orderConfiguration
          .buildingConfiguration[0].floors &&
        this.currentOrder.orderConfiguration
          .buildingConfiguration[0].floors.length > 0
      ) {
        if (this.defaultWirelessRepeater.includes(product.deviceCode)) {
          const floorModel = new Models.FloorModel();
          const currentFloorsNumberInThisBuilding =
            this.currentOrder.orderConfiguration
              .buildingConfiguration[0].floors.length;
          floorModel.type = 'FL' + currentFloorsNumberInThisBuilding;
          floorModel.floorName = currentFloorsNumberInThisBuilding.toString();
          this.currentOrder
            .orderConfiguration.buildingConfiguration[0].floors.push(
              floorModel
            );
        } else if (
          this.currentOrder.orderConfiguration
            .buildingConfiguration[0].floors[0].tags
        )
          this.currentOrder
            .orderConfiguration.buildingConfiguration[0].floors.find(
              (x) => x.type == Enums.FloorType.GroundFloor
            )
            ?.tags.push(product.roomType);
      }
    }
  }
}
