import { Enums, Models } from 'shared-state';
export class OrderMergeService {
/**
 * Merges the building and floor configurations from closed child orders into the parent order's configuration.
 *
 * For each closed child order, the method:
 * - Finds buildings in the child order that match buildings in the parent order by type and name.
 * - For matching buildings, merges floors by matching floor name and type, appending tags from child floors to parent floors.
 * - If a child building has floors not present in the parent, those floors are added to the parent building.
 * - If a child building does not exist in the parent, the entire building is added to the parent's configuration.
 *
 * The method marks the parent order as merged to prevent repeated merging.
 *
 * @param order The parent order model containing configuration and sub-orders.
 * @returns The updated parent order model with merged configurations.
 */
  mergeParentChildConfigurations (order: Models.OrderModel) {
    if (
      order.orderConfiguration &&
      order.orderConfiguration.buildingConfiguration.length > 0 &&
      order.subOrders &&
      order.subOrders.length > 0 &&
      !order.isMerged
    ) {
      const childCandidateOrders = order.subOrders.filter(
        (subOrder) => subOrder.status === Enums.OrderStatus.Closed
      );
      if (childCandidateOrders && childCandidateOrders.length > 0) {
        childCandidateOrders.forEach((childCandidateOrder) => {
          childCandidateOrder.orderConfiguration.buildingConfiguration.forEach(
            (childBuilding) => {
              const parentIdenticalBuilding =
                order.orderConfiguration.buildingConfiguration.find(
                  (parentBuilding) =>
                    parentBuilding.type === childBuilding.type &&
                    parentBuilding.buildingName === childBuilding.buildingName
                );
              if (parentIdenticalBuilding) {
                if (childBuilding.floors && childBuilding.floors.length > 0) {
                  if (
                    parentIdenticalBuilding &&
                    parentIdenticalBuilding.floors.length > 0
                  ) {
                    childBuilding.floors.forEach((childBuildingFloor) => {
                      const filteredParentBuildingIdenticalFloor =
                        parentIdenticalBuilding.floors.find(
                          (parentBuildingIdenticalFloor) =>
                            parentBuildingIdenticalFloor.floorName ===
                              childBuildingFloor.floorName &&
                            parentBuildingIdenticalFloor.type ===
                              childBuildingFloor.type
                        );
                      if (filteredParentBuildingIdenticalFloor) {
                        filteredParentBuildingIdenticalFloor.tags.push(
                          ...childBuildingFloor.tags
                        );
                      } else {
                        parentIdenticalBuilding.floors.push(childBuildingFloor);
                      }
                    });
                  } else {
                    /**
                     * TODO: what if parent building doesn't contains a floor but in the child order that building has been amended with a floor.
                     * As per logic the floors of the child building should be added as it is to the parent identical building.
                     */
                  }
                } else {
                  /**
                   * TODO: what if child building doesn't contains any floor.
                   * As per logic the building needs to skiped as it's existence had beend ensured by parent identical building.
                   */
                }
              } else {
                order.orderConfiguration.buildingConfiguration.push(
                  childBuilding
                );
              }
            }
          );
        });
      }
      //TODO: marking the order as merged, as it shouldn't be merged again.
      order.isMerged = true;
    }
    return order;
  }

  /**
 * Merges the sub-order configurations into the parent order configuration.
 *
 * This method traverses the building and floor structures of the parent order and its sub-orders,
 * merging tags and adding new floors/buildings from sub-orders where appropriate. It prevents
 * multiple traversals using a `traversed` marker on buildings and floors. Only sub-orders that
 * do not have the status `PaymentReversel` are considered for merging.
 *
 * After merging, the parent order's `isMerged` flag is set to `true` to prevent repeated merges.
 *
 * @param order The parent order model containing building and sub-order configurations.
 * @returns The merged order model.
 */
  mergeSubOrderConfigurationWithParent (order: Models.OrderModel) {
    if (
      order.orderConfiguration &&
      order.orderConfiguration.buildingConfiguration.length > 0 &&
      order.subOrders &&
      order.subOrders.length > 0 &&
      !order.isMerged
    ) {
      order.orderConfiguration.buildingConfiguration.forEach((building) => {
        if (
          building.floors &&
          building.floors.length > 0 &&
          !building.traversed // preventing multitraversel
        ) {
          building.floors.forEach((floor) => {
            // preventing multitraversel
            if (!floor.traversed) {
              order.subOrders
                .filter(
                  (sub) => sub.status !== Enums.OrderStatus.PaymentReversel
                )
                .find((sub) => {
                  sub.orderConfiguration.buildingConfiguration.forEach(
                    (subbuilding) => {
                      if (
                        subbuilding.type.toLowerCase() ==
                          building.type.toLowerCase() &&
                        subbuilding.buildingName.toLowerCase() ==
                          building.buildingName.toLowerCase()
                      ) {
                        if (
                          subbuilding.floors &&
                          subbuilding.floors.length > 0
                        ) {
                          // Adding all rooms with common building and floor
                          subbuilding.floors.forEach((SubFloor) => {
                            if (
                              SubFloor.floorName.toLowerCase() ==
                                floor.floorName.toLowerCase() &&
                              SubFloor.type.toLowerCase() ==
                                floor.type.toLowerCase()
                            ) {
                              floor.tags.push(...SubFloor.tags);
                            } else {
                              SubFloor.traversed = true; //marker to prevent multitraversel
                              building.floors.push(SubFloor);
                            }
                          });
                        }
                      } else {
                        subbuilding.traversed = true; //marker to prevent multitraversel
                        order.orderConfiguration.buildingConfiguration.push(
                          subbuilding
                        );
                      }
                    }
                  );
                });
            }
          });
        }
      });

      order.isMerged = true;
    }
    return order;
  }
}
