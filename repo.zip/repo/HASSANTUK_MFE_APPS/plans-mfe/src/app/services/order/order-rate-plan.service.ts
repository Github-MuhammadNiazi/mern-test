/* eslint-disable @typescript-eslint/no-explicit-any */
import { Enums, Models } from 'shared-state';
import {
  ORDER_PLAN_SKUS,
  PlanDuration,
} from '../../configs/order-rate-plan.config';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class OrderRatePlanService {
  extractBasicWirelessSmokeDetectorRatePlan (bundle: any) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) =>
            x.defaultName ==
            ORDER_PLAN_SKUS.BASIC_WIRELESS_SMOKE[PlanDuration.CPS_MOI12M_NEW] // 'RPMOISMOKEDVCBASC12'
        );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) =>
            x.defaultName ==
            ORDER_PLAN_SKUS.BASIC_WIRELESS_SMOKE[PlanDuration.CPS_MOI24M_NEW] //'RPMOISMOKEDVCBASC24'
        );
    }
  }

  extractBasicWirelessHeatDetectorRatePlan (bundle: any) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIHEATDVCBASIC12'
        );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIHEATDVCBASIC24'
        );
    }
  }

  extractATEPaymentChargesRatePlan (bundle: any) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIATEDVC12'
        );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIATEDVC24'
        );
    }
  }

  extractAdditionalWirelessSmokeDetectorFromOrder (
    bundle: any,
    currentOrder: Models.OrderModel
  ) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0 &&
      currentOrder &&
      currentOrder.orderConfiguration &&
      currentOrder.orderConfiguration.postPaidOrderAdditionalDevices
    ) {
      if (
        bundle.defaultName === PlanDuration.CPS_MOI12M_NEW &&
        'RPMOISMOKEDVCOPT12' in
          currentOrder.orderConfiguration.postPaidOrderAdditionalDevices
      )
        return currentOrder.orderConfiguration.postPaidOrderAdditionalDevices[
          'RPMOISMOKEDVCOPT12'
        ];
      else if (
        bundle.defaultName === PlanDuration.CPS_MOI24M_NEW &&
        'RPMOISMOKEDVCOPT24' in
          currentOrder.orderConfiguration.postPaidOrderAdditionalDevices
      )
        return currentOrder.orderConfiguration.postPaidOrderAdditionalDevices[
          'RPMOISMOKEDVCOPT24'
        ];
    }
    return 0.0; //added later - check if this is needed
  }

  extractAdditionalHeatDetectorFromOrder (
    bundle: any,
    currentOrder: Models.OrderModel
  ) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0 &&
      currentOrder &&
      currentOrder.orderConfiguration &&
      currentOrder.orderConfiguration.postPaidOrderAdditionalDevices
    ) {
      if (
        bundle.defaultName === PlanDuration.CPS_MOI12M_NEW &&
        'RPMOIHEATDVCOPT12' in
          currentOrder.orderConfiguration.postPaidOrderAdditionalDevices
      )
        return currentOrder.orderConfiguration.postPaidOrderAdditionalDevices[
          'RPMOIHEATDVCOPT12'
        ];
      else if (
        bundle.defaultName === PlanDuration.CPS_MOI24M_NEW &&
        'RPMOIHEATDVCOPT24' in
          currentOrder.orderConfiguration.postPaidOrderAdditionalDevices
      )
        return currentOrder.orderConfiguration.postPaidOrderAdditionalDevices[
          'RPMOIHEATDVCOPT24'
        ];
    }
    return 0.0; //added later - check if this is needed
  }

  extractAdditionalWirelessSmokeDetectorRatePlan (bundle: any) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOISMOKEDVCOPT12'
        );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOISMOKEDVCOPT24'
        );
    }
  }

  extractAdditionalHeatDetectorRatePlan (bundle: any) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIHEATDVCOPT12'
        );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIHEATDVCOPT24'
        );
    }
  }

  extractMonthlyRecurringChargesRatePlan (bundle: any) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      if (bundle.defaultName === PlanDuration.CPS_MOI12M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIPOST12'
        );
      else if (bundle.defaultName === PlanDuration.CPS_MOI24M_NEW)
        return bundle.subProducts.find(
          (x: { defaultName: string }) => x.defaultName == 'RPMOIPOST24'
        );
    }
  }

  extractMonitoringServiceCharges (bundle: any) {
    if (
      bundle.defaultName &&
      bundle.subProducts &&
      bundle.subProducts.length > 0
    ) {
      return bundle.subProducts.find(
        (x: { defaultName: string }) => x.defaultName == 'RPMOIANMSCHARGE'
      );
    }
  }

  calculateAggregatedMonthlyCharges (
    bundle: any,
    currentOrder: Models.OrderModel
  ) {
    // Monthly Plan + Monitoring and Maintenance + additional devices
    let monthlyCharges =
      this.extractMonthlyRecurringCharges(
        this.extractMonitoringServiceCharges(bundle)
      ) +
      this.extractMonthlyRecurringCharges(
        this.extractMonthlyRecurringChargesRatePlan(bundle)
      );
    if (
      this.extractAdditionalWirelessSmokeDetectorFromOrder(bundle, currentOrder)
    )
      // additional smoke detector price
      monthlyCharges +=
        this.extractMonthlyRecurringCharges(
          this.extractAdditionalWirelessSmokeDetectorRatePlan(bundle)
        ) *
        Number(
          this.extractAdditionalWirelessSmokeDetectorFromOrder(
            bundle,
            currentOrder
          )
        );
    if (this.extractAdditionalHeatDetectorFromOrder(bundle, currentOrder))
      // additional Heat detector price
      monthlyCharges +=
        this.extractMonthlyRecurringCharges(
          this.extractAdditionalHeatDetectorRatePlan(bundle)
        ) *
        Number(
          this.extractAdditionalHeatDetectorFromOrder(bundle, currentOrder)
        );
    return monthlyCharges;
  }

  extractMonthlyRecurringCharges (product: any) {
    if (
      product &&
      product.deviceSpecifications &&
      product.deviceSpecifications.length > 0 &&
      product.deviceSpecifications[0].chargeDetails &&
      product.deviceSpecifications[0].chargeDetails.length > 0
    ) {
      const charge = product.deviceSpecifications[0].chargeDetails.find(
        (charge: { type: string }) => charge.type == 'RECURRING'
      );
      return charge && charge.amount ? charge.amount : 0;
    }
    return 0.0;
  }

  isCurrentOrderPostPaid (currentOrder: Models.OrderModel) {
    return (
      (currentOrder &&
        currentOrder.planType &&
        currentOrder.planType == Enums.PlanType.MONTHLY) ||
      (currentOrder.type &&
        currentOrder.type.id == Models.OrderType.POSTPAID.ID)
    );
  }
}
