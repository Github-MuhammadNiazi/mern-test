import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { ChangeDetectorRef, Component, Inject, OnInit, Optional, inject } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { DeviceSpec, QuoteResponse } from './quote-details.interface';
import { Enums, Models, ToastService, TranslateAsyncPipe } from 'shared-state';
import { OrderData, OrderDetails } from './order-details.interface';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
// import mockData from './mockData.json';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, TranslateAsyncPipe, FormsModule],
  providers: [DatePipe],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class HomeAppComponent implements OnInit {
  title = 'home-dashboard-mfe';
  data?: OrderData;
  userId!: string;
  dateWithoutTime!: string;
  deviceCounts: { name: string; count: number }[] = [];
  quote!: DeviceSpec[];
  editing = false;
  private regex = /^0[5][0-9]{8}$/;
  private toastSvc = inject(ToastService);

  deviceCodeMap: Record<string, string[]> = {
    "Smoke Detector": [
      "RP_RESIDEO_SMOKE_DETECTOR",
      "RPMOISMOKEDVCJCI",
      "RPFIREALARMSMOKEHO",
      "RPFIREALARMSMOKE",
      "RPFIREALARMSMOKE2"
    ],
    "Alarm Panel Device": [
      "RPFIREALARMSIRENHO",
      "RPMOISIRENDVCJCI",
      "RPFIREALARMSIREN"
    ],
    "Wireless Heat Detector": [
      "RP_RESIDEO_HEAT_DETECTOR",
      "RPMOIHEATDVCJCI",
      "RPFIREALARMHEATHO",
      "RPFIREALARMHEAT",
      "RPFIREALARMHEAT2"
    ],
    "Wireless Repeater": [
      "RP_RESIDEO_REPEATER",
      "RPMOIREPDVCJCI",
      "RPFIREALARMREPHO",
      "RPFIREALARMREP",
      "RPFIREALARMREP2"
    ],
    "ATEPAY": [
      "RP_RESIDEO_ATE",
      "RPMOIATEPAYJCI",
      "RPFIREALARMATEPAYHO",
      "RPFIREALARMATEPAY",
      "RPFIREALARMATEPAY2",
      "RPFIREALARMATEPAY3"
    ]
  };

  constructor (
    private route: ActivatedRoute,
    @Optional()
    @Inject('orderData')
    private orderData: (id: number) => Observable<OrderDetails>,
    @Optional()
    @Inject('quoteData')
    private quoteData: (id: number) => Observable<QuoteResponse>,
    @Optional()
    @Inject('updateSecondaryPhoneNo')
    private updateSecondaryPhoneNo: (id: number, orderData: OrderData) => Observable<Models.OrderModel>,
    private cdr: ChangeDetectorRef,
    private datePipe: DatePipe
  ) {
    this.userId = this.route.snapshot.paramMap.get('userId') ?? '';
  }

  newNumber = this.data?.attendantContactNumber;

  isValidPhone (): boolean {
    return this.regex.test(this.newNumber ?? '');
  }

  toggleEdit () {
    this.editing = !this.editing;
    if (this.editing) {
      this.newNumber = this.data?.attendantContactNumber;
    }
  }

  saveNumber () {
    if (!this.isValidPhone()) return;
    if (this.newNumber && this.newNumber.trim() && this.data) {
      this.data = {
        ...this.data,
        attendantContactNumber: this.newNumber.trim()
      };
      this.updateSecondaryPhoneNo(Number(this.userId), this.data).subscribe({
        next: (res) => {
          this.toastSvc.success('Success', 'Phone number updated successfully');
          this.editing = false;
          if (res.attendantContactNumber) {
            this.newNumber = res.attendantContactNumber;
          }
          this.editing = false;
        },
        error: (err) => {
          this.toastSvc.error('Error', 'Phone number not updated');
          console.error('API error:', err);
        }
      });
      this.editing = false;
    } else {
      this.toastSvc.warning('Order data is unavailable', 'Phone number not updated');
      this.editing = false;
    }
  }

  ngOnInit () {
    this.loadOrder();
    this.loadQuote();
  }

  loadOrder () {
    // this.data = mockData.data;
    this.orderData(Number(this.userId)).subscribe({
      next: (res: OrderDetails) => {
        this.data = res.data as OrderData;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error(err);
        this.toastSvc.error('Error', 'Failed to load order data');},
    });
  }

  loadQuote () {
    // if(mockData) {
    //   this.quote = mockData.data.deviceSpecs as DeviceSpec[];
    //   this.countDevices();
    // }
    this.quoteData(Number(this.userId)).subscribe({
      next: (res: QuoteResponse) => {
        this.quote = res.data.deviceSpecs as DeviceSpec[];
        this.countDevices();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.toastSvc.error('Error', 'Failed to load quote data');
        console.error(err);
      },
    });
  }

  /**
  * Find group name from deviceCodeMap
  */
  private findDeviceGroupName (code: string): string {
    for (const [group, codes] of Object.entries(this.deviceCodeMap)) {
      if (codes.includes(code)) {
        return group;
      }
    }
    return code; // fallback if no match
  }

  /**
  * Count devices and map to group names
  */
  countDevices (): void {
    const countMap = this.quote.reduce((acc, item) => {
      const groupName = this.findDeviceGroupName(item.deviceCode);
      acc[groupName] = (acc[groupName] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    this.deviceCounts = Object.entries(countMap).map(([name, count]) => ({
      name,
      count,
    }));
  }

  checkPlanType (planType: string) {
    switch (planType) {
    case 'CUSTOM': return 'One Time';
    default: return planType;
    }
  }

  calculateDevices (imgeURL: string) {
    switch (imgeURL) {
    case 'Alarm Panel Device': return '../../images/icons/alarm-pannel.svg';
    case 'Wireless Repeater': return '../../images/icons/wireless-repeater.svg';
    case 'Smoke Detector': return '../../images/icons/smoke-detector.svg';
    case 'Wireless Heat Detector': return '../../images/icons/heat-detector.svg';
    default: return '';
    }
  }

  getOrderPaymentStatusClass (paymentStatus: string) {
    switch (paymentStatus) {
    case Enums.OrderPaymentStatus.Successful: return 'status-badge status-installed';
    case Enums.OrderPaymentStatus.Failed: return 'status-badge status-pending';
    default: return 'status-badge status-waiting';
    }
  }

  getOrderPaymentStatusIcon (status: string) {
    switch (status) {
    case  Enums.OrderPaymentStatus.Successful: return '../../images/svg-icons/success-icon.svg';
    case Enums.OrderPaymentStatus.Failed: return '../../images/svg-icons/warn-icon.svg';
    default: return '../../images/svg-icons/watch-icon.svg';
    }
  }

  getOrderStatusClass (paymentStatus: string) {
    switch (paymentStatus) {
    case Enums.OrderStatus.Closed: return 'status-badge status-installed';
    case Enums.OrderStatus.Fail: return 'status-badge status-pending';
    default: return 'status-badge status-waiting';
    }
  }

  getOrderStatusIcon (status: string) {
    switch (status) {
    case Enums.OrderStatus.Fail: return '../../images/svg-icons/warn-icon.svg';
    case Enums.OrderStatus.Closed: return '../../images/svg-icons/success-icon.svg';
    default: return '../../images/svg-icons/watch-icon.svg';
    }
  }

  dateFormat (date: string) {
    const isoDateString = date.replace(/(\d{2})\/(\d{2})\/(\d{4})/, '$2/$1/$3');
    const validDate = new Date(isoDateString);
    return this.datePipe.transform(validDate, 'dd/MM/yyyy') || '';
  }

  getStatusLabel (status: string | null): string {
    switch (status) {
    case Enums.OrderStatus.SurveyInProgress: return 'In progress';
    case Enums.OrderStatus.AddVillaDocs: return 'Add Villa Documents';
    case Enums.OrderStatus.PendingAdditionalPayment: return 'Pending Payment';
    case Enums.OrderStatus.Closed: return 'Successful';
    case Enums.OrderStatus.Fail: return 'Failed';
    default: return status ? status.replace(/_/g, ' ').toLowerCase() : '';
    }
  }

  getPaymentStatusLabel (status: string | null): string {
    switch (status) {
    case Enums.OrderPaymentStatus.Successful: return 'Paid';
    case Enums.OrderPaymentStatus.Pending: return 'Pending';
    case Enums.OrderPaymentStatus.Failed: return 'Failed';
    case Enums.OrderPaymentStatus.PendingOffline: return 'Pending Offline';
    default: return status ? '' : '';
    }
  }

}
