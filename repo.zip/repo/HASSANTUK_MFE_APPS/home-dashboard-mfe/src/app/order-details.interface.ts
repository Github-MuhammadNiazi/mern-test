export interface OrderDetails {
  status: string;
  data: OrderData;
  message: string;
  accepted: boolean;
}

export interface OrderData {
  creationDate: string;
  lastUpdateDate: number;
  id: number;
  orderName: string;
  accountNumber: string;
  plotNumber: string;
  villaNumber: string;
  address: string;
  community: string;
  city: string;
  emirate: string;
  makani: string | null;
  eidNumber: string;
  latitude: string;
  longitude: string;
  premiseName: string | null;
  premiseType: string;
  gisPremiseId: string;
  paymentAmount: number;
  paymentStatus: string;
  epgPaymentTrxnId: string;
  paymentDate: string;
  requestId: string;
  primaryMobileNumber: string;
  secondaryMobileNumber: string | null;
  etisalatLandlineNumber: string | null;
  attendantName: string;
  attendantContactNumber: string;
  boqGenerationDate: string | null;
  status: string;
  termsAndConditionsAccepted: boolean;
  statusUpdatedToBackend: boolean;
  partyOrderCreationState: number;
  lastNotificationDate: string | null;
  user: UserDetails;
  orderDocuments: unknown[];
  orderConfiguration: unknown | null;
  isSubsidized: boolean;
  subOrders: SubOrder[];
  epgPaymentTrxnResponseCode: string;
  rtfUpdateOrderResponseCode: string;
  type: OrderType;
  subOrder: boolean;
  planType: string;
  orderDiscount: unknown | null;
  paymentMethodId: unknown | null;
  paymentDay: unknown | null;
  transferFlow: unknown | null;
  ordersMetadata: OrdersMetadata;
  invoice: InvoiceDetails;
  postPaid: boolean;
  sharjahSubsidized: boolean;
  default: boolean;
}

export interface SubOrder {
  requestId: string;
  status: string; // add more if needed
  paymentAmount: number;
  creationDate: string; // can use Date if you parse it
}

export interface UserDetails {
  creationDate: string;
  lastUpdateDate: number;
  id: number;
  documentId: string;
  documentType: string;
  documentExpiryDate: string;
  email: string;
  firstNameEn: string;
  fistNameAr: string;
  lastNameAr: string;
  lastNameEn: string;
  gender: string;
  isEtisalatCustomer: boolean;
  nationality: string;
  primaryMobileNumber: string;
  landlineNumber: string | null;
  birthDate: string;
  locale: string;
  partyId: string;
  residentialProfileId: string;
  passwordExpired: boolean;
  userDocuments: unknown[];
  userRoles: UserRole[];
  isDeveloper: boolean;
  active: boolean;
  locked: boolean;
  subsidizedAccountId: string | null;
  firstInvalidAttemptAt: string | null;
  lastInvalidAttemptAt: string | null;
  invalidLoginAttemptsCount: number;
  type: UserType;
  channel: string | null;
  channelToken: string | null;
  postPaid: boolean;
  sharjahSubsidized: boolean;
  nameAr: string;
  prePaid: boolean;
  roles: Role[];
  name: string;
  default: boolean;
}

export interface UserRole {
  id: number;
  role: Role;
}

export interface Role {
  creationDate: string | null;
  lastUpdateDate: string | null;
  id: number;
  active: boolean;
  comments: string | null;
  name: string;
  displayName: string;
  privileges: unknown[];
}

export interface UserType {
  id: number;
  name: string;
  description: string;
}

export interface OrderType {
  id: number;
  name: string;
  description: string;
}

export interface OrdersMetadata {
  id: number;
  isTowDueAmountPaid: boolean;
  isTechVisitDue: boolean;
  exitCharges: unknown | null;
  techVisitAndExitCharges: unknown | null;
  towDueCharges: unknown | null;
  fromOrder: unknown | null;
  createDate: number;
  lastUpdateDate: number;
  sourcePlan: unknown | null;
  targetPlan: unknown | null;
  isTransferred: boolean;
  accountActivationDate: unknown | null;
  techVisitRequestId: unknown | null;
}

export interface InvoiceDetails {
  requestSummary: RequestSummary;
  paid: PaidDetails;
  unpaid: UnpaidDetails;
  totalPrice: number;
  isSubsidized: boolean;
  ordertype: unknown | null;
}

export interface RequestSummary {
  locale: string | null;
  requestID: string;
  requestStatus: string;
  snagList: unknown[];
  snagListCleared: boolean;
  totalPaidAmount: string;
}

export interface PaidDetails {
  locale: string | null;
  deviceSpecs: DeviceSpec[];
  totalDevicesPrice: number;
  totalSubsidizedDevicesPrice: number;
  serviceSpecs: ServiceSpec[];
  totalServicesPrice: number;
  totalBuffer: number;
  totalSubsidizedBuffer: number;
  totalPrice: number;
  totalSubsidizedPrice: number;
  totalVatPrice: number;
  againstOrder: unknown | null;
  subsidyApplied: boolean;
}

export interface DeviceSpec {
  locale: string | null;
  unit: number;
  unitPrice: string;
  unitSubsidizedPrice: string | null;
  unitPriceForCalc: number;
  vat: number;
  subsidizedVat: number;
  vatPercentage: number;
  totalPrice: string;
  totalSubsidizedPrice: string | null;
  buildingType: string;
  buildingLabel: string;
  floorNumber: string;
  floorLabel: string | null;
  roomType: string;
  roomLabel: string;
  deviceCode: string;
  deviceLabel: string | null;
  description: string;
  visible: boolean;
  subsidizedAccounts: unknown | null;
  additionalDevice: boolean;
}

export interface ServiceSpec {
  locale: string | null;
  unit: number;
  unitPrice: string;
  unitSubsidizedPrice: string | null;
  unitPriceForCalc: number;
  vat: number;
  subsidizedVat: number;
  vatPercentage: number;
  totalPrice: string;
  totalSubsidizedPrice: string | null;
  serviceType: string;
  serviceCode: string;
  serviceLabel: string;
}

export interface UnpaidDetails {
  locale: string | null;
  deviceSpecs: unknown[];
  totalDevicesPrice: number;
  totalSubsidizedDevicesPrice: number;
  serviceSpecs: unknown[];
  totalServicesPrice: number;
  totalBuffer: number;
  totalSubsidizedBuffer: number;
  totalPrice: number;
  totalSubsidizedPrice: number;
  totalVatPrice: number;
  againstOrder: unknown | null;
  subsidyApplied: boolean;
}
