export interface QuoteResponse {
  status: string;
  data: QuoteData;
}

export interface QuoteData {
  locale: string | null;
  deviceSpecs: DeviceSpec[];
}

export interface DeviceSpec {
  locale: string | null;
  unit: number;
  unitPrice: string;
  unitSubsidizedPrice: string | null;
  unitPriceForCalc: number;
  vat: number;
  subsidizedVat: number;
  vatPercentage: number;
  totalPrice: string;
  totalSubsidizedPrice: string | null;
  buildingType: string;
  buildingLabel: string;
  floorNumber: string;
  floorLabel: string | null;
  roomType: string;
  roomLabel: string;
  deviceCode: string;
  deviceLabel: string | null;
  description: string;
  visible: boolean;
  subsidizedAccounts: unknown | null;
  additionalDevice: boolean;
}
