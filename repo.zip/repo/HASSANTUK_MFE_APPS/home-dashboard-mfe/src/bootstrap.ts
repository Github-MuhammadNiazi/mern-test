import { HomeAppComponent } from './app/app.component';
import { appConfig } from './app/app.config';
import { bootstrapApplication } from '@angular/platform-browser';

bootstrapApplication(HomeAppComponent, appConfig)
  .catch((err) => console.error(err));
