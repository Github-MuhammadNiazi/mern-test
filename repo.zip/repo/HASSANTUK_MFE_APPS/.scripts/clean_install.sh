#!/bin/bash

# Script to clean and reinstall dependencies for all MFE folders
# This script deletes dist and node_modules folders, then runs npm install

# --------------------------- INSTRUCTIONS ------------------------
#
# Please make sure that this script resides in either HASSANTUK_MFE_APPS or MOI_FE_SHELL_APP folder.
# Following should be your directory structure to use this:
#
# -------------------------------
#
# HASSANTUK_MFE_APPS
#   |_ <existing files>
#   |_ .scripts
#       |_clean_install.sh
#
# -------------------------------
#
#
# Steps to clean install
#
# Step 1 - execute `ng build` inside hassantuk_contracts_lib
# Step 2 - execute `.scripts/clean_install.sh` inside HASSANTUK_MFE_APPS using bash and wait for completion

set -e  # Exit on any error

echo "🚀 Starting cleanup and reinstallation for all MFE projects..."
echo "=================================================="

# Get the root directory (where the script is located)
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "Root directory: $ROOT_DIR"

# Counter for processed folders
processed_count=0
success_count=0
error_count=0

# Function to check if directory is an MFE project
is_mfe_project() {
    local dir="$1"
    # Check if package.json exists (indicating it's a Node.js project)
    if [[ -f "$dir/package.json" ]]; then
        return 0
    fi
    return 1 
}

# Function to clean a single project
clean_project() {
    local project_dir="$1"
    local project_name="$(basename "$project_dir")"

    echo ""
    echo "📁 Processing: $project_name"
    echo "----------------------------------------"

    cd "$project_dir"

    # Delete dist folder if it exists
    if [[ -d "dist" ]]; then
        echo "🗑️  Deleting dist folder..."
        rm -rf dist
        echo "✅ dist folder deleted"
    else
        echo "ℹ️  No dist folder found"
    fi

    # Delete node_modules folder if it exists
    if [[ -d "node_modules" ]]; then
        echo "🗑️  Deleting node_modules cache..."
        rm -rf node_modules/.cache
        echo "✅ node_modules cache deleted"
    else
        echo "ℹ️  No node_modules folder found"
    fi

    # Run npm install
    echo "📦 Running npm install..."
    if npm install; then
        echo "✅ npm install completed successfully"
        return 0
    else
        echo "❌ npm install failed"
        return 1
    fi
}

# Process root directory if it's an MFE project
if is_mfe_project "$ROOT_DIR"; then
    echo "📁 Processing root directory..."
    processed_count=$((processed_count + 1))

    if clean_project "$ROOT_DIR"; then
        success_count=$((success_count + 1))
    else
        error_count=$((error_count + 1))
        echo "❌ Failed to process root directory"
    fi

    # Return to root directory
    cd "$ROOT_DIR"
else
    echo "ℹ️  Root directory is not an MFE project (no package.json), skipping..."
fi

echo "📁 Processing all MFE subdirectories..."

# Process all directories in the root
for dir in "$ROOT_DIR"/*; do
    # Skip if not a directory
    if [[ ! -d "$dir" ]]; then
        continue
    fi

    # Skip if it's a hidden directory (starts with .)
    if [[ "$(basename "$dir")" == .* ]]; then
        continue
    fi

    # Skip if it's not an MFE project
    if ! is_mfe_project "$dir"; then
        echo "⏭️  Skipping $(basename "$dir") - not an MFE project (no package.json)"
        continue
    fi

    processed_count=$((processed_count + 1))

    # Clean and install for this project
    if clean_project "$dir"; then
        success_count=$((success_count + 1))
    else
        error_count=$((error_count + 1))
        echo "❌ Failed to process $(basename "$dir")"
    fi

    # Return to root directory
    cd "$ROOT_DIR"
done

# Summary
echo ""
echo "=================================================="
echo "🎉 Cleanup and reinstallation completed!"
echo "📊 Summary:"
echo "   - Total projects processed: $processed_count"
echo "   - Successful installations: $success_count"
echo "   - Failed installations: $error_count"

if [[ $error_count -eq 0 ]]; then
    echo "✅ All projects processed successfully!"
    exit 0
else
    echo "⚠️  Some projects failed. Please check the output above."
    exit 1
fi
