import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { FooterComponent } from './app/app.component';

bootstrapApplication(FooterComponent, appConfig)
  .catch((err) => console.error(err));
