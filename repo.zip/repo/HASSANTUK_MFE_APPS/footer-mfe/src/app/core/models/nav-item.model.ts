export interface NavItem {
    label: string;
    url: string;
    translationKey?: string;
}