// import { Injectable } from '@angular/core';
// import { of } from 'rxjs';

// @Injectable({ providedIn: 'root' })
// export class CmsService {
//   getNavItems(lang: string) {
//     // Simulate CMS fetch
//     return of([
//       { label: lang == 'en'? 'Home' : 'الصفحة الرئيسية', url: '/', translationKey: 'home-label' },
//       { label: lang == 'en'? 'About' :'حول الصفحة' , url: '/about', translationKey: 'about-label' },
//     ]);
//   }
// }