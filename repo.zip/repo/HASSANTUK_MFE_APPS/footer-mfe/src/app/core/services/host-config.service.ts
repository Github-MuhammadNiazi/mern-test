import { FooterLinks } from '../interfaces/cms-config.interface';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class HostConfigService {
  cmsData: FooterLinks = {
    "footerLinksEn": [
      {
        "_path": "/content/dam/moi/cfm/privacy-policy",
        "linkText": "Privacy Policy",
        "linkUrl": "/en/general/privacy-policy.html",
        "linkTarget": "_self",
        "logoImage": null
      },
      {
        "_path": "/content/dam/moi/cfm/faq",
        "linkText": "FAQ",
        "linkUrl": "/en/support/faqs.html",
        "linkTarget": "_blank",
        "logoImage": null
      },
      {
        "_path": "/content/dam/moi/cfm/terms-&-conditions",
        "linkText": "Terms & Conditions",
        "linkUrl": "/en/general/terms-and-conditions.html",
        "linkTarget": "_self",
        "logoImage": null
      }
    ],
    "footerLinksAr": [
      {
        "_path": "/content/dam/moi/cfm/privacy-policy",
        "linkText": "سياسة الخصوصية",
        "linkUrl": "/ar/general/privacy-policy.html",
        "linkTarget": "_self",
        "logoImage": null
      },
      {
        "_path": "/content/dam/moi/cfm/faq",
        "linkText": "الأسئلة الشائعة",
        "linkUrl": "/ar/support/faqs.html",
        "linkTarget": "_blank",
        "logoImage": null
      },
      {
        "_path": "/content/dam/moi/cfm/terms-&-conditions",
        "linkText": "الشروط والأحكام",
        "linkUrl": "/ar/general/terms-and-conditions.html",
        "linkTarget": "_self",
        "logoImage": null
      }
    ]
  };

  getNavItems (lang: string) {
    // Simulate host/client config for logged-in user
    return lang === 'en'
      ? of(this.cmsData.footerLinksEn)
      : of(this.cmsData.footerLinksAr);
  }
};
