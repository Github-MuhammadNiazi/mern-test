interface FooterLink {
  _path: string; // Path to the content
  linkText: string; // Text for the link
  linkUrl: string; // URL for the link
  linkTarget: '_self' | '_blank'; // Target for the link (_self or _blank)
  logoImage: LogoImage | null; // Optional logo image
}

interface LogoImage {
  _path: string; // Path to the logo image
}

export interface FooterLinks {
  footerLinksEn: FooterLink[]; // Array of English footer links
  footerLinksAr: FooterLink[]; // Array of Arabic footer links
};
