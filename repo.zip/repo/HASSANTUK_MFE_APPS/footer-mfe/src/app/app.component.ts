/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Inject, OnInit, Optional, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HostConfigService } from './core/services/host-config.service';
import { Store } from '@ngrx/store';
import { TranslationService } from 'shared-state';
import { User } from './core/models/auth.model';

import { selectUser } from './store/auth/auth.selectors';


@Component({
  selector: 'app-root',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class FooterComponent implements OnInit {
  title = 'footer-mfe';
  user: User | null = null;
  private hostConfig = inject(HostConfigService);
  footerURLs: any;
  copyRights= '';
  data: any;
  callCenterText= '';

  constructor (
    @Optional() @Inject('data') private channelName: any,
    @Optional() @Inject('footerLinks') footerData: any,
    @Optional() @Inject('devNewURL') public baseURL: string,
    private translationSvc: TranslationService,
    private store: Store<{ login: { user: User } }>
  ) {
    this.data =  footerData?.data?.footer?.data?.footerSectionByPath;
    console.log('this.baseURL', this.baseURL);
    this.footerURLs = this.data?.item?.footerLeftSection;
    this.copyRights = this.data?.item?.copyRightText;
    // Use a regular expression to extract the number
    // const numberMatch = this.data?.item?.callCenterText?.match(/\d+/g); // Matches all digits in the string
    // const phoneNumber = numberMatch ? numberMatch.join('') : ''; // Joins the digits into a single number

    // Use the extracted number in your template
    this.callCenterText = this.data?.item?.callCenterText;
  }

  ngOnInit () {
    this.subscribeToUserChanges();
    this.loadDynamicStyling();
  }

  subscribeToUserChanges (): void {
    this.store.select(selectUser).subscribe(user => {
      console.log('User data in footer MFE:', user);
      this.user = user;
      const lang = this.translationSvc.getCurrentLanguage();
      console.log('lang', lang);
      if (user) {
        this.fetchDynamicNavItems(lang);
      } else {
        return this.footerURLs;
      }
    });
  }

  fetchDynamicNavItems (lang: string): void {
    this.hostConfig.getNavItems(lang).subscribe(
      items => this.footerURLs = items,
      error => {
        console.error('Error fetching navigation items:', error);
        return this.footerURLs;
      }
    );
  }

  loadDynamicStyling (): void {
    const baseUrl = this.channelName ? new URL('./', import.meta.url).toString() : './';
    const stylePath = `${baseUrl}styling/${this.channelName}/footer.scss`;

    this.loadStyling(stylePath);
  }

  loadStyling (href: string) {
    const id = 'dynamic-theme';
    const existingLink = document.getElementById(id);
    if (existingLink) existingLink.remove();
    const link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href = href;
    document.head.appendChild(link);
  }
}
