import { createActionGroup, props, emptyProps } from '@ngrx/store';
import { User } from '../../core/models/auth.model';
 
export const AuthActions = createActionGroup({
  source: 'Auth',
  events: {
    'Login': props<{ user: User }>(),
    'Logout': emptyProps(),
  },
});