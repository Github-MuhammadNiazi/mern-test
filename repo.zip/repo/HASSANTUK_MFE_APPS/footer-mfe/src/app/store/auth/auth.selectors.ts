import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AuthState } from '../../core/models/auth.model';
 
export const selectAuthState = createFeatureSelector<AuthState>('auth');
 
export const selectUser = createSelector(
  selectAuthState,
  (state) => state.user
);
 
export const selectIsLoggedIn = createSelector(
  selectUser,
  (user) => !!user
);