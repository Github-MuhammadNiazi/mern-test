import { Component, EventEmitter,Input, Output, inject  } from '@angular/core';
import { Constants, TranslationService } from 'shared-state';
import { RouterLink, RouterLinkActive } from '@angular/router';

import { CommonModule } from '@angular/common';
import { NavItem } from '../core/models/nav-item.model';



@Component({
  selector: 'app-nav-bar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss',
})
export class NavBarComponent {
  @Input() navItems: NavItem[] | null = [];
  isMobileMenuOpen = false;
  // TODO: Replace 'any' with a UserModel from sharedState
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() user: any = null;
  @Output() langChange = new EventEmitter<Event>();
  @Output() menuEvent = new EventEmitter<string>();
  @Input() language = '';
  public translationSvc: TranslationService = inject(TranslationService);
  activeIndex = 0;
  constants = Constants;

  toggleMobileMenu () {
    this.isMobileMenuOpen = !this.isMobileMenuOpen;
  }

  onLanguageChange (event: Event) {
    event.preventDefault();
    this.language =
      this.language === this.constants.languages.english
        ? this.constants.languages.arabic
        : this.constants.languages.english;

    // Emiting a custom event with the new language value
    // This is done to support shared service implementation
    const customEvent = {
      ...event,
      target: {
        ...event.target,
        value: this.language,
      },
    } as Event;

    this.langChange.emit(customEvent);
    this.toggleMobileMenu();
  }
}
