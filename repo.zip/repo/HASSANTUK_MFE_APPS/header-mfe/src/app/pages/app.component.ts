import { ChangeDetectionStrategy, Component, Inject, OnInit, Optional } from '@angular/core';
import { Constants, TranslationService } from 'shared-state';
import { AsyncPipe } from '@angular/common';
import { NavBarComponent } from '../components/nav-bar.component';
import { NavItem } from '../core/models/nav-item.model';
import { Observable } from 'rxjs';
import { RouterOutlet } from '@angular/router';

import { Store } from '@ngrx/store';
import { User } from '../core/models/auth.model';
import { selectUser } from '../store/auth/auth.selectors';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, NavBarComponent, AsyncPipe],
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeaderComponent implements OnInit {
  navItems: NavItem[] = [];
  user: User | null = null;
  lang: string = Constants.languages.english; // Lazy Loading languge to english as default

  headerItems$: Observable<NavItem[]>;

  constructor (
    private transalationSvc: TranslationService,
    private store: Store<{ login: { user: User } }>,
    @Optional()
    @Inject('NAV_ITEMS') private navItemss$: Observable<NavItem[]>,
  ) {
    this.headerItems$ = this.navItemss$;
  }

  ngOnInit () {
    this.store.select(selectUser).subscribe((user) => {
      this.user = user;
    });
  }

  onLangChange (event: Event) {
    this.lang = (event.target as HTMLInputElement).value;
    localStorage.setItem('language',this.lang); // store in local to save user prefs refactor later
    this.transalationSvc.setLanguage(this.lang);
  }

  onMenuEvent (event: string) {
    console.log('Menu event:', event);
  }
}
