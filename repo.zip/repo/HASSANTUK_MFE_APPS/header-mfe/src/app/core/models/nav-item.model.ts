import { NavAction } from "../enums/enums";

export interface NavItem {
  label: string;
  translationKey: string;
  icon?: string; // Optional icon for the nav item
  url?: string; // Static URL for navigation
  dynamicUrl?: (userId: string) => string;
  action?: NavAction;
  callback?: () => void; // Optional callback function for custom actions
}
