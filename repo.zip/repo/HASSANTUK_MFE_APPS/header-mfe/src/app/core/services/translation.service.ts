import { Injectable } from '@angular/core';
import { of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class TranslationService {

    getNavItems() {
        let isLoggedInuser = true;
        if (isLoggedInuser) { //load from local
            return of([
                { label: 'Dashboard', url: '/dashboard', translationKey: 'welcome' },
                { label: 'Profile', url: '/profile', translationKey: 'headerMainText' },
            ]);
        }
        else { //load from cms
            return of([
                { label: 'Home', url: '/', translationKey: 'logout' },
                { label: 'About', url: '/about', translationKey: 'temperature' },
            ]);
        }
    }
}