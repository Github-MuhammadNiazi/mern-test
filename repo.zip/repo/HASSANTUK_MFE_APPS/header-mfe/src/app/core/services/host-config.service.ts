import { Injectable } from '@angular/core';
import { of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class HostConfigService {
  getNavItems(lang: string) {
    // Simulate host/client config for logged-in user
    return of([
      { label: lang === 'en' ? 'Dashboard' : 'لوحة القيادة', url: '/dashboard', translationKey: 'dashboard-label' },
      { label: lang === 'en' ?'Profile' : 'صفحة الملف الشخصي', url: '/profile', translationKey: 'nav.profile' },
    ]);
  }
}