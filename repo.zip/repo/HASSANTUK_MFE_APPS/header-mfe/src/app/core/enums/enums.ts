export enum NavAction {
    Logout = 'logout',
}
