import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { GisConfig } from '../config/gis-config.token';
import { Injectable } from '@angular/core';
import { Models } from 'shared-state';

interface IGisResponse {
  status: string;
  data?: unknown;
  code?: string;
}

interface IOrderModel {
  gisPremiseId?: string;
  id?: number;
}

@Injectable({
  providedIn: 'root'
})
export class GisService {
  private config: GisConfig | null = null;
  private currentOrderId: string | null = null;
  private currentOrder: IOrderModel | null = null;
  private currentLanguage = 'en';
  private redirectCallback: ((orderid: string) => void) | null = null;

  constructor (private http: HttpClient) {}

  /**
   * Set the GIS configuration (called from component)
   */
  setOrderId (orderId: string | null): void {
    this.currentOrderId = orderId;
  }

  /**
   * Get the GIS configuration
   */
  getOrderId (): string | null {
    return this.currentOrderId;
  }

  /**
   * Set the GIS configuration (called from component)
   */
  setConfig (config: GisConfig | null): void {
    this.config = config;
  }

  /**
   * Get the GIS configuration
   */
  getConfig (): GisConfig | null {
    return this.config;
  }

  /**
   * Set the redirect callback
   */
  setRedirectCallback (callback: ((orderId: string) => void) | null): void {
    this.redirectCallback = callback;
  }

  /**
   * Get the redirect callback
   */
  getRedirectCallback (): ((orderId: string) => void) | null {
    return this.redirectCallback;
  }

  /**
   * Set the current order
   */
  setCurrentOrder (order: IOrderModel | null): void {
    this.currentOrder = order;
  }

  /**
   * Get the current order
   */
  getCurrentOrder (): IOrderModel | null {
    return this.currentOrder;
  }

  /**
   * Set the current language
   */
  setCurrentLanguage (language: string): void {
    this.currentLanguage = language;
  }

  /**
   * Get the current language
   */
  getCurrentLanguage (): string {
    return this.currentLanguage;
  }

  /**
   * Check if the service is properly configured
   */
  isConfigured (): boolean {
    return !!(this.config && this.config.gisGetAccessToken);
  }

  /**
   * Get access token from the GIS service
   */
  getAccessToken (): Observable<IGisResponse> {
    if (!this.config || !this.config.gisGetAccessToken) {
      return throwError(() => new Error('GIS Access Token URL is not configured'));
    }

    return this.http.get<IGisResponse>(this.config.gisGetAccessToken, {withCredentials: true});
  }

  /**
   * Get map view data from the GIS service
   */
  getMapViewUrl (): Observable<IGisResponse> {
    if (!this.config || !this.config.gisGetMapViewUrl) {
      return throwError(() => new Error('GIS Map View URL is not configured'));
    }

    const params = { locale: this.currentLanguage };
    return this.http.get<IGisResponse>(this.config.gisGetMapViewUrl, {params, withCredentials: true});
  }

  createOrder (gisPremiseId: string, isSubsidizedOrder?: boolean): Observable<IGisResponse> {
    if (!this.config || !this.config.gisCreateOrderUrl) {
      return throwError(() => new Error('Create order URL is not configured'));
    }
    const params = new HttpParams()
      .set('gisPremiseId', gisPremiseId)
      .set('isSubsidizedOrder', isSubsidizedOrder ?? false);

    return this.http.get<IGisResponse>(this.config.gisCreateOrderUrl, {params, withCredentials: true});
  }

  /**
   * Get map view data from the GIS service
   */
  getOrderDetails (orderId: string): Observable<IGisResponse> {
    if (!this.config || !this.config.gisGetOrderUrl) {
      return throwError(() => new Error('Get order URL is not configured'));
    }
    return this.http.get<IGisResponse>(this.config.gisGetOrderUrl.replace('{{orderId}}', orderId), {withCredentials: true});
  }

  updateOrderDetails (order: Models.OrderModel): Observable<IGisResponse> {
    if (!this.config || !this.config.gisPatchOrderUrl) {
      return throwError(() => new Error('Update order URL is not configured'));
    }

    const reqBody = JSON.stringify(order);

    return this.http.patch<IGisResponse>(this.config.gisPatchOrderUrl.replace('{{orderId}}', order.id.toString()  ), reqBody, { withCredentials: true});
  }
}
