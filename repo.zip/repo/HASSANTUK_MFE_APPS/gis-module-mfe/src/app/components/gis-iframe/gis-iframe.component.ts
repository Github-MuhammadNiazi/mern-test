import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import {
  HassantukLoaderComponent,
  Models,
  SafePipe,
  ToastService,
  TranslateAsyncPipe,
  TranslationService
} from 'shared-state';
import { Subject, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { GisConfig } from './../../config/gis-config.token';
import { GisService } from './../../services/gis.service';
import { HttpErrorResponse } from '@angular/common/http';

type OrderModel = Models.OrderModel;

@Component({
  selector: 'gis-iframe',
  imports: [
    CommonModule,
    SafePipe,
    HassantukLoaderComponent,
    TranslateAsyncPipe
  ],
  templateUrl: './gis-iframe.component.html',
  styleUrl: './gis-iframe.component.scss',
})
export class GisIFrameComponent implements OnInit, OnDestroy {
  @ViewChild('gisFrame') iframe!: ElementRef;
  @ViewChild('gisLoader') gisLoader!: HassantukLoaderComponent;

  @Output() orderCreated = new EventEmitter<string>();

  private destroy$ = new Subject<void>();
  responseData = null;
  errorMessage = '';
  config: GisConfig | null = null;
  token = '';
  mapViewUrl = '';
  url = '';
  iframeHeight = '100%';
  appName = 'PORTAL';
  currentOrder: OrderModel | null = null;
  isLoading = true;
  hasError = false;

  constructor (
    private gisService: GisService,
    private toastService: ToastService,
    private translationService: TranslationService,
    private cdr: ChangeDetectorRef
  ) {
  }

  ngOnInit (): void {
    this.gisLoader?.show();
    this.config = this.gisService.getConfig();

    // Initialize translation service with default language if not set
    const currentLang = this.translationService.getCurrentLanguage();
    if (!currentLang || currentLang === 'en') {
      // Set default language and load translations
      this.translationService.setLanguage('en');
    }

    // Subscribe to language changes
    this.translationService.language$
      .pipe(takeUntil(this.destroy$))
      .subscribe((language) => {
        this.gisService.setCurrentLanguage(language);

        // Update iframe URL if already initialized
        if (this.token && this.mapViewUrl && !this.isLoading) {
          this.updateIframeForLanguageChange();
        }
      });

    const orderId = this.gisService.getOrderId();

    if (orderId) {
      this.updateCurrentOrder(orderId);
    }

    this.initializeGisModule();
  }

  //Listen iframe messages
  @HostListener('window:message', ['$event'])
  onMessage (e: MessageEvent): boolean {
    if (this.url.indexOf(e.origin) > -1) {
      if (e.data && e.data.bodyHeight) {
        this.iframeHeight = e.data.bodyHeight;
      } else if (e.data && e.data.premiseID) {
        this.handlePremiseIdSelection(e.data.premiseID);
      }
    } else {
      return false;
    }
    return true;
  }

  initializeGisModule (): void {
    this.getAccessToken();
  }

  getAccessToken (): void {
    if (!this.config) {
      this.errorMessage = 'GIS Configurations are not configured';
      this.handleError();
      return;
    }

    this.gisLoader?.show();
    this.hasError = false;

    const req$ = this.gisService.getAccessToken();

    req$.pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        if (res.status !== 'OK' || !res.data) {
          console.warn('Failure to get access token: ', res);
          this.handleError();
          return;
        }
        this.token = res.data as string;
        this.getMapViewUrl();
      },
      error: (err: HttpErrorResponse) => {
        console.error('getAccessToken HTTP error: ', err);
        this.handleError();
      },
    });
  }

  getMapViewUrl (): void {
    if (!this.config) {
      this.errorMessage = 'GIS Configurations are not configured';
      this.handleError();
      return;
    }

    const req$ = this.gisService.getMapViewUrl();

    req$.pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        if (res.status !== 'OK' || !res.data) {
          console.warn('Failure to get map view url: ', res);
          this.handleError();
          return;
        }
        this.mapViewUrl = res.data as string;
        this.url = this.createIframeUrl();
        this.isLoading = false;
        this.hasError = false;

        this.cdr.detectChanges();

        // URL is ready, hide loader and show success
        this.gisLoader?.hide();
      },
      error: (err: HttpErrorResponse) => {
        console.error('getMapViewUrl HTTP error: ', err);
        this.handleError();
      },
    });
  }

  createIframeUrl (): string {
    let locationUrl = '';
    const lockAddress = localStorage.getItem('LockAddress');
    const villaNo = localStorage.getItem('VillaNo');
    const plotNumber = localStorage.getItem('PlotNumber');
    const villaAddress = localStorage.getItem('VillaAddress');
    const community = localStorage.getItem('Community');
    const emirate = localStorage.getItem('Emirate');

    if (lockAddress) {
      locationUrl = '&LockAddress=Y';
    }
    if (villaNo) {
      locationUrl += '&VillaNo=' + villaNo;
    }
    if (plotNumber) {
      locationUrl += '&PlotNumber=' + plotNumber;
    }
    if (villaAddress) {
      locationUrl += '&VillaAddress=' + villaAddress;
    }
    if (community) {
      locationUrl += '&Community=' + community;
    }
    if (emirate) {
      locationUrl += '&Emirate=' + emirate;
    }

    // Use translation service to get current language
    const currentLang = this.translationService.getCurrentLanguage();
    const baseParams = `?requester=${this.appName}&requestedsystem=${this.appName}&token=${this.token}&lang=${currentLang}`;
    if (this.currentOrder && this.currentOrder.gisPremiseId) {
      return (
        this.mapViewUrl +
        baseParams +
        '&premiseid=' +
        this.currentOrder.gisPremiseId +
        locationUrl
      );
    } else {
      return this.mapViewUrl + baseParams + locationUrl;
    }
  }

  handlePremiseIdSelection (premiseId: string): void {
    if (!this.config) {
      this.errorMessage = 'GIS Configurations are not configured';
      this.handleError();
      return;
    }
    this.hasError = false;

    const isSubsidizedOrder = localStorage.getItem('isSubsidizedOrder');

    const req$ = this.gisService.createOrder(premiseId, isSubsidizedOrder == 'true');

    req$.pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        if (res.status !== 'OK' || !res.data) {
          console.warn('Failure to create order: ', res);
          this.handleError();
          return;
        }
        const newOrderId = (res.data as {id: string}).id as string;
        this.orderCreated.emit(newOrderId);
      },
      error: (err: HttpErrorResponse) => {
        console.error('handlePremiseIdSelection HTTP error: ', err);
        this.handleError();
      },
    });
  }

  /**
   * Update iframe URL when language changes
   */
  private updateIframeForLanguageChange (): void {
    this.gisLoader?.show();

    // Rebuild URL with new language
    this.url = this.createIframeUrl();

    this.cdr.detectChanges();

    // Short delay to show loading state
    setTimeout( () => {
      this.gisLoader?.hide();
    }, 300);
  }

  /**
   * Handle errors by showing log and setting error state
   */
  private handleError (): void {
    this.gisLoader?.hide();
    this.hasError = true;
    this.isLoading = false;

    this.cdr.detectChanges();
  }

  /**
   * Retry initialization when there's an error
   */
  retryInitialization (): void {
    this.hasError = false;
    this.gisLoader?.show();
    this.url = '';
    this.token = '';
    this.mapViewUrl = '';

    this.cdr.detectChanges();

    // Restart the initialization process
    this.initializeGisModule();
  }

  /**
   * Public method to reload the GIS module
   */
  reloadGisModule (): void {
    this.retryInitialization();
  }

  /**
   * Get access to the translation service for external components
   */
  getTranslationService (): TranslationService {
    return this.translationService;
  }

  updateCurrentOrder (orderId: string) {
    const req$ = this.gisService.getOrderDetails(orderId);
    req$.pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        if (res.status !== 'OK' || !res.data) {
          console.warn('Failure to get order: ', res);
          this.handleError();
          return;
        }
        this.setCurrentOrder(res.data as Models.OrderModel);
        this.cdr.detectChanges();
      },
      error: (err: HttpErrorResponse) => {
        console.error('HTTP error: ', err);
        this.handleError();
      },
    });
  }

  /**
   * Set the current order for the GIS module
   */
  setCurrentOrder (order: OrderModel | null): void {
    this.currentOrder = order;
    this.gisService.setCurrentOrder(order);
    // Rebuild URL if token and mapViewUrl are available
    if (this.token && this.mapViewUrl) {
      this.gisLoader?.show();
      this.url = this.createIframeUrl();

      this.cdr.detectChanges();

      // Simulate a small delay for URL processing
      setTimeout( () => {
        this.gisLoader?.hide();
      }, 500);
    }
  }

  /**
   * Set the current language for the GIS module (deprecated - use TranslationService.setLanguage instead)
   */
  setCurrentLanguage (language: string): void {
    console.warn(
      'setCurrentLanguage is deprecated. Use TranslationService.setLanguage () instead.'
    );
    this.translationService.setLanguage(language);
  }

  clearLocalStorage (): void {
    localStorage.removeItem('LockAddress');
    localStorage.removeItem('VillaNo');
    localStorage.removeItem('PlotNumber');
    localStorage.removeItem('VillaAddress');
    localStorage.removeItem('Community');
    localStorage.removeItem('Emirate');
    localStorage.removeItem('isSubsidizedOrder');
  }

  updateIframeUrl (): void {
    const newUrl = this.createIframeUrl();
    if (this.url !== newUrl) {
      this.url = newUrl;
      this.cdr.detectChanges();
    }
  }

  ngOnDestroy () {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
