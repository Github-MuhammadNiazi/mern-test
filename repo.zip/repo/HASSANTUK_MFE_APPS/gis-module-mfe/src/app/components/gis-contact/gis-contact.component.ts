import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import {
  HassantukLoaderComponent,
  Models,
  TranslateAsyncPipe,
} from 'shared-state';
import { Subject, finalize, takeUntil } from 'rxjs';
import { alphabetsOnlyValidator, mobileNumberValidator } from '../../common/custom.validators';
import { CommonModule } from '@angular/common';
import { GisConfig } from '../../config/gis-config.token';
import { GisService } from '../../services/gis.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-gis-contact',
  imports: [
    CommonModule,
    HassantukLoaderComponent,
    TranslateAsyncPipe,
    ReactiveFormsModule,
  ],
  templateUrl: './gis-contact.component.html',
  styleUrl: './gis-contact.component.scss',
})
export class GisContactComponent implements OnInit {
  private destroy$ = new Subject<void>();
  contactForm: FormGroup;
  config: GisConfig | null = null;
  errorMessage = '';
  hasError = false;
  isLoading = false;

  @Output() editOrderLocation = new EventEmitter<string>();

  constructor (private fb: FormBuilder, private gisService: GisService) {
    this.config = this.gisService.getConfig();
    this.contactForm = this.fb.group({
      name: ['', [Validators.required, alphabetsOnlyValidator()]],
      mobileNumber: ['', [Validators.required, mobileNumberValidator()]],
    });
  }

  ngOnInit (): void {
    const orderId = this.gisService.getOrderId();
    if (orderId) {
      const req$ = this.gisService.getOrderDetails(orderId);

      req$.pipe(takeUntil(this.destroy$)).subscribe({
        next: (res) => {
          if (res.status !== 'OK' || !res.data) {
            console.warn('Failure to get order: ', res);
            return;
          }
          this.gisService.setCurrentOrder(res.data as Models.OrderModel);
        },
        error: (err: HttpErrorResponse) => {
          console.error('HTTP error: ', err);
        },
      });
    }
  }

  onContinue () {
    const currentOrder = this.gisService.getCurrentOrder();
    const redirectCallback = this.gisService.getRedirectCallback();
    if (
      this.contactForm.valid &&
      (currentOrder as Models.OrderModel) &&
      currentOrder?.id
    ) {
      const { name, mobileNumber } = this.contactForm.value;

      const newOrder: Models.OrderModel = {
        ...currentOrder,
        attendantName: name,
        attendantContactNumber: mobileNumber,
      } as Models.OrderModel;

      if (!this.config) {
        this.errorMessage = 'GIS Configurations are not configured';
        return;
      }

      this.isLoading = true;
      this.hasError = false;

      const req$ = this.gisService.updateOrderDetails(newOrder);

      req$
        .pipe(
          takeUntil(this.destroy$),
          finalize(() => (this.isLoading = false))
        )
        .subscribe({
          next: (res) => {
            if (res.status !== 'OK' || !res.data) {
              console.warn('Failure to update order: ', res);
              return;
            }
            if (redirectCallback && currentOrder?.id) {
              redirectCallback(currentOrder.id.toString());
            } else {
              console.warn('No redirect callback provided by shell app');
            }
          },
          error: (err: HttpErrorResponse) => {
            console.error('handlePremiseIdSelection HTTP error: ', err);
          },
        });
    }
  }

  onBack () {
    try {
      const currentOrderId = this.gisService.getOrderId();
      if (currentOrderId) {
        this.editOrderLocation.emit();
      }
    } catch (err) {
      console.error(err);
    }
  }
}
