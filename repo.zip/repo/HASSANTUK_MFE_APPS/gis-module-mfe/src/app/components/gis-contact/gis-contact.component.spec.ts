import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GisContactComponent } from './gis-contact.component';

describe('GisContactComponent', () => {
  let component: GisContactComponent;
  let fixture: ComponentFixture<GisContactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GisContactComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(GisContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
