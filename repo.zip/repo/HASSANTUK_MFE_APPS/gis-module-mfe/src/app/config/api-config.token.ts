import {InjectionToken} from '@angular/core';

export interface ApiCfg {
  apiBase: string;
  getMapViewUrl: string;
  getGisAccessToken: string;
}

export const APP_CFG = new InjectionToken<ApiCfg>('APP_CFG');
