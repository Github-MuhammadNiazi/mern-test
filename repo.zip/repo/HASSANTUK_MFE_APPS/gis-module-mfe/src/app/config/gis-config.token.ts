import { InjectionToken } from '@angular/core';

export interface GisConfig {
  gisGetAccessToken: string;
  gisGetMapViewUrl: string;
  gisCreateOrderUrl: string;
  gisGetOrderUrl: string;
  gisPatchOrderUrl: string;
}

export const GIS_CFG = new InjectionToken<GisConfig>('GIS_CFG');
