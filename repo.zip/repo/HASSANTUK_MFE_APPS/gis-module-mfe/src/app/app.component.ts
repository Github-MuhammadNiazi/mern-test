import { Component, Inject, Optional } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { GisConfig } from './config/gis-config.token';
import { GisContactComponent } from './components/gis-contact/gis-contact.component';
import { GisIFrameComponent } from './components/gis-iframe/gis-iframe.component';
import { GisService } from './services/gis.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-root',
  imports: [CommonModule, GisIFrameComponent, GisContactComponent],
  templateUrl: './app.component.html',
})
export class GisViewerComponent {
  private destroy$ = new Subject<void>();
  config: GisConfig | null = null;
  isLocationSelected = false;
  isOrderLocationProcessed = false;
  isLoading = true;
  hasError = false;

  constructor (
    @Optional() @Inject('GIS_CFG') private injectedConfig: GisConfig,
    @Optional() @Inject('GIS_REDIRECT_CALLBACK') private redirectCallback: (orderid: string) => void,
    private gisService: GisService,
    private route: ActivatedRoute,
  ) {
    // Pass the injected config to the service
    this.gisService.setConfig(this.injectedConfig);
    this.gisService.setRedirectCallback(this.redirectCallback);
    this.gisService.setOrderId(this.route.snapshot.paramMap.get('orderId') || null);
  }

  orderCreated (orderId: string): void {
    this.gisService.setOrderId(orderId);
    this.isOrderLocationProcessed = true;
  }

  editOrderLocation (): void {
    this.isOrderLocationProcessed = false;
  }
}
