import { GisViewerComponent } from './app.component';
import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    component: GisViewerComponent
  }
];
