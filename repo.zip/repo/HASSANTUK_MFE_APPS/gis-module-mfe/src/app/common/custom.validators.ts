import { AbstractControl, ValidatorFn } from '@angular/forms';

export function mobileNumberValidator (): ValidatorFn {
  return (control: AbstractControl): Record<string, boolean> | null => {
    const mobile: string = control.value;

    // If the control is empty, return no error (required validator handles this)
    if (!mobile) {
      return null;
    }

    // Regex validation (e.g., must start with 05 and be exactly 10 digits)
    const regex = /^0[5][0-9]{8}$/;
    if (regex.test(mobile)) {
      return null; // Valid
    }

    return { invalidMobile: true }; // Invalid mobile
  };
}


export function alphabetsOnlyValidator (): ValidatorFn {
  return (control: AbstractControl): Record<string, boolean> | null => {
    const name: string = control.value;

    // If the control is empty, return no error (required validator handles this)
    if (!name) {
      return null;
    }

    // Regex validation (only alphabets and spaces allowed)
    const regex = /^[a-zA-Z\s]+$/;
    if (regex.test(name.trim())) {
      return null; // Valid
    }

    return { invalidName: true }; // Invalid name
  };
}
