import { AbstractControl, ValidatorFn } from '@angular/forms';

export function mobileNumberValidator (): ValidatorFn {
  return (control: AbstractControl): Record<string, boolean> | null => {
    const mobile: string = control.value;

    // If the control is empty, return no error (required validator handles this)
    if (!mobile) {
      return null;
    }

    // Regex validation (e.g., must start with 05 and be exactly 10 digits)
    const regex = /^0[5][0-9]{8}$/;
    if (regex.test(mobile)) {
      return null; // Valid
    }

    // if (regex.test(mobile) && mobile.length == 10) {
    //   const withoutFirstChar = mobile.substring(1);
    //   if (!withoutFirstChar.includes('+')) {
    //     return null; // Valid
    //   }
    // }

    return { invalidMobile: true }; // Invalid mobile
  };
}
