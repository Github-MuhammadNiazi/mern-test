import { Routes } from '@angular/router';
import { LoginComponent } from './app.component';


export const routes: Routes = [
    { path: '', component: LoginComponent }
];
