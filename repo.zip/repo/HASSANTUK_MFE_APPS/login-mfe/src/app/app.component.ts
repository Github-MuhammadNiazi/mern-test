import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import { AfterViewInit, Component, Inject, OnDestroy, OnInit, Optional, inject } from '@angular/core';
import { Autoplay, Pagination } from 'swiper/modules';
import { Constants, TranslateAsyncPipe, TranslationService } from "shared-state";
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';


import { CommonModule } from '@angular/common';
import Swiper from 'swiper';

import { mobileNumberValidator } from './common/custom.validators';



@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ReactiveFormsModule, CommonModule, TranslateAsyncPipe, RouterLink],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class LoginComponent implements AfterViewInit, OnInit, OnDestroy {
  title = 'login-mfe';
  loginForm: FormGroup;
  signupForm: FormGroup;
  isLoading = false;
  submitBtnText = "Continue";
  selectedTab = 'individual';
  isSignupAction = true;
  private swiper!: Swiper;
  private translationSvc = inject(TranslationService);
  constructor (
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,

    @Optional()
    @Inject('loginCallback')
    private loginCallback: (data: string) => void,
    @Optional()
    @Inject('signupCallback')
    private signupCallback: (data: string) => void,
    @Optional()
    @Inject('setUserTypeCallback')
    private setUserTypeCallback: (data: string) => void
  )
  {
    // Initialize the forms with empty values
    this.loginForm = this.fb.group({
      email: [''], // login only
    });
    this.signupForm = this.fb.group({
      phone: [''], // signup only
    });

    Swiper.use([Pagination, Autoplay]);
    this.route.data.subscribe(data => {
      this.isSignupAction = data['isSignup'];
      this.setControlValidators();
    });
  }

  ngOnDestroy (): void {
    this.swiper.destroy(true, true);
  }

  ngOnInit (): void {
    this.setControlValidators();

  }

  ngAfterViewInit (): void {
    this.initializeSwiper();
    this.translationSvc.language$.subscribe(lang => {
      const dir = lang === Constants.languages.arabic
        ? Constants.languageDirectionality.rightToLeft
        : Constants.languageDirectionality.leftToRight;
      this.swiper.changeLanguageDirection(dir);
      this.swiper.update();
    });
  }

  initializeSwiper () {
    this.swiper = new Swiper(".signup-slider", {
      loop: true,
      direction: 'horizontal',
      slidesPerView: 1,
      spaceBetween: 0,
      pagination: {
        el: ".signup-slider .swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".signup-slider .swiper-button-next",
        prevEl: ".signup-slider .swiper-button-prev",
      },
      autoplay: {
        delay: 3000, // Slide will change every 3 seconds
        disableOnInteraction: false, // Autoplay won't stop after user interaction
      },
    });
  }

  selectTab (tab: string) {
    this.selectedTab = tab;
    this.setUserTypeCallback?.(tab);
  }

  private setControlValidators () {
    const phone = this.signupForm.get('phone')!;
    const email = this.loginForm.get('email')!;

    if (this.isSignupAction) {
      phone.setValidators([
        Validators.required,
        mobileNumberValidator()
      ]);

      email.clearValidators();
    } else {
      email.setValidators([
        Validators.required,
        Validators.email
      ]);

      phone.clearValidators();
    }

    phone.updateValueAndValidity();
    email.updateValueAndValidity();
  }

  onContinue () {
    if (this.isSignupAction) {
      this.handleSignup();
    }
    else {
      this.handleLogin();
    }
  }

  handleLogin () {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }
    const value = this.loginForm.value;
    this.loginCallback?.(value.email);
    sessionStorage.setItem('fromInApp', 'true');
    this.router.navigate(['/login/otp'], {state: {fromInApp: true}});
  }

  handleSignup () {
    if (this.signupForm.invalid) {
      this.signupForm.markAllAsTouched();
      return;
    }
    const value = this.signupForm.value;
    this.signupCallback?.(value.phone);
    sessionStorage.setItem('fromInApp', 'true');
    this.router.navigate(['/signup/otp'],{state: {fromInApp: true}});
  }
}
