// @ts-check
const eslint = require("@eslint/js");
const tseslint = require("typescript-eslint");
const angular = require("angular-eslint");

module.exports = tseslint.config(
  {
    files: ["**/*.ts"],
    extends: [
      eslint.configs.recommended,
      ...tseslint.configs.recommended,
      ...tseslint.configs.stylistic,
      ...angular.configs.tsRecommended,
    ],
    processor: angular.processInlineTemplates,
    rules: {
      "prefer-arrow-callback": "error",
      "no-useless-return": "error",
      "indent": ["error", 2],
      "space-before-function-paren": ["error", "always"],
      "no-mixed-spaces-and-tabs": "error",
      "no-trailing-spaces": "error",
      "eol-last": ["error", "always"],
      "semi": ["error", "always"],
      "prefer-const": "error",
      "no-unused-expressions": "error",
      "no-empty-function": "error",
      "camelcase": ["error", { "properties": "always" }],
      "no-underscore-dangle": ["error", { "allowAfterThis": false }],
      "sort-imports": [
        "error",
        {
          "ignoreCase": false,
          "ignoreDeclarationSort": false,
          "memberSyntaxSortOrder": ["none", "all", "multiple", "single"],
        },
      ],
      "no-duplicate-imports": "error",
    }
  },
  {
    files: ["**/*.html"],
    extends: [
      ...angular.configs.templateRecommended,
      ...angular.configs.templateAccessibility,
    ],
    rules: {},
  }
);
