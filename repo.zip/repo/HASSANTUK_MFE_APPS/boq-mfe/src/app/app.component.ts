import { BoqService, IAuthService } from './services/boq.service';
import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit, Optional, ViewChild } from '@angular/core';
import { Enums, HassantukLoaderComponent, Interfaces } from 'shared-state';
import { Subject, finalize, takeUntil } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { BoqConfig } from './config/boq-config.token';
import { CommonModule } from '@angular/common';
import { PaymentFailedComponent } from './components/payment-failed/payment-failed.component';
import { PaymentSuccessComponent } from './components/payment-success/payment-success.component';
import { ReviewOrderComponent } from './components/review-order/review-order.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ReviewOrderComponent, PaymentSuccessComponent, PaymentFailedComponent, HassantukLoaderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit, OnDestroy {
  @ViewChild('boqLoader') boqLoader!: HassantukLoaderComponent;
  private destroy$ = new Subject<void>();
  title = 'boq-mfe';
  PaymentStatus = Enums.OrderPaymentStatus;
  paymentStatus: Enums.OrderPaymentStatus | null = null;
  orderId: string | null = null;
  orderData: Interfaces.IQuotation | null = null;
  isLoading = false;
  hasError = false;

  constructor (
    @Optional() @Inject('BOQ_CFG') private injectedConfig: BoqConfig,
    @Optional() @Inject('authService') private authService: IAuthService,
    @Optional() @Inject('backRedirectCallback') private backRedirectCallback: ((orderId: string) => void) | null,
    private boqService: BoqService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {
    // Pass the injected config to the service
    this.boqService.setConfig(this.injectedConfig);
    this.orderId = this.route.snapshot.paramMap.get('orderId');
    this.boqService.setOrderId(this.orderId);
    if (this.authService && this.authService.isAuthenticated$) {
      this.authService.isAuthenticated$.subscribe((isAuth: boolean) => {
        this.boqService.setIsAuthenticated(isAuth);
      });
    }
  }

  ngOnInit (): void {
    // Check for payment status in URL parameters first
    this.checkPaymentStatusFromRouteData();
    if (this.orderId && this.boqService.isConfigured() && !this.paymentStatus) {
      this.fetchOrderQuoteDetails();
    } else if (!this.boqService.isConfigured()) {
      console.error('BOQ service is not properly configured');
      this.hasError = true;
    }
  }

  ngOnDestroy (): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Check URL parameters for payment status
   */
  private checkPaymentStatusFromRouteData (): void {
    const routeData = this.route.snapshot.data;
    if (routeData['isPaymentSuccessRoute']) {
      this.paymentStatus = Enums.OrderPaymentStatus.Successful;
    } else if (routeData['isPaymentFailedRoute']) {
      this.paymentStatus = Enums.OrderPaymentStatus.Failed;
    }
  }

  /**
   * Set payment status (called by review-order component)
   */
  setPaymentStatus (status: Enums.OrderPaymentStatus | null): void {
    this.paymentStatus = status;
    this.cdr.detectChanges();
  }

  /**
   * Get payment status setter for review-order component
   */
  getPaymentStatusSetter (): (status: Enums.OrderPaymentStatus | null) => void {
    return this.setPaymentStatus.bind(this);
  }

  /**
   * Get back redirect callback for review-order component
   */
  getBackRedirectCallback (): ((orderId: string) => void) | null {
    return this.backRedirectCallback;
  }

  private fetchOrderQuoteDetails (): void {
    if (!this.orderId) return;

    this.isLoading = true;
    this.hasError = false;
    this.boqLoader?.show();

    this.boqService.getOrderQuoteDetails(this.orderId)
      .pipe(takeUntil(this.destroy$),finalize(() => {
        this.isLoading = false;
        this.boqLoader?.hide();
        this.cdr.detectChanges();
      }))
      .subscribe({
        next: (response) => {
          this.orderData = response.data as Interfaces.IQuotation;
          this.boqService.setCurrentOrder(this.orderData);

        },
        error: (error) => {
          console.error('Error fetching order details:', error);
          this.hasError = true;
        }
      });
  }

  /**
   * Helper function to pass as callback to switch loader.
   * @param show boolean
   */
  switchLoader = (show: boolean): void => {
    if (show)
      this.boqLoader?.show();
    else
      this.boqLoader?.hide();
  };
}

export { AppComponent as BoqComponent };

