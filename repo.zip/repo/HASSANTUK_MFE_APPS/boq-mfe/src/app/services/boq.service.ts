import { Interfaces, TranslationService } from 'shared-state';
import { Observable, throwError } from 'rxjs';
import { BoqConfig } from '../config/boq-config.token';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

interface IBoqResponse {
  status: string;
  data?: unknown;
  code?: string;
}

export interface IAuthService {
  isAuthenticated$: Observable<boolean>;
}

export interface IPaymentData {
  isAutopayFlag?: boolean;
  paymentDay?: string;
  paymentMethodId?: string;
  amount?: number;
}

@Injectable({
  providedIn: 'root'
})
export class BoqService {
  private config: BoqConfig | null = null;
  private isAuthenticated = false;
  private currentOrderId: string | null = null;
  private currentOrder: Interfaces.IQuotation | null = null;

  constructor (private http: HttpClient, private translationSvc: TranslationService) {}

  /**
   * Set the BOQ configuration (called from component)
   */
  setConfig (config: BoqConfig | null): void {
    this.config = config;
  }

  /**
   * Get the BOQ configuration
   */
  getConfig (): BoqConfig | null {
    return this.config;
  }

  /**
   * Set user authenticated status
   */
  setIsAuthenticated (isAuthenticated: boolean): void {
    this.isAuthenticated = isAuthenticated;
  }

  /**
   * Get user authenticated status
   */
  getIsAuthenticated (): boolean {
    return this.isAuthenticated;
  }

  /**
   * Set the order ID
   */
  setOrderId (orderId: string | null): void {
    this.currentOrderId = orderId;
  }

  /**
   * Get the order ID
   */
  getOrderId (): string | null {
    return this.currentOrderId;
  }

  /**
   * Set the current order
   */
  setCurrentOrder (order: Interfaces.IQuotation | null): void {
    this.currentOrder = order;
  }

  /**
   * Get the current order
   */
  getCurrentOrder (): Interfaces.IQuotation | null {
    return this.currentOrder;
  }

  /**
   * Check if the service is properly configured
   */
  isConfigured (): boolean {
    return !!(this.config && this.config.boqGetOrderQuoteUrl);
  }

  /**
   * Get order details from the BOQ service
   */
  getOrderDetails (orderId: string): Observable<IBoqResponse> {
    if (!this.config || !this.config.boqGetOrderUrl) {
      return throwError(() => new Error('BOQ Get Order URL is not configured'));
    }

    let url = this.config.boqGetOrderUrl;
    if (url.includes('{{orderId}}')) {
      url = url.replace('{{orderId}}', orderId);
    } else {
      url = url.endsWith('/') ? `${url}${orderId}` : `${url}/${orderId}`;
    }

    return this.http.get<IBoqResponse>(url, { withCredentials: true });
  }

  /**
   * Get order quote details from the BOQ service
   */
  getOrderQuoteDetails (orderId: string): Observable<IBoqResponse> {
    if (!this.config || !this.config.boqGetOrderQuoteUrl) {
      return throwError(() => new Error('BOQ Get Order Quote URL is not configured'));
    }

    let url = this.config.boqGetOrderQuoteUrl;
    if (url.includes('{{orderId}}')) {
      url = url.replace('{{orderId}}', orderId);
    } else {
      url = url.endsWith('/') ? `${url}${orderId}` : `${url}/${orderId}`;
    }

    return this.http.get<IBoqResponse>(url, { withCredentials: true });
  }

  /**
   * Get post paid order bill details from the BOQ service
   */
  getPostPaidOrderBillDetails (orderId: string): Observable<IBoqResponse> {
    if (!this.config || !this.config.boqGetPostpaidBillUrl) {
      return throwError(() => new Error('BOQ Get Postpaid Bill URL is not configured'));
    }

    const url = `${this.config.boqGetPostpaidBillUrl}?id=${orderId}&lang=${this.translationSvc.getCurrentLanguage()}`;

    return this.http.get<IBoqResponse>(url);
  }

  /**
   * Apply promo code to order
   */
  applyPromoCode (orderId: string, promoCode: string): Observable<IBoqResponse> {
    if (!this.config || !this.config.boqApplyPromoUrl) {
      return throwError(() => new Error('BOQ Apply Promo URL is not configured'));
    }

    let url = this.config.boqApplyPromoUrl;
    if (url.includes('{{orderId}}') && url.includes('{{promoCode}}')) {
      url = url.replace('{{orderId}}', orderId);
      url = url.replace('{{promoCode}}', promoCode);
    } else {
      console.warn('Invalid url:', url);
    }

    return this.http.get<IBoqResponse>(url, { withCredentials: true });
  }

  /**
   * Process payment for order
   */
  processPayment (orderId: string, paymentData?: IPaymentData): Observable<IBoqResponse> {
    if (!this.config) {
      return throwError(() => new Error('BOQ configuration is not set'));
    }

    let url: string;

    const headers = {
      'channel-token': 'NULL'
    };

    // Determine which endpoint to use based on payment data
    if (paymentData?.isAutopayFlag && paymentData?.paymentDay) {
      // Auto-pay processing
      if (!this.config.boqProcessAutoPayUrl) {
        return throwError(() => new Error('BOQ Process Auto Pay URL is not configured'));
      }
      url = this.config.boqProcessAutoPayUrl.replace('{{orderId}}', orderId);
      url += `?paymentDay=${paymentData.paymentDay}`;
    } else if (paymentData?.paymentMethodId && !paymentData?.isAutopayFlag) {
      // Payment with specific method
      if (!this.config.boqProcessPaymentWithMethodUrl) {
        return throwError(() => new Error('BOQ Process Payment With Method URL is not configured'));
      }
      url = this.config.boqProcessPaymentWithMethodUrl
        .replace('{{orderId}}', orderId)
        .replace('{{paymentDay}}', paymentData.paymentDay || '')
        .replace('{{paymentMethodId}}', paymentData.paymentMethodId);
    } else {
      // Standard payment processing
      if (!this.config.boqProcessPaymentUrl) {
        return throwError(() => new Error('BOQ Process Payment URL is not configured'));
      }
      url = this.config.boqProcessPaymentUrl.replace('{{orderId}}', orderId);
    }

    return this.http.get<IBoqResponse>(url, {
      withCredentials: true,
      headers: headers
    });
  }

  /**
   * Get payment status for order
   */
  getPaymentStatus (orderId: string): Observable<IBoqResponse> {
    if (!this.config || !this.config.boqPaymentStatusUrl) {
      return throwError(() => new Error('BOQ Payment Status URL is not configured'));
    }

    const url = this.config.boqPaymentStatusUrl.replace('{{orderId}}', orderId);
    return this.http.get<IBoqResponse>(url, { withCredentials: true });
  }
}
