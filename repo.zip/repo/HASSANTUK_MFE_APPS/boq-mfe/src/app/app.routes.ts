import { BoqComponent } from './app.component';
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', component: BoqComponent },
];
