import { InjectionToken } from '@angular/core';

export interface BoqConfig {
  boqGetOrderQuoteUrl: string;
  boqApplyPromoUrl?: string;
  boqProcessPaymentUrl?: string;
  boqProcessAutoPayUrl?: string;
  boqProcessPaymentWithMethodUrl?: string;
  boqPaymentStatusUrl?: string;
  boqGetOrderUrl?: string;
  boqGetPostpaidBillUrl?: string;
}

export const BOQ_CFG = new InjectionToken<BoqConfig>('BOQ_CFG');
