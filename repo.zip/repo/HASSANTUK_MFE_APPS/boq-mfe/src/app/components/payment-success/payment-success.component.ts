import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, finalize, takeUntil } from 'rxjs';
import { TranslateAsyncPipe, TranslationService } from 'shared-state';
import { ActivatedRoute } from '@angular/router';
import { BoqService } from '../../services/boq.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'payment-success-component',
  standalone: true,
  imports: [
    CommonModule,
    TranslateAsyncPipe,
  ],
  templateUrl: './payment-success.component.html'
})
export class PaymentSuccessComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  orderId: string | null = null;
  isAuthenticated = false;
  requestId: string | null = null;
  accountNumber: string | null = null;
  invoiceNumber: string | null = null;
  loading = false;
  error: string | null = null;

  constructor (
    private boqService: BoqService,
    private translationService: TranslationService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {
  }

  ngOnInit (): void {
    // Initialize translation service with default language if not set
    const currentLang = this.translationService.getCurrentLanguage();
    if (!currentLang || currentLang === 'en') {
      // Set default language and load translations
      this.translationService.setLanguage('en');
    }

    this.isAuthenticated = this.boqService.getIsAuthenticated();
    this.orderId = this.boqService.getOrderId();

    // Track payment success with Google Analytics
    this.trackPaymentSuccess();

    // Load order details based on authentication status
    this.loadOrderDetails();
  }

  ngOnDestroy (): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Track payment success with Google Analytics
   */
  private trackPaymentSuccess (): void {
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any).gtag('event', 'conversion', {
        'send_to': 'AW-11228734940/PFZlCLXSk4kZENzLo-op',
        'transaction_id': ''
      });
    } catch (error) {
      console.warn('Failed to track payment success:', error);
    }
  }

  /**
   * Load order details based on authentication status
   */
  private loadOrderDetails (): void {
    if (!this.orderId) {
      return;
    }

    this.loading = true;
    this.error = null;

    if (this.isAuthenticated) {
      // Call GET_ORDER endpoint for authenticated users
      this.getOrderDetails();
    } else {
      // Call postpaid bill endpoint for unauthenticated users
      this.callPostpaidBillEndpoint();
    }
  }

  /**
   * Call GET_ORDER endpoint for authenticated users
   */
  private getOrderDetails (): void {
    this.boqService
      .getOrderDetails(this.orderId as string)
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => {
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: (res) => {
          this.loading = false;
          const requestId = (res?.data as {requestId: string}).requestId;
          if (requestId) {
            this.requestId = requestId;
          }
        },
        error: (error) => {
          this.loading = false;
          this.error = 'Failed to load order details';
          console.error('Error loading order details:', error);
        }
      });
  }

  /**
   * Call postpaid bill endpoint for unauthenticated users
   */
  private callPostpaidBillEndpoint (): void {
    this.boqService
      .getPostPaidOrderBillDetails(this.orderId as string)
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => {
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: (res) => {
          this.loading = false;
          if (res?.data) {
            this.accountNumber = (res?.data as {accountNumber: string} ).accountNumber || null;
            this.invoiceNumber = (res?.data as {invoiceNumber: string} ).invoiceNumber || null;
          }
        },
        error: (error) => {
          this.loading = false;
          this.error = 'Failed to load bill details';
          console.error('Error loading bill details:', error);
        }
      });
  }
}
