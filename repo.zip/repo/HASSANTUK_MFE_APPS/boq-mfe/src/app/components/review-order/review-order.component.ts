import { BoqService, IPaymentData } from '../../services/boq.service';
import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import {
  Enums,
  Interfaces,
  Models,
  ToastService,
  TranslateAsyncPipe,
  TranslationService,
} from 'shared-state';
import { Subject, finalize, takeUntil } from 'rxjs';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface PaymentResponse {
  status: string,
  data: {
    Transaction: {
      TransactionID: string,
      PaymentPortal: string
    }
  }
}

@Component({
  selector: 'review-order-component',
  standalone: true,
  imports: [CommonModule, TranslateAsyncPipe, FormsModule],
  templateUrl: './review-order.component.html',
})
export class ReviewOrderComponent implements OnInit, OnDestroy {
  @Input() orderData: Interfaces.IQuotation | null = null;
  @Input() paymentStatusSetter?: (status: Enums.OrderPaymentStatus | null) => void;
  @Input() backRedirectCallback?: ((orderId: string) => void) | null;
  @Input() switchLoader?: (show: boolean) => void;

  // Quotation and order data
  quotation: Interfaces.IQuotation | null = null;
  orderId: string | null = null;

  // UI state
  isLoading = false;
  dataLoaded = false;

  // Pricing calculations
  totalDevicesChargesWithoutVAT = 0;
  totalSubscriptionChargesWithoutVAT = 0;
  totalDevicesChargesWithVAT = 0;
  totalSubscriptionChargesWithVAT = 0;

  // Coupon functionality
  couponCode = '';
  applyingCoupon = false;
  appliedCoupon = false;
  couponError = false;
  couponErrorMsg = '';

  // Terms and conditions
  termsAccepted = false;
  autoPayAccepted = false;

  // Payment processing state
  isProcessingPayment = false;

  // Payment error state
  paymentError = false;
  paymentErrorMessage = '';

  private destroy$ = new Subject<void>();

  constructor (
    private translationService: TranslationService,
    private boqService: BoqService,
    private cdr: ChangeDetectorRef,
    private toastSvc: ToastService
  ) {}

  ngOnInit (): void {
    // Initialize translation service with default language if not set
    const currentLang = this.translationService.getCurrentLanguage();
    if (!currentLang || currentLang === 'en') {
      // Set default language and load translations
      this.translationService.setLanguage('en');
    }

    // Get order ID from BOQ service
    this.orderId = this.boqService.getOrderId();

    // If order data is passed as input, use it
    if (this.orderData) {
      this.quotation = this.orderData;
      this.calculatePricing();
      this.dataLoaded = true;
    } else if (this.orderId) {
      // Otherwise, fetch quotation data
      this.getQuotation();
    }
  }

  ngOnDestroy (): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Get quotation data from the BOQ service
   */
  getQuotation (): void {
    if (!this.orderId) {
      console.error('No order ID available');
      return;
    }

    this.isLoading = true;
    if (this.switchLoader)
      this.switchLoader(true);

    this.boqService
      .getOrderQuoteDetails(this.orderId)
      .pipe(takeUntil(this.destroy$), finalize(() => this.cdr.detectChanges()))
      .subscribe({
        next: (response) => {
          if (response.status === 'OK' && response.data) {
            this.quotation = response.data as Interfaces.IQuotation;
            this.calculatePricing();
            this.dataLoaded = true;
          } else {
            console.error('Failed to fetch quotation data');
          }
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error fetching quotation:', error);
          this.isLoading = false;
        },
      });
  }

  /**
   * Calculate pricing totals from quotation data
   */
  calculatePricing (): void {
    if (!this.quotation) return;

    // Calculate device charges
    this.totalDevicesChargesWithoutVAT =
      this.quotation.deviceSpecs?.reduce(
        (sum, item) => sum + (item.unitPriceForCalc || 0) * (item.unit || 0),
        0
      ) || 0;

    this.totalDevicesChargesWithVAT =
      this.quotation.deviceSpecs?.reduce(
        (sum, item) => sum + parseFloat(item.totalPrice || '0'),
        0
      ) || 0;

    // Calculate subscription charges
    this.totalSubscriptionChargesWithoutVAT =
      this.quotation.serviceSpecs?.reduce(
        (sum, item) => sum + (item.unitPriceForCalc || 0),
        0
      ) || 0;

    this.totalSubscriptionChargesWithVAT =
      this.quotation.serviceSpecs?.reduce(
        (sum, item) => sum + parseFloat(item.totalPrice || '0'),
        0
      ) || 0;
  }

  /**
   * Function to determine if promo code should be allowed
   * @returns boolean
   */
  isPromoAllowed (): boolean {
    return !!this.quotation?.deviceSpecs?.length
      && !this.quotation?.againstOrder?.subOrder
      && !this.quotation?.againstOrder?.requestId;
  }

  /**
   * Get device specs grouped by building and floor
   */
  getDeviceSpecs (): Interfaces.DeviceSpec[] {
    return this.quotation?.deviceSpecs || [];
  }

  /**
   * Get service specs
   */
  getServiceSpecs (): Interfaces.ServiceSpec[] {
    return this.quotation?.serviceSpecs || [];
  }

  /**
   * Apply coupon code
   */
  applyCoupon (): void {
    if (!this.couponCode.trim()) return;

    this.applyingCoupon = true;
    this.couponError = false;

    // Get current order ID
    const currentOrderId = this.orderId || this.boqService.getOrderId();
    if (!currentOrderId) {
      this.couponError = true;
      this.applyingCoupon = false;
      return;
    }

    this.boqService
      .applyPromoCode(currentOrderId, this.couponCode)
      .pipe(takeUntil(this.destroy$), finalize(() => this.cdr.detectChanges()))
      .subscribe({
        next: (response) => {
          if (response.status === 'OK') {
            this.appliedCoupon = true;
            this.applyingCoupon = false;
            // Refresh quotation data to get updated pricing
            this.toastSvc.success(this.translationService.translateSync("nvf.success"), this.translationService.translateSync("nvf.couponAppliedSuccessfully"));
            this.getQuotation();
          } else {
            this.couponError = true;
            this.couponErrorMsg = this.translationService.translateSync('nvf.invalidPromoCode');
            this.applyingCoupon = false;
            this.toastSvc.warning(this.translationService.translateSync("nvf.oops"), this.translationService.translateSync("nvf.invalidCouponEntered"));
          }
        },
        error: (error) => {
          this.couponError = true;
          this.couponErrorMsg = this.translationService.translateSync('nvf.failedToApplyPromoCode');
          this.applyingCoupon = false;
          console.error('Error applying promo code:', error);
          this.toastSvc.error(this.translationService.translateSync("nvf.oops"), this.translationService.translateSync("nvf.unableToApplyCoupon"));

        },
      });
  }

  /**
   * Check if payment can be processed
   */
  canProceedToPayment (): boolean {
    // Basic requirement: terms must be accepted and data must be loaded
    if (!this.termsAccepted || !this.dataLoaded || this.isProcessingPayment || this.getTotalPrice() == 0) {
      return false;
    }

    // For postpaid orders, autopay acceptance is recommended but not mandatory
    // Users can still proceed without autopay
    return true;
  }

  /**
   * Process payment
   */
  processPayment (): void {
    if (!this.canProceedToPayment()) {
      this.toastSvc.warning(this.translationService.translateSync('nvf.warning'), this.translationService.translateSync('nvf.pleaseAcceptTermsConditions'));
      return;
    }

    if (!this.orderId) {
      this.toastSvc.error(this.translationService.translateSync('nvf.error'), this.translationService.translateSync('nvf.orderIdNotFound'));
      return;
    }

    // Reset error state
    this.paymentError = false;
    this.paymentErrorMessage = '';

    this.isProcessingPayment = true;
    if (this.switchLoader)
      this.switchLoader(true);

    // Prepare payment data based on order type
    const paymentData: IPaymentData = {};

    if (this.isPostPaidOrder() && this.autoPayAccepted) {
      // For postpaid orders with autopay
      paymentData.isAutopayFlag = true;
      paymentData.paymentDay = '1'; // TODO: Default to 1st of month, could be configurable
    } else {
      // For prepaid orders or postpaid without autopay
      paymentData.isAutopayFlag = false;
    }

    this.boqService
      .processPayment(this.orderId, paymentData)
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => {
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: (response) => {
          this.handlePaymentResponse(response as PaymentResponse);
        },
        error: (error) => {
          this.isProcessingPayment = false;
          if (this.switchLoader)
            this.switchLoader(false);
          this.handlePaymentError(error);
        }
      });
  }

  /**
   * Handle successful payment response
   */
  private handlePaymentResponse (response: PaymentResponse): void {
    this.isProcessingPayment = false;
    if (this.switchLoader)
      this.switchLoader(false);

    if (response.status === 'OK' && response.data?.Transaction) {
      // Payment processing initiated successfully - redirect to payment portal
      const paymentTransaction: Models.PaymentTransactionModel = {
        paymentTransactionId: response.data.Transaction.TransactionID,
        paymentPortalURL: response.data.Transaction.PaymentPortal,
        showLogo: true
      };

      // Redirect to payment portal
      this.redirectToPaymentPortal(paymentTransaction);
    } else if (response.status === 'CONFLICT') {
      // Payment is pending offline authorization
      if (this.paymentStatusSetter) {
        this.paymentStatusSetter(Enums.OrderPaymentStatus.PendingOffline);
      }
      this.toastSvc.warning(this.translationService.translateSync('nvf.paymentPending'), this.translationService.translateSync('nvf.yourPaymentIsPendingAuthorization'));
    } else {
      // Payment failed - show error message
      this.paymentError = true;
      this.paymentErrorMessage = 'label.paymentFailedMsg';
      this.toastSvc.error(this.translationService.translateSync('nvf.paymentFailed'), this.translationService.translateSync('nvf.unableToProcessPayment'));
    }
  }

  /**
   * Handle payment error
   */
  private handlePaymentError (error: {status: number}): void {
    this.isProcessingPayment = false;
    if (this.switchLoader)
      this.switchLoader(false);

    console.error('Payment processing error:', error);

    let errorMessage = this.translationService.translateSync('nvf.anErrorOccurredProcessingPayment');

    if (error.status === 409) {
      if (this.paymentStatusSetter) {
        this.paymentStatusSetter(Enums.OrderPaymentStatus.PendingOffline);
      }
      errorMessage = this.translationService.translateSync('nvf.yourPaymentIsPendingAuthorization');
      this.toastSvc.warning(this.translationService.translateSync('nvf.paymentPending'), errorMessage);
    } else {
      // Payment failed - show error message
      this.paymentError = true;
      this.paymentErrorMessage = 'label.paymentFailedMsg';

      if (error.status === 400) {
        errorMessage = this.translationService.translateSync('nvf.invalidPaymentRequest');
      } else if (error.status === 500) {
        errorMessage = this.translationService.translateSync('nvf.serverErrorOccurred');
      }

      this.toastSvc.error(this.translationService.translateSync('nvf.paymentError'), errorMessage);
    }
  }

  /**
   * Redirect to payment portal
   */
  private redirectToPaymentPortal (paymentTransaction: Models.PaymentTransactionModel): void {
    const fullUrl = `${paymentTransaction.paymentPortalURL}&t=${paymentTransaction.paymentTransactionId}`;

    // Direct redirect to payment portal
    window.location.href = fullUrl;
  }

  /**
   * Format currency value
   */
  formatCurrency (value: number | string): string {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    return numValue.toLocaleString('en-AE', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  /**
   * Get total price (prioritize quotation.totalPrice, fallback to calculated total)
   */
  getTotalPrice (): number {
    // If quotation has totalPrice, use it
    if (this.quotation?.totalPrice) {
      return this.quotation.totalPrice;
    }

    // Otherwise calculate from device and service charges
    return (
      this.totalDevicesChargesWithVAT + this.totalSubscriptionChargesWithVAT
    );
  }

  /**
   * Get total VAT
   */
  getTotalVAT (): number {
    // If quotation has totalVatPrice, use it
    if (this.quotation?.totalVatPrice) {
      return this.quotation.totalVatPrice;
    }

    // Otherwise calculate VAT from the difference between with and without VAT totals
    const deviceVAT =
      this.totalDevicesChargesWithVAT - this.totalDevicesChargesWithoutVAT;
    const serviceVAT =
      this.totalSubscriptionChargesWithVAT -
      this.totalSubscriptionChargesWithoutVAT;
    return deviceVAT + serviceVAT;
  }

  /**
   * Get total price excluding VAT for display
   */
  getTotalPriceExcludingVAT (): number {
    const totalPrice = this.getTotalPrice();
    const totalVAT = this.getTotalVAT();
    return totalPrice - totalVAT;
  }

  /**
   * Check if order is postpaid
   */
  isPostPaidOrder (): boolean {
    // Handle both string and object types for againstOrder
    const order = this.quotation?.againstOrder;
    if (typeof order === 'object' && order !== null) {
      return (order as {postPaid: boolean}).postPaid === true;
    }
    return false;
  }

  /**
   * Get Service Terms & Conditions URL based on current language
   */
  getTermsAndConditionsUrl (): string {
    const currentLang = this.translationService.getCurrentLanguage();
    const fileName = currentLang === 'ar' ? 'Terms&Conditions_ar.pdf' : 'Terms&Conditions_en.pdf';
    return `/assets/downloads/${fileName}`;
  }

  /**
   * Get Auto Pay Terms & Conditions URL based on current language
   */
  getAutoPayTermsAndConditionsUrl (): string {
    const currentLang = this.translationService.getCurrentLanguage();
    // TODO: Need to update filename once becomes available
    const fileName = currentLang === 'ar' ? 'AutoPayTerms&Conditions_ar.pdf' : 'AutoPayTerms&Conditions_en.pdf';
    return `/assets/downloads/${fileName}`;
  }

  /**
   * Redirect to the plans page using the redirect url provided
   */
  onBack (): void {
    const currentOrderId = this.orderId || this.boqService.getOrderId();
    if (this.backRedirectCallback && currentOrderId) {
      this.backRedirectCallback(currentOrderId);
    } else {
      console.warn('No redirect url provided or no order ID available');
    }
  }
}
