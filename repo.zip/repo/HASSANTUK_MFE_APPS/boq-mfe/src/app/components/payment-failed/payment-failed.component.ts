import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, finalize, takeUntil } from 'rxjs';
import { TranslateAsyncPipe, TranslationService } from 'shared-state';
import { ActivatedRoute } from '@angular/router';
import { BoqService } from '../../services/boq.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'payment-failed-component',
  standalone: true,
  imports: [
    CommonModule,
    TranslateAsyncPipe,
  ],
  templateUrl: './payment-failed.component.html'
})
export class PaymentFailedComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  orderId: string | null = null;
  isAuthenticated = false;
  requestId: string | null = null;
  accountNumber: string | null = null;
  invoiceNumber: string | null = null;
  loading = false;
  error: string | null = null;

  constructor (
    private boqService: BoqService,
    private translationService: TranslationService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {
  }

  ngOnInit (): void {
    // Initialize translation service with default language if not set
    const currentLang = this.translationService.getCurrentLanguage();
    if (!currentLang || currentLang === 'en') {
      // Set default language and load translations
      this.translationService.setLanguage('en');
    }

    this.isAuthenticated = this.boqService.getIsAuthenticated();
    this.orderId = this.boqService.getOrderId();

    // Track payment failure with Google Analytics
    this.trackPaymentFailed();

    // Load order details based on authentication status
    this.loadOrderDetails();
  }

  ngOnDestroy (): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Track payment failure with Google Analytics
   */
  private trackPaymentFailed (): void {
    try {
      // TODO: Update payment failure event
      console.log('Logging payment failure');
      // (window as any).gtag('event', 'conversion', {
      //   'send_to': '<<Tracker ID>>',
      //   'transaction_id': ''
      // });
    } catch (error) {
      console.warn('Failed to track payment failure:', error);
    }
  }

  /**
   * Load order details based on authentication status
   */
  private loadOrderDetails (): void {
    if (!this.orderId) {
      return;
    }

    this.loading = true;
    this.error = null;

    if (this.isAuthenticated) {
      // Call GET_ORDER endpoint for authenticated users
      this.getOrderDetails();
    } else {
      // Call postpaid bill endpoint for unauthenticated users
      this.callPostpaidBillEndpoint();
    }
  }

  /**
   * Call get order endpoint for authenticated users
   */
  private getOrderDetails (): void {
    this.boqService
      .getOrderDetails(this.orderId as string)
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => {
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: (res) => {
          this.loading = false;
          const requestId = (res?.data as {requestId: string}).requestId;
          if (requestId) {
            this.requestId = requestId;
          }
        },
        error: (error) => {
          this.loading = false;
          this.error = 'Failed to load order details';
          console.error('Error loading order details:', error);
        }
      });
  }

  /**
   * Call postpaid bill endpoint for unauthenticated users
   */
  private callPostpaidBillEndpoint (): void {
    this.boqService
      .getPostPaidOrderBillDetails(this.orderId as string)
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => {
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: (res) => {
          this.loading = false;
          if (res?.data) {
            this.accountNumber = (res?.data as {accountNumber: string} ).accountNumber || null;
            this.invoiceNumber = (res?.data as {invoiceNumber: string} ).invoiceNumber || null;
          }
        },
        error: (error) => {
          this.loading = false;
          this.error = 'Failed to load bill details';
          console.error('Error loading bill details:', error);
        }
      });
  }
}
