import { ErrorPageComponent } from './app.component';
import { TestBed } from '@angular/core/testing';


describe('ErrorPageComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErrorPageComponent],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(ErrorPageComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have the 'error-page-mfe' title`, () => {
    const fixture = TestBed.createComponent(ErrorPageComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('error-page-mfe');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(ErrorPageComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h1')?.textContent).toContain('Hello, error-page-mfe');
  });
});
