import { ErrorPageComponent } from './app.component';
import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '404',
    component: ErrorPageComponent
  }
];
