import { AsyncPipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {TranslateAsyncPipe} from 'shared-state';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, AsyncPipe, TranslateAsyncPipe],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class ErrorPageComponent {
  title = 'error-page-mfe';
}
