export interface Locale {
  locale: string | null;
}

export interface Role {
  id: number | null;
  role: {
    creationDate: string | null;
    lastUpdateDate: string | null;
    id: number | null;
    active: boolean;
    comments: string | null;
    name: string | null;
    displayName: string | null;
    privileges: unknown[];
  };
}

export interface User {
  locale: string | null;
  id: number | null;
  documentNumber: string | null;
  documentType: string | null;
  documentExpiryDate: string | null;
  documentStatus: string | null;
  documentStatusLabelEn: string | null;
  documentStatusLabelAr: string | null;
  email: string | null;
  firstNameEn: string | null;
  fistNameAr: string | null;
  lastNameAr: string | null;
  lastNameEn: string | null;
  gender: string | null;
  isEtisalatCustomer: boolean;
  nationality: string | null;
  primaryMobileNumber: string | null;
  etisalatLandlineNumber: string | null;
  birthDate: string | null;
  partyId: string | null;
  residentialProfileId: string | null;
  isAllowedToUpdateDoc: string | null;
  isPartyExists: boolean;
  userDocuments: unknown | null;
  subsidizedAccountId: string | null;
  type: string | null;
  roles: Role[];
}

export interface Type {
  id: number | null;
  name: string | null;
  description: string | null;
}

export interface DeviceSpec {
  locale: string | null;
  unit: number | null;
  unitPrice: string | null;
  unitSubsidizedPrice: string | null;
  unitPriceForCalc: number | null;
  vat: number | null;
  subsidizedVat: number | null;
  vatPercentage: number | null;
  totalPrice: string | null;
  totalSubsidizedPrice: string | null;
  buildingType: string | null;
  buildingLabel: string | null;
  floorNumber: string | null;
  floorLabel: string | null;
  roomType: string | null;
  roomLabel: string | null;
  deviceCode: string | null;
  deviceLabel: string | null;
  description: string | null;
  visible: boolean;
  subsidizedAccounts: string | null;
  additionalDevice: boolean;
}

export interface ServiceSpec {
  locale: string | null;
  unit: number | null;
  unitPrice: string | null;
  unitSubsidizedPrice: string | null;
  unitPriceForCalc: number | null;
  vat: number | null;
  subsidizedVat: number | null;
  vatPercentage: number | null;
  totalPrice: string | null;
  totalSubsidizedPrice: string | null;
  serviceType: string | null;
  serviceCode: string | null;
  serviceLabel: string | null;
}

export interface RequestSummary {
  locale: string | null;
  requestID: string | null;
  requestStatus: string | null;
  snagList: unknown[];
  snagListCleared: boolean;
  totalPaidAmount: string | null;
}

export interface Invoice {
  requestSummary: RequestSummary;
  paid: {
    locale: string | null;
    deviceSpecs: DeviceSpec[];
    totalDevicesPrice: number | null;
    totalSubsidizedDevicesPrice: number | null;
    serviceSpecs: ServiceSpec[];
    totalServicesPrice: number | null;
    totalBuffer: number | null;
    totalSubsidizedBuffer: number | null;
    totalPrice: number | null;
    totalSubsidizedPrice: number | null;
    totalVatPrice: number | null;
    againstOrder: string | null;
    subsidyApplied: boolean;
  };
  unpaid: {
    locale: string | null;
    deviceSpecs: DeviceSpec[];
    totalDevicesPrice: number | null;
    totalSubsidizedDevicesPrice: number | null;
    serviceSpecs: ServiceSpec[];
    totalServicesPrice: number | null;
    totalBuffer: number | null;
    totalSubsidizedBuffer: number | null;
    totalPrice: number | null;
    totalSubsidizedPrice: number | null;
    totalVatPrice: number | null;
    againstOrder: string | null;
    subsidyApplied: boolean;
  };
  totalPrice: number | null;
  isSubsidized: boolean;
  ordertype: string | null;
}

export interface orders {
  locale: string | null;
  user: User;
  id: number | null;
  accountNumber: string | null;
  address: string | null;
  requestId: string | null;
  status: string | null;
  paymentStatus: string | null;
  orderName: string | null;
  registrationDate: number | null;
  boqGenerationdate: number | null;
  paymentDate: number| null;
  warningState: boolean;
  errorState: boolean;
  type: Type | null;
  postPaidBill: unknown | null;
  subOrderInvoices: unknown | null;
  subOrders: unknown | null;
  invoice: Invoice | null;
  paymentMethodId: number | null;
  paymentDay: number | null;
  planType: string | null;
  transferFlow: string | null;
  subOrder: boolean;
}

export interface OrderObject {
  totalRecords: number;
  orders: orders[];
}


export interface UserOrderResponse {
  status: string;
  data: OrderObject;
}
