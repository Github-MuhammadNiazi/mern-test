import { TestBed } from '@angular/core/testing';
import { UserDashboardComponent } from './app.component';

describe('UserDashboardComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserDashboardComponent],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(UserDashboardComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have the 'user-dashboard-mfe' title`, () => {
    const fixture = TestBed.createComponent(UserDashboardComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('user-dashboard-mfe');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(UserDashboardComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h1')?.textContent).toContain('Hello, user-dashboard-mfe');
  });
});
