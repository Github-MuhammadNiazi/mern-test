import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';
import { ChangeDetectorRef, Component, Inject, Optional, ViewChild, inject } from '@angular/core';
import { DeviceSpec, UserOrderResponse, orders } from './user-order.interface';
import { Enums, HassantukLoaderComponent, Models, ToastService, TranslateAsyncPipe } from 'shared-state';
import { CommonModule } from '@angular/common';
import { InfiniteScrollDirective } from 'ngx-infinite-scroll';
import { Observable } from 'rxjs';
// import mockData from './mock-data.json';

@Component({
  standalone: true,
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, InfiniteScrollDirective, TranslateAsyncPipe, HassantukLoaderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})

export class UserDashboardComponent {
  @ViewChild('otpLoader') otpLoader!: HassantukLoaderComponent;
  orderData!: orders[];
  deviceSpecs!: Models.OrderModel;

  title = 'user-dashboard-mfe';
  userId!: string;
  firstName!: string;
  currentPage = 1;
  limit = 9;
  totalRecords = 0;
  loading = false;
  filteredOrderData: orders[] = [];
  private toastSvc = inject(ToastService);
  constructor (
    @Optional()
    @Inject('userOrderCallback')
    private userOrder: (id: number, pageNo: number, recordsPerPage: number) => Observable<UserOrderResponse>,
    @Optional()
    @Inject('orderId') private orderId: ((id: number) => string),
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.userId = this.route.snapshot.paramMap.get('userId') ?? '';
    const userData = localStorage.getItem('user');

    if (userData) {
      const userObject = JSON.parse(userData);
      this.firstName = userObject.firstNameEn;
    } else {
      this.toastSvc.error('Error', 'Failed to load quote data');
    }

    this.loadOrders();
  }

  navigateTogis (){
    this.router.navigate(['/home/location']);
  }
  // Map statuses into readable labels/icons
  getStatusLabel (status: string | null): string {
    switch (status) {
    case Enums.OrderStatus.SurveyInProgress: return 'In progress';
    case Enums.OrderStatus.AddVillaDocs: return 'Add Villa Documents';
    case Enums.OrderStatus.PendingAdditionalPayment: return 'Pending Payment';
    case Enums.OrderStatus.Closed: return 'Successful';
    case Enums.OrderStatus.Fail: return 'Failed';
    default: return status ? status.replace(/_/g, ' ').toLowerCase() : '';
    }
  }

  getPaymentStatusLabel (status: string | null): string {
    switch (status) {
    case Enums.OrderPaymentStatus.Successful: return 'Paid';
    case Enums.OrderPaymentStatus.Pending: return 'Pending';
    case Enums.OrderPaymentStatus.Failed: return 'Failed';
    case Enums.OrderPaymentStatus.PendingOffline: return 'Pending Offline';
    default: return status ? '' : '';
    }
  }

  getStatusIcon (status: string | null): string {
    switch (status) {
    case Enums.OrderStatus.Fail: return '../../images/svg-icons/warn-icon.svg';
    case Enums.OrderStatus.Closed: return '../../images/svg-icons/success-icon.svg';
    default: return '../../images/svg-icons/watch-icon.svg';
    }
  }

  getPaymentStatusIcon (status: string | null): string {
    switch (status) {
    case Enums.OrderPaymentStatus.Failed: return '../../images/svg-icons/warn-icon.svg';
    case Enums.OrderPaymentStatus.Successful: return '../../images/svg-icons/success-icon.svg';
    default: return '../../images/svg-icons/watch-icon.svg';
    }
  }

  getStatusBadgeClass (status: string | null): string {
    switch (status) {
    case Enums.OrderStatus.Closed: return 'status-badge status-installed';
    case Enums.OrderStatus.Fail: return 'status-badge status-pending';
    default: return 'status-badge status-waiting';
    }
  }

  getPaymentStatusBadgeClass (status: string | null): string {
    switch (status) {
    case Enums.OrderPaymentStatus.Successful: return 'status-badge status-installed';
    case Enums.OrderPaymentStatus.Failed: return 'status-badge status-pending';
    default: return 'status-badge status-waiting';
    }
  }

  smokeDetectorsCalc (detectors: DeviceSpec[] | undefined) : string {
    const totalSmokeDetectors = detectors?.filter(d => d.deviceCode === 'RPMOISMOKEDVCJCI').length || 0;
    if(totalSmokeDetectors <= 5 ) {
      return '../../images/media/product/home1.png';
    } else if(totalSmokeDetectors > 5 && totalSmokeDetectors <= 10)  {
      return '../../images/media/product/home2.png';
    } else {
      return '../../images/media/product/home3.png';
    }
  }

  onClickOrder (orderId: number | null) {
    if(orderId) {
      this.orderId(orderId);
    }
  }

  loadOrders () {
    if (this.loading) return; // avoid duplicate calls
    this.loading = true;
    this.userOrder(Number(this.userId), this.currentPage, this.limit).subscribe({
      next: (res) => {
        const newOrders = Array.isArray(res?.data?.orders) ? res.data.orders : [];
        if (!Array.isArray(this.orderData)) {
          this.orderData = [];
        }
        this.totalRecords = res.data.totalRecords; // backend should return total count
        this.orderData = [...this.orderData, ...newOrders];
        this.filteredOrderData = [...this.orderData]; // Initialize filtered data
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('API error:', err);
        this.toastSvc.error('Error', 'Failed to load order data');
      },
      complete: () => {
        this.loading = false;
        this.otpLoader?.hide();
      },
    });
  }

  onScroll () {
    this.otpLoader?.show();
    // Load more only if not reached total
    if (this.orderData.length < this.totalRecords) {
      this.currentPage++;
      this.loadOrders();
    }
  }

  onSearch (event: KeyboardEvent) {
    const searchValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    // If searchValue is empty, reset filteredOrderData to original orderData
    if (!searchValue) {
      this.filteredOrderData = [...this.orderData];
    } else {
      this.filteredOrderData = this.orderData.filter((order) =>
        (order.accountNumber ? order.accountNumber.toString().toLowerCase() : '').includes(searchValue)
      );
    }
  }
}
