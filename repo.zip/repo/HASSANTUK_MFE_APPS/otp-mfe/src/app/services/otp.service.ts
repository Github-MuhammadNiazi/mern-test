import {HttpClient, HttpParams} from '@angular/common/http';
import {Inject, Injectable, inject} from '@angular/core';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import {Observable, delay, map, of, throwError} from 'rxjs';
import {ApiCfg} from '../config/api-config.token';

interface OtpResponse {
  status: string;
  data?: unknown;
  code?: string;
}

@Injectable({providedIn: 'root'})
export class OtpService {
  #http = inject(HttpClient);

  constructor (@Inject('APP_CFG') private cfg: ApiCfg) {
  }

  sendOtp (accountNumber: string, locale?: string): Observable<OtpResponse> {
    // const mockResponse: OtpResponse = {
    //   status: 'OK',
    //   data: 'OTP sent successfully',
    //   code: 'OTP_SENT',
    // };
    //
    // return of(mockResponse).pipe(delay(1000));

    // TODO: uncomment for actual api call
    const params = new HttpParams().set('accountNumber', accountNumber).set('locale', locale ?? 'en');

    return this.#http
      .get<OtpResponse>(this.cfg.otpSendUrl, {params});
  }

  verifyOtp (accountNumber: string, otp: string): Observable<OtpResponse> {

    // if (otp === '1234') {
    //   const mockResponse: OtpResponse = {
    //     status: 'OK',
    //     data: 'OTP verified successfully',
    //     code: 'VERIFIED',
    //   };
    //   return of(mockResponse).pipe(delay(1000)); // Simulate network delay
    // } else {
    //   const mockErrorResponse: OtpResponse = {
    //     status: 'ERROR',
    //     data: 'Invalid OTP',
    //     code: 'INVALID_OTP',
    //   };
    //   return throwError(() => mockErrorResponse).pipe(delay(1000));
    // }
    // TODO: uncomment for actual api call
    const params = new HttpParams()
      .set('accountNumber', accountNumber)
      .set('otp', otp);

    return this.#http.get<OtpResponse>(this.cfg.otpVerifyUrl, {params});
  }

  // Send OTP For Login: email
  sendOtpLogin (email: string, locale?: string) {
    const body: Record<string, string> = { email };
    const url = this.cfg.otpSendLoginUrl ?? this.cfg.otpSendUrl; // fallback if not provided
    body['locale'] = locale ?? 'en';

    return this.#http.post<OtpResponse>(url, body);
  }

  // Verify For Login: email + otp (login)
  verifyOtpLogin (email: string, otp: string, locale?: string): Observable<OtpResponse> {
    const url = this.cfg.otpVerifyLoginUrl ?? this.cfg.otpVerifyUrl; // fallback if not provided
    const lang = locale ?? 'en';
    const body = { email, otp };
    const options = {
      params: { lang },
      withCredentials: true
    };

    return this.#http.post<OtpResponse>(url, body, options);
  }
}
