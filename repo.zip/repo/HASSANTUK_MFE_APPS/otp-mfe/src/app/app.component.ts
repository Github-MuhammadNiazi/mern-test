import {
  AfterViewInit,
  Component,
  ElementRef,
  Inject,
  OnDestroy,
  OnInit,
  Optional,
  QueryList,
  Signal,
  ViewChild,
  ViewChildren,
  WritableSignal,
  afterNextRender,
  computed,
  inject,
  signal,
} from '@angular/core';
import {CommonModule, NgIf} from '@angular/common';
import {HassantukLoaderComponent, TranslateAsyncPipe, TranslationService} from 'shared-state';
import {Subject, finalize, takeUntil} from 'rxjs';
import {FormsModule} from '@angular/forms';
import {HttpErrorResponse} from '@angular/common/http';
import {OtpService} from './services/otp.service';
import Swiper from 'swiper';
import {toSignal} from '@angular/core/rxjs-interop';


type Dir = 'rtl' | 'ltr';

interface OtpError {
  message: string;
  code?: string;
  timestamp: number;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, NgIf, TranslateAsyncPipe, HassantukLoaderComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [OtpService]
})
export class OtpComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChildren('otpInput') otpInputs!: QueryList<ElementRef<HTMLInputElement>>;
  @ViewChild('otpLoader') otpLoader!: HassantukLoaderComponent;
  loading = signal(false);
  error = signal<OtpError | null>(null);
  resendWait = signal(0);
  private swiper!: Swiper;
  // 6 digits for both flows
  digits: WritableSignal<string>[] = Array.from({length: 6}, () => signal(''));
  // Enable Continue only when all 6 inputs have 1 digit each (and not loading)
  readonly canSubmit = computed(
    () => this.digits.every(d => d().trim().length === 1) && !this.loading()
  );
  // Check if OTP is complete for auto-submit (optional feature)
  readonly isComplete = computed(
    () => this.digits.every(d => d().trim().length === 1)
  );
  private translationService: TranslationService = inject(TranslationService);
  // Translation Labels
  readonly labelOtpNotSent: Signal<string> = toSignal(
    this.translationService.translate$('message.otpNotSent'),
    {initialValue: ''}
  );
  readonly labelOtpSendingFailed: Signal<string> = toSignal(
    this.translationService.translate$('message.otpSendingFailed'),
    {initialValue: ''}
  );
  readonly labelOtpNotVerified: Signal<string> = toSignal(
    this.translationService.translate$('message.otpNotVerified'),
    {initialValue: ''}
  );
  readonly labelOtpNotVerificationFailed: Signal<string> = toSignal(
    this.translationService.translate$('message.otpNotVerificationFailed'),
    {initialValue: ''}
  );
  private destroy$ = new Subject<void>();
  private sentOnce = false;
  private resendTimerId: ReturnType<typeof setInterval> | null = null;
  private autoVerifyIfComplete (): void {
    if (this.isComplete() && !this.loading()) {
      Promise.resolve().then(() => this.verify());
    }
  }

  constructor (
    private api: OtpService,
    @Inject('otpSendEnabled') private sendEnabled: boolean,               // true=msisdn flow, false=login
    @Optional() @Inject('accountNumber') private accountNumber?: string, // MSISDN (signup)
    @Optional() @Inject('loginEmail') private loginEmail?: string,     // Email (login)
    @Optional() @Inject('otpVerifiedCallback') private otpVerifiedCallback?: (otp: string, isSignup: boolean) => void,
    @Optional() @Inject('otpFailedCallback') private otpFailedCallback?: (reason: string) => void
  ) {
    // Fire once after the initial render — avoids rare federation timing races
    afterNextRender(() => {
      if (this.hasIdentifier() && !this.sentOnce) {
        this.sentOnce = true;
        this.send();
      }
    });
  }

  ngOnInit () {
    // (redundant with afterNextRender). Safe due to sentOnce:
    if (this.hasIdentifier() && !this.sentOnce) {
      this.sentOnce = true;
      this.send();
    }
  }

  ngAfterViewInit (): void {
    this.initializeSwiper();

    this.translationService.language$
      .pipe(takeUntil(this.destroy$))
      .subscribe((lang) => {
        const dir: Dir = lang === 'ar' ? 'rtl' : 'ltr';
        const el: HTMLElement | null = document.querySelector('.signup-slider');
        if (el) el.setAttribute('dir', dir);

        const sw = this.swiper;
        if (!sw) return;
        requestAnimationFrame(() => {
          try {
            if ('changeLanguageDirection' in (sw as object)) {
              sw.changeLanguageDirection(dir);
              sw.update();
            } else {
              sw.destroy(true, true);
              this.initializeSwiper();
            }
          } catch (e) {
            console.warn('[Swiper] direction switch failed, re-init:', e);
            sw.destroy(true, true);
            this.initializeSwiper();
          }
        });
      });
  }

  ngOnDestroy () {
    this.destroy$.next();
    this.destroy$.complete();
    this.clearResendTimer();
  }

  initializeSwiper () {
    this.swiper = new Swiper(".signup-slider", {
      loop: true,
      slidesPerView: 1,
      spaceBetween: 0,
      pagination: {
        el: ".signup-slider .swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".signup-slider .swiper-button-next",
        prevEl: ".signup-slider .swiper-button-prev",
      },
      autoplay: {
        delay: 3000, // Slide will change every 3 seconds
        disableOnInteraction: false, // Autoplay won't stop after user interaction
      },
    });
  }

  /** Helpers */
  private hasIdentifier (): boolean {
    return this.sendEnabled ? !!this.accountNumber : !!this.loginEmail;
  }

  private identifierLabel (): 'accountNumber' | 'loginEmail' {
    return this.sendEnabled ? 'accountNumber' : 'loginEmail';
  }

  private get otpValue (): string {
    return this.digits.map(d => d()).join('');
  }

  private clearResendTimer (): void {
    if (this.resendTimerId) {
      globalThis.clearInterval(this.resendTimerId);
      this.resendTimerId = null;
    }
  }

  private createError (message: string, code?: string): OtpError {
    return {
      message,
      code,
      timestamp: Date.now()
    };
  }

  private focusInput (index: number): void {
    if (this.otpInputs && this.otpInputs.toArray()[index]) {
      setTimeout(() => {
        this.otpInputs.toArray()[index].nativeElement.focus();
      });
    }
  }

  private clearAllDigits (): void {
    this.digits.forEach(digit => digit.set(''));
  }

  /** Input Handlers */
  onDigitInput (ev: Event, idx: number): void {
    const input = ev.target as HTMLInputElement;
    const val = input.value.replace(/[^0-9]/g, '').slice(0, 1);

    this.digits[idx].set(val);
    this.clearError();

    // Auto-focus next input
    if (val && idx < this.digits.length - 1) {
      this.focusInput(idx + 1);
    }
    // auto-submit if all boxes filled
    this.autoVerifyIfComplete();
  }

  onKeyDown (event: KeyboardEvent, index: number): void {
    const input = event.target as HTMLInputElement;

    // Handle backspace/delete
    if (event.key === 'Backspace' || event.key === 'Delete') {
      if (!input.value && index > 0) {
        event.preventDefault();
        this.focusInput(index - 1);
        this.digits[index - 1].set('');
      } else if (input.value) {
        this.digits[index].set('');
      }
    }
    // Handle arrow keys for navigation
    else if (event.key === 'ArrowLeft' && index > 0) {
      event.preventDefault();
      this.focusInput(index - 1);
    }
    // Move Right
    else if (event.key === 'ArrowRight' && index < this.digits.length - 1) {
      event.preventDefault();
      this.focusInput(index + 1);
    }
    // Handle Home/End keys
    else if (event.key === 'Home') {
      event.preventDefault();
      this.focusInput(0);
    }
    else if (event.key === 'End') {
      event.preventDefault();
      this.focusInput(this.digits.length - 1);
    }
    // Prevent non-numeric input
    else if (!/[0-9]/.test(event.key) &&
      !['Tab', 'Shift', 'Control', 'Alt', 'Meta'].includes(event.key) &&
      !event.ctrlKey && !event.metaKey) {
      event.preventDefault();
    }
  }

  onPaste (event: ClipboardEvent): void {
    event.preventDefault();
    const pasteData = event.clipboardData?.getData('text') || '';
    const digits = pasteData.replace(/[^0-9]/g, '').slice(0, this.digits.length);

    if (digits.length === 0) return;

    // Clear all existing digits first
    this.clearAllDigits();
    this.clearError();

    // Fill digits from the beginning
    digits.split('').forEach((digit, i) => {
      if (i < this.digits.length) {
        this.digits[i].set(digit);
      }
    });

    // Focus on the next empty input or last filled input
    const nextEmptyIndex = Math.min(digits.length, this.digits.length - 1);
    this.focusInput(nextEmptyIndex);
    // auto-submit if all boxes filled
    this.autoVerifyIfComplete();
  }

  onFocus (event: FocusEvent): void {
    const input = event.target as HTMLInputElement;
    // Select all text on focus for easier replacement
    setTimeout(() => input.select());
  }

  private clearError (): void {
    if (this.error()) {
      this.error.set(null);
    }
  }

  /** Send (initial + resend) */
  send (): void {
    if (this.loading()) return;
    if (!this.hasIdentifier()) {
      const which = this.identifierLabel();
      this.error.set(this.createError(`Missing ${which} for sending OTP`, 'MISSING_IDENTIFIER'));
      console.error('[OTP] send() called without', which);
      return;
    }

    this.loading.set(true);
    this.clearError();
    const locale = this.translationService.getCurrentLanguage();
    const req$ = this.sendEnabled
      ? this.api.sendOtp(this.accountNumber!, locale)     // MSISDN flow (GET)
      : this.api.sendOtpLogin(this.loginEmail!, locale);  // Login flow (POST)

    req$.pipe(
      finalize(() => this.loading.set(false)),
      takeUntil(this.destroy$)
    ).subscribe({
      next: (res) => {
        if (res.status !== 'OK') {
          this.error.set(this.createError(this.labelOtpNotSent(), res.code));
          console.warn('sendOtp failure:', res);
          return;
        }

        this.startResendTimer();
        // Clear any existing OTP digits on successful send
        this.clearAllDigits();
        // Focus on first input
        this.focusInput(0);
      },

      error: (err: HttpErrorResponse) => {
        console.error('sendOtp HTTP error:', err);
        const errorMessage = `${this.labelOtpSendingFailed()} (${(err?.error?.status ?? err.status) || 'Error'})`;
        this.error.set(this.createError(errorMessage, 'HTTP_ERROR'));
      }
    });
  }

  onResendClick (evt: Event): void {
    evt.preventDefault();
    if (this.resendWait() > 0 || this.loading()) return;
    this.send();
  }

  /** Verify on submit */
  verify (): void {
    if (!this.canSubmit()) return;

    if (!this.hasIdentifier()) {
      const which = this.identifierLabel();
      this.error.set(this.createError(`Missing ${which} for verifying OTP`, 'MISSING_IDENTIFIER'));
      console.error('[OTP] verify() called without', which);

      return;
    }

    const otp = this.otpValue;
    if (otp.length !== this.digits.length) {
      this.error.set(this.createError('Please enter all digits', 'INCOMPLETE_OTP'));

      return;
    }

    this.otpLoader.show();
    this.loading.set(true);
    this.clearError();

    const locale = this.translationService.getCurrentLanguage();
    const req$ = this.sendEnabled
      ? this.api.verifyOtp(this.accountNumber!, otp)     // MSISDN + OTP
      : this.api.verifyOtpLogin(this.loginEmail!, otp, locale);  // Email + OTP

    req$.pipe(
      finalize(() => this.loading.set(false)),
      takeUntil(this.destroy$)
    ).subscribe({
      next: (res) => {
        if (res.status === 'OK') {
          this.clearResendTimer();
          this.otpVerifiedCallback?.(otp, this.sendEnabled);
        } else {
          this.error.set(this.createError(this.labelOtpNotVerified(), res.code ?? 'WRONG_OTP'));
          this.otpFailedCallback?.(res.code ?? 'WRONG_OTP');

          // Clear OTP on verification failure and focus first input
          this.clearAllDigits();
          this.focusInput(0);
          this.otpLoader.hide();
        }
      },

      error: (err: HttpErrorResponse) => {
        console.error('verifyOtp HTTP error:', err);
        const errorMessage = `${this.labelOtpNotVerificationFailed()} (${(err?.error?.status ?? err.status) || 'Error'})`;
        this.error.set(this.createError(errorMessage, 'HTTP_ERROR'));
        this.otpFailedCallback?.('HTTP_ERROR');

        // Clear OTP on HTTP error and focus first input
        this.clearAllDigits();
        this.focusInput(0);
        this.otpLoader.hide();
      }
    });
  }

  /** Timer */
  private startResendTimer (): void {
    this.clearResendTimer();
    this.resendWait.set(30);

    this.resendTimerId = globalThis.setInterval(() => {
      const currentWait = this.resendWait();
      if (currentWait <= 1) {
        this.clearResendTimer();
        this.resendWait.set(0);
      } else {
        this.resendWait.set(currentWait - 1);
      }
    }, 1000);
  }

}

