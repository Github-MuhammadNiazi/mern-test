import { Routes } from '@angular/router';
import { OtpComponent } from './app.component';

export const routes: Routes = [
  { path: '', component: OtpComponent },
];
