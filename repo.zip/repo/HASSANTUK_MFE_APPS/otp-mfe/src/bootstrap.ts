import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { OtpComponent } from './app/app.component';

bootstrapApplication(OtpComponent, appConfig)
  .catch((err) => console.error(err));
