declare module 'dropzone/dist/dropzone' {
  import Dropzone from 'dropzone';
  export default Dropzone;
}
