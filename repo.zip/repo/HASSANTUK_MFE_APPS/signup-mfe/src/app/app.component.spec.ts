import { TestBed } from '@angular/core/testing';
import { HeaderComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HeaderComponent],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(HeaderComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

<<<<<<<< HEAD:signup-mfe/src/app/app.component.spec.ts
  it(`should have the 'signup-mfe' title`, () => {
    const fixture = TestBed.createComponent(AppComponent);
========
  it(`should have the 'header-mfe' title`, () => {
    const fixture = TestBed.createComponent(HeaderComponent);
>>>>>>>> develop:header-mfe/src/app/app.component.spec.ts
    const app = fixture.componentInstance;
    expect(app.title).toEqual('signup-mfe');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(HeaderComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h1')?.textContent).toContain('Hello, signup-mfe');
  });
});
