import { Injectable } from '@angular/core';
import AirDatepicker, { AirDatepickerLocale } from 'air-datepicker';

@Injectable({
  providedIn: 'root',
})
export class DatepickerService {
  private enLocale = {
    days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    daysShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    daysMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
    months: [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December',
    ],
    monthsShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    today: 'Today',
    clear: 'Clear',
    dateFormat: 'dd/MM/yyyy',
    timeFormat: 'HH:mm',
    firstDay: 0,
  };

  initializeDatepicker(
    selector: string,
    formControl: any,
    position: 'top right' | 'bottom right' | 'top left' | 'bottom left' = 'top right'
  ): void {
    new AirDatepicker(selector, {
      locale: this.enLocale as Partial<AirDatepickerLocale>,
      autoClose: true,
      dateFormat: 'dd/MM/yyyy',
      position,
      onSelect: ({ formattedDate }) => {
        formControl.setValue(formattedDate);
        formControl.markAsTouched();
      },
    });
  }
}