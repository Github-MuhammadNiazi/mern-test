import { Routes } from '@angular/router';
// import { SignupComponent } from './app.component';
import { SignupMainComponent } from './pages/signup/signup.component';

export const routes: Routes = [
    { path: '', component: SignupMainComponent }
];
