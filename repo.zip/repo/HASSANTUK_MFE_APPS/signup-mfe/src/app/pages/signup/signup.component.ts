import { AfterViewInit, Component } from '@angular/core';
import { Autoplay, Pagination } from 'swiper/modules';
import { Models, TranslateAsyncPipe } from "shared-state";
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DeveloperComponent } from "../developer/developer.component";
import { IndividualComponent } from "../individual/individual.component";
import { NsLookupItem } from '../../core/models/NsLookupModel';
import Swiper from 'swiper';
import { docTypeModel } from '../../core/models/docTypeModel';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, DeveloperComponent, IndividualComponent, TranslateAsyncPipe],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.scss'
})
export class SignupMainComponent implements AfterViewInit {
  title = 'signup-mfe';
  showIndividualForm = false;
  showDeveloperForm = false;
  isEtisalatCustomer = false;
  userData: Models.UserModel | undefined;
  currentFormType = '';
  docTypes: docTypeModel[] = [];
  nationality: NsLookupItem[] = [];
  //add type later, not finalised what data received form host
  dataFromHost: unknown;

  constructor (private route: ActivatedRoute) {
    this.route.data.subscribe(data => {
      if (data) {
        this.docTypes = data['docType'];
        this.nationality = data['nationality'];

        this.userData = data['userData'].user;
        this.isEtisalatCustomer = data['userData'].isEtisalatUser;
        console.log('userData', data['userData']);
        this.setFormType(data["userData"].formType);
      }
    });

    Swiper.use([Pagination, Autoplay]);
  }

  ngAfterViewInit (): void {
    this.initializeSwiper();
  }

  initializeSwiper () {
    new Swiper(".signup-slider", {
      loop: true,
      slidesPerView: 1,
      spaceBetween: 0,
      pagination: {
        el: ".signup-slider .swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".signup-slider .swiper-button-next",
        prevEl: ".signup-slider .swiper-button-prev",
      },
      autoplay: {
        delay: 3000, // Slide will change every 3 seconds
        disableOnInteraction: false, // Autoplay won't stop after user interaction
      },
    });
  }

  getImageURL (path: string): string {
    // return new URL(`./${path}`, import.meta.url).toString();
    return `${path}`;
  }

  setFormType (formType: string) {
    this.currentFormType = formType;
    // Reset all form visibility flags
    this.showIndividualForm = false;
    this.showDeveloperForm = false;
    // Dynamically enable the correct form based on the form type
    switch (formType) {
    case 'individual':
      this.showIndividualForm = true;
      break;
    case 'developer':
      this.showDeveloperForm = true;
      break;
    default:
      console.warn(`Unknown form type: ${formType}`);
    }
  }
}
