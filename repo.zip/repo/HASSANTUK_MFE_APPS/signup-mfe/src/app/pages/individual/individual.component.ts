import {
  AfterViewInit,
  Component,
  ElementRef,
  Inject,
  Input,
  OnInit,
  Optional,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

import { HassantukLoaderComponent, Models, TranslateAsyncPipe } from 'shared-state';
import { Observable, catchError, debounceTime, distinctUntilChanged, filter, of, switchMap } from 'rxjs';
import { CommonModule } from '@angular/common';
import { DatepickerService } from '../../services/air-datepicker.service';
import Dropzone from 'dropzone/dist/dropzone';
import { EidResponse } from '../../core/interfaces/eid-validation-response.interface';
import { EmailValidationResponse } from '../../core/interfaces/email-validation-response.interface';
import { NsLookupItem } from '../../core/models/NsLookupModel';
import { PrefilledData } from '../../core/interfaces/prefilled-customer-data.interface';
import { UploadedItem } from '../../core/interfaces/upload-item.interface';
import { futureDateValidator } from '../../core/validators/future-date.validator';
import { minimumAgeValidator } from '../../core/validators/check-18yo.validator';

@Component({
  selector: 'app-individual',
  imports: [CommonModule, ReactiveFormsModule, TranslateAsyncPipe, HassantukLoaderComponent],
  templateUrl: './individual.component.html',
  styleUrl: './individual.component.scss',
})


export class IndividualComponent implements AfterViewInit, OnInit {
  form: FormGroup;
  @Input() nationality: NsLookupItem[] = [];
  @Input() isEtisalatCustomer!: boolean;
  @Input() userData: Models.UserModel | undefined;
  uploadedFiles: UploadedItem[] = [];
  dz!: InstanceType<typeof Dropzone>;
  private replacingIndex: number | null = null; // <— key
  emiratesIdMaxLength = 15;
  emiratesIdMaxLengthReached = false;
  isEidValid = false;
  isEmailValid: boolean | null = null;
  prefilledCustomerData!: PrefilledData;

  @ViewChild('userDocuments') userDocuments!: ElementRef<HTMLInputElement>;
  @ViewChild('dropzoneRef') dropzoneRef!: ElementRef<HTMLDivElement>;
  @ViewChild('defaultPreview') defaultPreview!: ElementRef<HTMLDivElement>;
  @ViewChild('signupLoader') signupLoader!: HassantukLoaderComponent;


  constructor (private fb: FormBuilder,
    @Optional()
    @Inject('registerUser')
    private registerUser: (data: Models.UserModel) => Observable<Models.UserModel>,
    @Optional()
    @Inject('validateEid')
    private validateEid: (data: number) => Observable<EidResponse>,
    @Optional()
    @Inject('validateEmail')
    private validateEmail: (email: string) => Observable<EmailValidationResponse>,
    private datepickerService: DatepickerService,
    @Optional()
    @Inject('onSignupSuccessCallback')
    private onSignupSuccessCallback: () => void,
  ) {
    this.form = this.fb.group({
      firstNameEn: ['', Validators.required],
      lastNameEn: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      userDocuments: [null, Validators.required],
      documentNumber: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
      nationality: ['', Validators.required],
      gender: ['', Validators.required],
      birthDate: ['', [Validators.required]],
      documentExpiryDate: ['', [Validators.required]],
    });

    if(!this.isEtisalatCustomer) {
      this.setupEmailValidation();
    }

    // Dynamically update the validator based on userExists
    const birthDateControl = this.form.get('birthDate');
    const documentExpiryDateControl = this.form.get('documentExpiryDate');
    if (!this.isEtisalatCustomer) {
      birthDateControl?.setValidators([Validators.required, minimumAgeValidator(18)]);
      documentExpiryDateControl?.setValidators([Validators.required, futureDateValidator()]);
    } else {
      birthDateControl?.clearValidators();
      documentExpiryDateControl?.clearAsyncValidators();
    }
  }

  ngOnInit (): void {
    // Prefill data if the user is an Etisalat user
    if (this.isEtisalatCustomer) {
      this.prefillFormData();
      this.disableFormFields();
      const userNationality = this.userData?.nationality;
      if (userNationality) {
        const exists = this.nationality.some(
          item => item.Nationality === userNationality
        );
        if (!exists) {
          this.nationality = [
            ...this.nationality,
            {
              Nationality: userNationality,
              EIDA_READER_CODE: '',
              PASSPORT_READER_CODE: '',
              SEGMENT_VALUE_ID: -1
            }
          ];
        }

        // Preselect
        this.form.get('nationality')?.setValue(userNationality);
      }
    }
  }

  setupEmailValidation (): void {
    this.form.get('email')?.valueChanges
      .pipe(
        debounceTime(500), // wait longer before checking
        distinctUntilChanged(),
        filter(() => !!this.form.get('email')?.valid), // force to boolean
        switchMap((email: string) =>
          this.validateEmail(email).pipe(
            catchError(err => {
              console.error('Email check failed:', err);
              this.form.get('email')?.setErrors({ emailCheckFailed: true });
              return of(null);
            })
          )
        )
      )
      .subscribe((response: EmailValidationResponse | null) => {
        if (!response) return;
        if (response.status === 'NO_CONTENT') {
          this.isEmailValid = true;
          this.form.get('email')?.setErrors(null);
        } else {
          this.isEmailValid = false;
          this.form.get('email')?.setErrors({ emailExists: true });
        }
      });
  }

  formatDate (timestamp: number | string): string {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  }

  prefillFormData () {
    // Example prefilled data for Etisalat users
    this.prefilledCustomerData = {
      firstNameEn: this.userData?.firstNameEn,
      lastNameEn: this.userData?.lastNameEn,
      email: this.userData?.email,
      documentId: this.userData?.documentNumber,
      documentNumber: this.userData?.documentNumber,
      nationality: this.userData?.nationality,
      gender: this.userData?.gender,
      birthDate: this.userData?.birthDate,
      documentExpiryDate: this.formatDate(Number(this.userData?.documentExpiryDate)),
      fistNameAr: "",
      lastNameAr: "",
      userDocuments: [],
      userRoles: [],
      documentType: 'EMIRATES_ID',
      partyId: this.userData?.partyId,
      residentialProfileId: this.userData?.residentialProfileId,
      primaryMobileNumber: this.userData?.primaryMobileNumber,
      locale: localStorage.getItem('language') || 'en'
    };

    this.form.patchValue(this.prefilledCustomerData);
    return this.prefilledCustomerData;
  }

  onDocumentIdInput (event: Event) {
    const input = event.target as HTMLInputElement;
    const documentId = input.value;

    // Reset validation state if input changes
    this.isEidValid = false;

    if (documentId.length === this.emiratesIdMaxLength) {
      console.log('Reached 15 digits - validating', documentId);
      this.validateEid(Number(documentId)).subscribe({
        next: (response: EidResponse) => {
          if (response.status === 'OK' && response.data && response.accepted) {
            console.log('response', response?.status);
            this.isEidValid = true;
          } else {
            console.error('Validation failed:', response.message);
            this.isEidValid = false;
          }
        },
        error: (error) => {
          console.log('error', error);
          this.isEidValid = false;
        },
        complete: () => {
          console.log('Validation process completed.');
          // Handle completion logic here if needed
        }
      });
    } else {
      console.log('Not yet 15 digits');
    }
  }

  disableFormFields (): void {
    // Disable specific form controls
    this.form.get('firstNameEn')?.disable();
    this.form.get('lastNameEn')?.disable();
    // this.form.get('email')?.disable();
    this.form.get('documentNumber')?.disable();
    this.form.get('nationality')?.disable();
    this.form.get('gender')?.disable();
    this.form.get('birthDate')?.disable();
    this.form.get('documentExpiryDate')?.disable();
  }

  ngAfterViewInit (): void {
    this.datepickerService.initializeDatepicker(
      '#birthDate',
      this.form.get('birthDate')
    );
    this.datepickerService.initializeDatepicker(
      '#documentExpiryDate',
      this.form.get('documentExpiryDate')
    );


    Dropzone.autoDiscover = false;

    this.dz = new Dropzone(this.dropzoneRef.nativeElement, {
      url: '/noop',
      autoProcessQueue: false,
      clickable: [this.dropzoneRef.nativeElement, this.defaultPreview.nativeElement],
      previewsContainer: undefined,
      previewTemplate: '<div></div>',
      dictDefaultMessage: '',
      maxFiles: 2,
      acceptedFiles: '.jpg,.jpeg,.png,.pdf',
    });

    this.dz.on('addedfile', (file: Dropzone.DropzoneFile) => {
      this.convertToBase64(file, (base64) => {
        const rawBase64 = base64.split(',')[1]; // keep only raw
        this.uploadedFiles.push({
          file,
          name: file.name,
          base64: rawBase64,
        });
        this.updateForm();
      });
    });
  }

  private convertToBase64 (file: File, cb: (b64: string) => void): void {
    const reader = new FileReader();
    reader.onload = () => cb(reader.result as string);
    reader.readAsDataURL(file);
  }

  private updateForm (): void {
    const files = this.uploadedFiles.map(f => f.file as File);
    const ctrl = this.form.get('userDocuments');
    ctrl?.setValue(files.length ? files : null);
    ctrl?.markAsTouched();
  }

  deleteFile (index: number): void {
    const fileToDelete = this.uploadedFiles[index]?.file;
    if (fileToDelete) {
      this.dz.removeFile(fileToDelete); // Remove the file from Dropzone
    }
    this.uploadedFiles.splice(index, 1); // Remove the file from the array
    this.updateForm(); // Update the form value
  }

  onManualFileSelect (event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files?.length) {
      const file = input.files[0];
      const base64Promise = new Promise<string>((resolve) => {
        this.convertToBase64(file, resolve);
      });

      base64Promise.then((base64) => {
        const rawBase64 = base64.split(',')[1];
        const newUploadedItem: UploadedItem = {
          file: file as Dropzone.DropzoneFile,
          name: file.name,
          base64: rawBase64,
        };

        if (this.replacingIndex !== null) {
          // Replacing existing file
          const oldFile = this.uploadedFiles[this.replacingIndex]?.file;
          if (oldFile) {
            this.dz.removeFile(oldFile); // Remove old from Dropzone
          }

          this.uploadedFiles[this.replacingIndex] = newUploadedItem;

          this.replacingIndex = null;
        } else {
          // Normal add
          this.uploadedFiles.push(newUploadedItem);
          this.dz.addFile(file as Dropzone.DropzoneFile); // only when adding
        }

        this.updateForm();
      });

      input.value = ''; // allow reselecting same file
    }
  }

  onKeyDown (event: KeyboardEvent, index: number) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      this.replaceFile(index);
    }
  }

  replaceFile (index: number): void {
    // Remove the old file from Dropzone and the uploadedFiles array
    const oldFile = this.uploadedFiles[index]?.file;
    if (oldFile) {
      this.dz.removeFile(oldFile); // Remove the old file from Dropzone
    }

    // Mark the index being replaced
    this.replacingIndex = index;

    // Trigger file selection dialog
    this.userDocuments.nativeElement.value = ''; // Reset input
    this.userDocuments.nativeElement.click();
  }

  onSubmit (): void {
    if (
      (!this.isEtisalatCustomer && (this.form.invalid || !this.isEidValid || !this.isEmailValid)) ||
      (this.isEtisalatCustomer && !this.isEmailValid))
    {
      this.form.markAllAsTouched();
      return;
    }
    // transform uploaded files into correct structure
    const userDocuments = this.uploadedFiles.map(f => {
      const ext = f.name.split('.').pop()?.toLowerCase() || 'file';
      return {
        document: `${ext},${f.base64}`,  // extension + base64
        documentType: 'EMIRATES_ID'      // same type for all
      };
    });

    const payload = {
      ...this.form.value,
      documentNumber: this.form.get('documentNumber')?.value,
      documentId: this.form.get('documentNumber')?.value,
      locale: localStorage.getItem('language') || 'en',
      primaryMobileNumber: this.userData?.primaryMobileNumber,
      userRoles: [],
      userDocuments,
      fistNameAr: "",
      lastNameAr: "",
      documentType: "EMIRATES_ID"
    };

    if(this.isEtisalatCustomer) {
      this.prefilledCustomerData.birthDate = '';
      this.prefilledCustomerData.documentExpiryDate = this.userData?.documentExpiryDate;
      this.prefilledCustomerData.documentNumber = '';
      this.prefilledCustomerData.email = this.form.get('email')?.value;
    }

    const regData = this.isEtisalatCustomer ? this.prefilledCustomerData : payload;
    console.log('regData', regData);
    this.submit(regData);
  }

  submit (payload: Models.UserModel) {
    this.signupLoader.show();
    this.registerUser(payload).subscribe({
      next: (res) =>  {
        console.log('res', res);
        this.onSignupSuccessCallback();
      },
      error: (err) => console.error('API error:', err),
      complete: () => {
        console.log('Request completed.');
        this.signupLoader.hide();
      },
    });
  }

}
