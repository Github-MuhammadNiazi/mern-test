import { AfterViewInit, Component, Inject, Input, Optional } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Models, TranslateAsyncPipe } from 'shared-state';
import { Observable, catchError, debounceTime, distinctUntilChanged, filter, of, switchMap } from 'rxjs';
import { CommonModule } from '@angular/common';
import { DatepickerService } from '../../services/air-datepicker.service';
import { EmailValidationResponse } from '../../core/interfaces/email-validation-response.interface';
import { PartyDetailsResponse } from '../../core/models/party-details-response.model';
import { docTypeModel } from '../../core/models/docTypeModel';

@Component({
  selector: 'app-developer',
  imports: [CommonModule, ReactiveFormsModule, TranslateAsyncPipe],
  templateUrl: './developer.component.html',
  styleUrl: './developer.component.scss'
})
export class DeveloperComponent implements AfterViewInit {
  @Input() docTypes: docTypeModel[] = [];
  @Input() userData: Models.UserModel | undefined;
  form: FormGroup;
  businessForm: FormGroup;
  emailForm: FormGroup;
  isBusinessDetailTab = false;
  isAccountTab = false;
  isPartyIdTab = true;
  businessInfo: PartyDetailsResponse = {
    fullName: '',
    documentExpiryDate: '',
    createdDate: ''
  };

  screenOrder = ['partyIdTab', 'businessDetailTab', 'accountTab'];
  currentScreenIndex = 0; // Tracks the current screen index
  developerData: Models.UserModel | undefined;
  isEmailValid: boolean | null = null;

  constructor (
  private datepickerService: DatepickerService,
  private fb: FormBuilder,
  @Optional() @Inject('registerDeveloper') private registerDeveloper: (data: Models.UserModel) => Observable<{data: PartyDetailsResponse}>,

  @Optional() @Inject('verifyDeveloperProfile') private verifyDeveloperProfile: (data: Models.UserModel) => Observable<{data: PartyDetailsResponse}>,

  @Optional()
  @Inject('validateEmail')
  private validateEmail: (email: string) => Observable<EmailValidationResponse>,
  @Optional()
  @Inject('onSignupSuccessCallback')
  private onSignupSuccessCallback: () => void
  ) {
    this.form = this.fb.group({
      documentCode: ['', Validators.required],
      documentId: ['', Validators.required],
      partyId: ['', [Validators.required, Validators.pattern(/^[0-9]+$/)]]
    });

    this.businessForm = this.fb.group({
      businessName: [{ value: '', disabled: true }],
      businessEstablishmentDate: [{ value: '', disabled: true }],
      documentExpiryDate: [{ value: '', disabled: true }]
    });

    this.emailForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
    });

    this.setupEmailValidation();
  }

  ngAfterViewInit (): void {
    this.datepickerService.initializeDatepicker(
      '#businessEstablishmentDate',
      this.businessForm.get('businessEstablishmentDate')
    );
    this.datepickerService.initializeDatepicker(
      '#documentExpiryDate',
      this.businessForm.get('documentExpiryDate')
    );
  }

  setupEmailValidation (): void {
    this.emailForm.get('email')?.valueChanges
      .pipe(
        debounceTime(500), // wait longer before checking
        distinctUntilChanged(),
        filter(() => !!this.emailForm.get('email')?.valid), // force to boolean
        switchMap((email: string) =>
          this.validateEmail(email).pipe(
            catchError(err => {
              console.error('Email check failed:', err);
              this.emailForm.get('email')?.setErrors({ emailCheckFailed: true });
              return of(null);
            })
          )
        )
      )
      .subscribe((response: EmailValidationResponse | null) => {
        if (!response) return;
        if (response.status === 'NO_CONTENT') {
          this.isEmailValid = true;
          this.emailForm.get('email')?.setErrors(null);
        } else {
          this.isEmailValid = false;
          this.emailForm.get('email')?.setErrors({ emailExists: true });
        }
      });
  }

  onSubmitPartyDetails (): void {
    this.developerData = {
      ...this.form.value,
      primaryMobileNumber: this.userData?.primaryMobileNumber,
    };

    this.verifyDeveloperProfile(this.developerData as Models.UserModel).subscribe({
      next: (response: {data: PartyDetailsResponse}) => {
        console.log('API response:', response);

        // assuming response contains business info in "partyDetails"
        this.businessInfo = {
          fullName: response.data.fullName ?? '',
          createdDate: response.data.createdDate ?? '',
          documentExpiryDate: response.data.documentExpiryDate ?? ''
        };

        // patch values to form
        this.businessForm.patchValue({
          businessName: this.businessInfo.fullName,
          businessEstablishmentDate: this.businessInfo.createdDate,
          documentExpiryDate: this.businessInfo.documentExpiryDate
        });
      },
      error: (error: Error) => {
        console.error('API error:', error);
      },
      complete: () => {
        console.log('Request completed.');
      },
    });
  }

  onSubmitPartyEmail (): void {
    const payload = {
      ...this.developerData,
      email: this.emailForm.get('email')?.value,
      firstName: this.businessInfo.fullName,
      lastName: this.businessInfo.fullName,
      locale: localStorage.getItem('language') || 'en'
    };
    console.log('payload', payload);
    this.registerDeveloper(payload as Models.UserModel).subscribe({
      next: (response: {data: PartyDetailsResponse}) => {
        console.log('API response:', response);
        this.onSignupSuccessCallback();
      },
      error: (error: Error) => {
        console.error('API error:', error);
      },
      complete: () => {
        console.log('Request completed.');
      },
    });
  }

  setActiveScreen (screenName: string) {
    // Reset all screens
    this.isAccountTab = false;
    this.isPartyIdTab = false;
    this.isBusinessDetailTab = false;

    // Activate the specified screen
    switch (screenName) {
    case 'partyIdTab':
      this.isPartyIdTab = true;
      break;
    case 'businessDetailTab':
      this.isBusinessDetailTab = true;
      break;
    case 'accountTab':
      this.isAccountTab = true;
      break;
    default:
      console.error('Invalid screen name provided:', screenName);
    }
  }

  navigateNext () {
    if (this.currentScreenIndex === 0) {
      // First screen: validate + submit
      if (this.form.invalid) {
        this.form.markAllAsTouched();
        return;
      }
      this.onSubmitPartyDetails();
    }

    // Check if navigating to the last screen
    if (this.currentScreenIndex === 2) {
      // Validate email form before navigating to the last screen
      if (this.emailForm.invalid) {
        this.emailForm.markAllAsTouched();
        console.error('Email validation failed.');
        return;
      }
      this.onSubmitPartyEmail();
    }

    if (this.currentScreenIndex < this.screenOrder.length - 1) {
      this.currentScreenIndex++;
      this.setActiveScreen(this.screenOrder[this.currentScreenIndex]);
    } else {
      console.log('Already on the last screen.');
    }
  }

  navigatePrevious () {
    if (this.currentScreenIndex > 0) {
      this.currentScreenIndex--;
      this.setActiveScreen(this.screenOrder[this.currentScreenIndex]);
    } else {
      console.log('Already on the first screen.');
    }
  }

  isButtonDisabled (): boolean {
    // First screen: Disable if the form is invalid
    if (this.currentScreenIndex === 0) {
      return this.form.invalid;
    }

    // Last screen: Disable if the email form is invalid
    if (this.currentScreenIndex === 2) {
      return this.emailForm.invalid;
    }

    // Default: Button is enabled for other screens
    return false;
  }
}
