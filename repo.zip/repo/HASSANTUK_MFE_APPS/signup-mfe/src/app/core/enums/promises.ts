export enum PromiseStatus {
    fulfilled = 'fulfilled'
}
