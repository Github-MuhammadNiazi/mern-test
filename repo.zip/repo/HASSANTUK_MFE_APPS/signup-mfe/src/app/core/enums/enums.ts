export enum DocType {
  EmiratesID = 'EMIRATES_ID',
  Passport = 'PASSPORT',
  Registration = 'REGISTRATION',
  EmiratesNumber = 'EMIRATES_Number',
  TitleDeed = 'TITLE_DEED',
  UaeIdentityCard ='UAE Identity card',
  EstablishmentCard = 'ESTABLISHMENT_CARD',
};


export enum GenderTitle {
  Mr = 'MALE', Mrs = 'FEMALE'
}

export enum GenderTitleAr {
  السيد = 'MALE', السيدة = 'FEMALE'
}
