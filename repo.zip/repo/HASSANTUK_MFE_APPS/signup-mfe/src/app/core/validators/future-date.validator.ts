import { AbstractControl, ValidationErrors } from '@angular/forms';

export function futureDateValidator () {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    if (!value) return null;

    // Parse the input date (assuming format is dd/mm/yyyy)
    const [day, month, year] = value.split('/');
    const selectedDate = new Date(+year, +month - 1, +day);

    // Get today's date
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time to midnight for accurate comparison

    // Check if the selected date is today or in the future
    return selectedDate >= today ? null : { futureDateValidator: true };
  };
}
