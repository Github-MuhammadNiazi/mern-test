import { AbstractControl, ValidationErrors } from '@angular/forms';

export function minimumAgeValidator (minAge: number) {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    if (!value) return null;

    const [day, month, year] = value.split('/');
    const selectedDate = new Date(+year, +month - 1, +day);
    const today = new Date();

    const cutoff = new Date(
      today.getFullYear() - minAge,
      today.getMonth(),
      today.getDate()
    );

    return selectedDate > cutoff ? { minimumAgeValidator: { requiredAge: minAge } } : null;
  };
}
