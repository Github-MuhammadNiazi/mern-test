export interface EidResponse {
  status: string; // Example: 'OK', 'ERROR'
  data: boolean; // Example: true or false
  message: string; // Example: 'ناجحة' (Success message in Arabic)
  accepted: boolean; // Example: true or false
};
