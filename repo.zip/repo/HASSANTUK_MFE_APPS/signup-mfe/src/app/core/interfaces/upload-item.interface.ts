import Dropzone from "dropzone/dist/dropzone";

export interface UploadedItem {
    file: Dropzone.DropzoneFile;
    name: string;
    base64: string; // raw base64 only (no "data:...")
}
