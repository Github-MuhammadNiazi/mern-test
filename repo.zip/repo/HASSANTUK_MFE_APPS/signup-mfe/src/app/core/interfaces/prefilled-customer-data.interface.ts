export interface PrefilledData {
  firstNameEn?: string; // Optional string
  lastNameEn?: string;  // Optional string
  email?: string;       // Optional string
  documentId?: string;  // Optional string
  documentNumber?: string; // Optional string
  nationality?: string; // Optional string
  gender?: string;      // Optional string
  birthDate?: string;    // Required string
  documentExpiryDate?: string; // Optional string
  fistNameAr: string;   // Required string
  lastNameAr: string;   // Required string
  userDocuments: []; // Array that can hold any type of data
  userRoles: [];     // Array that can hold any type of data
  documentType: string; // Required string
  partyId?: string;     // Optional string
  residentialProfileId?: string; // Optional string
  primaryMobileNumber?: string; // Optional string
  locale: string;       // Required string
};
