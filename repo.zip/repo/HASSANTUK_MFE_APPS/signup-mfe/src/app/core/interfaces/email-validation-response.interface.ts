export interface EmailValidationResponse {
  status: string; // Example: 'OK', 'ERROR'
  data: unknown; // Example: true or false
  accepted: boolean; // Example: true or false
};
