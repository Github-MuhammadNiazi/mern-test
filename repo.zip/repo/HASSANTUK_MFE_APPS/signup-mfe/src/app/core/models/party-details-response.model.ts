export interface PartyDetailsResponse {
  fullName: string;
  documentExpiryDate: string;
  createdDate: string;
}
