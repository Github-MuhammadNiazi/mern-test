export interface docTypeModel {
  id: number;
  name: string;
}
