import { UserModel } from "./user-model";
export interface AuthState {
  user: UserModel | null;
  token: string | null;
  isAuthenticated: boolean;
  tempEmail: string | null; // temporary until login success
  error: string | null;
}
