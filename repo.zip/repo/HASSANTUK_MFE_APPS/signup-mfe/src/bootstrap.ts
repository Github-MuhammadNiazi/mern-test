import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { SignupComponent } from './app/app.component';

bootstrapApplication(SignupComponent, appConfig)
  .catch((err) => console.error(err));
